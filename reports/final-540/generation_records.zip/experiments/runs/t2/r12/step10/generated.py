import sys, csv, json, math

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]
CAT = ["origin"]


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows


def goal_values(header, rows):
    idx = [header.index(g) for g in GOALS]
    out = []
    for row in rows:
        try:
            out.append([float(row[i]) for i in idx])
        except (ValueError, IndexError):
            out.append(None)
    return out


def stats(tv):
    n = len(tv)
    means, sds = [], []
    for j in range(3):
        col = [v[j] for v in tv]
        m = sum(col) / n
        var = sum((c - m) ** 2 for c in col) / (n - 1) if n > 1 else 0.0
        means.append(m)
        sds.append(math.sqrt(var))
    return means, sds


def nrm(v, m, s):
    z = (v - m) / (s + 1e-32)
    z = max(-3.0, min(3.0, z))
    return 1.0 / (1.0 + math.exp(-1.702 * z))


def d2h(v, means, sds):
    heaven = list(GOALS.values())
    s = 0.0
    for j in range(3):
        s += (nrm(v[j], means[j], sds[j]) - heaven[j]) ** 2
    return math.sqrt(s / 3)


def remember(th, tr, eh, te):
    means, sds = stats([v for v in goal_values(th, tr) if v is not None])
    scores = [d2h(v, means, sds) for v in goal_values(eh, te)]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {"scores": scores, "top": order[:10], "best": order[0],
            "median": order[len(order) // 2], "worst": order[-1]}


# ---- guess ----
def getnum(h, row, c):
    try:
        return float(row[h.index(c)])
    except (ValueError, IndexError):
        return None


def getcat(h, row, c):
    try:
        v = row[h.index(c)]
        return None if v in ("?", "") else v
    except (ValueError, IndexError):
        return None


def raw(h, row):
    return [getnum(h, row, c) for c in NUM] + [getcat(h, row, c) for c in CAT]


def feat(r, avail, cats):
    f = []
    for k in range(len(NUM)):
        if avail[k]:
            f += [r[k], r[k] ** 2]
    for k, c in enumerate(CAT):
        if avail[len(NUM) + k]:
            f += [1.0 if r[len(NUM) + k] == v else 0.0 for v in cats[k]]
    return f


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        if abs(M[i][i]) < 1e-12:
            continue
        for r in range(n):
            if r != i:
                k = M[r][i] / M[i][i]
                for c in range(i, n + 1):
                    M[r][c] -= k * M[i][c]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]


def fit(X, ys, lam=1.0):
    n = len(X)
    d = len(X[0]) if X else 0
    mu = [sum(x[j] for x in X) / n for j in range(d)]
    sd = [math.sqrt(sum((x[j] - mu[j]) ** 2 for x in X) / n) or 1.0 for j in range(d)]
    Z = [[(x[j] - mu[j]) / sd[j] for j in range(d)] for x in X]
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0.0) for j in range(d)] for i in range(d)]
    models = []
    for y in ys:
        ym = sum(y) / n
        b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(d)]
        w = solve(A, b) if d else []
        models.append((ym, w))
    return mu, sd, models


def guess(th, tr, eh, te):
    means, sds = stats([v for v in goal_values(th, tr) if v is not None])
    gv = goal_values(th, tr)
    data = []
    for row, g in zip(tr, gv):
        if g is None or g[2] <= 0:
            continue
        data.append((raw(th, row), math.log(g[2]), d2h(g, means, sds)))
    cats = [sorted({r[len(NUM) + k] for r, _, _ in data if r[len(NUM) + k] is not None})
            for k in range(len(CAT))]
    gm = sum(math.exp(y) for _, y, _ in data) / len(data)
    gd = sum(s for _, _, s in data) / len(data)
    cache = {}
    mpg, sc = [], []
    for row in te:
        r = raw(eh, row)
        avail = tuple(x is not None for x in r)
        if avail not in cache:
            sub = [(r2, y, s) for r2, y, s in data
                   if all(a <= (x is not None) for a, x in zip(avail, r2))]
            if len(sub) < 5 or not any(avail):
                cache[avail] = None
            else:
                X = [feat(r2, avail, cats) for r2, _, _ in sub]
                cache[avail] = fit(X, [[y for _, y, _ in sub], [s for _, _, s in sub]])
        m = cache[avail]
        if m is None:
            mpg.append(gm)
            sc.append(gd)
            continue
        mu, sd, models = m
        z = [(a - b) / c for a, b, c in zip(feat(r, avail, cats), mu, sd)]
        p = [ym + sum(wi * zi for wi, zi in zip(w, z)) for ym, w in models]
        mv = math.exp(max(-1.0, min(5.0, p[0])))
        mpg.append(mv if math.isfinite(mv) and mv > 0 else gm)
        s = p[1]
        sc.append(max(0.0, min(1.0, s)) if math.isfinite(s) else gd)
    return {"mpg": mpg, "scores": sc}


# ---- certify ----
def var(v):
    m = sum(v) / len(v)
    return sum((x - m) ** 2 for x in v) / (len(v) - 1)


def compare(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    pooled = ((n - 1) * var(xs) + (m - 1) * var(ys)) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)
    tot = 0
    for x in xs:
        for y in ys:
            tot += (x > y) - (x < y)
    cliffs = abs(tot) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    i = j = 0
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v:
            i += 1
        while j < m and sy[j] <= v:
            j += 1
        d = max(d, abs(i / n - j / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}


def certify(cases):
    return {"comparisons": [compare([float(x) for x in c["xs"]],
                                    [float(y) for y in c["ys"]]) for c in cases]}


# ---- flow ----
def flow(th, tr, eh, te, win=20):
    g = guess(th, tr, eh, te)
    tv = [v for v in goal_values(th, tr) if v is not None]
    means, sds = stats(tv)
    hist = [d2h(v, means, sds) for v in tv]
    sc = g["scores"]
    alerts = []
    for i in range(len(sc)):
        if i < win - 1 or len(hist) < 2:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - win + 1:i + 1])["same"])
    return {"mpg": g["mpg"], "scores": sc, "alerts": alerts}


# ---- blame ----
def blame(th, tr, eh, te):
    gv = goal_values(th, tr)
    keep = [i for i, v in enumerate(gv) if v is not None]
    means, sds = stats([gv[i] for i in keep])
    rows = {i: raw(th, tr[i]) for i in keep}
    order = sorted(keep, key=lambda i: (round(d2h(gv[i], means, sds), 12), i))
    q = max(1, len(keep) // 4)
    good, poor = order[:q], order[-q:]
    nk = len(NUM)
    ns = []
    for k in range(nk):
        col = [rows[i][k] for i in keep if rows[i][k] is not None]
        if col:
            m = sum(col) / len(col)
            s = math.sqrt(sum((c - m) ** 2 for c in col) / (len(col) - 1)) if len(col) > 1 else 0.0
        else:
            m = s = 0.0
        ns.append((m, s))

    def center(grp, k):
        c = [rows[i][k] for i in grp if rows[i][k] is not None]
        return nrm(sum(c) / len(c), *ns[k]) if c else None

    centers = [(center(good, k), center(poor, k)) for k in range(nk)]

    def freqs(grp, k):
        c = [rows[i][nk + k] for i in grp if rows[i][nk + k] is not None]
        d = {}
        for v in c:
            d[v] = d.get(v, 0) + 1
        return d, len(c)

    cf = [(freqs(good, k), freqs(poor, k)) for k in range(len(CAT))]
    heaven = list(GOALS.values())
    names = list(GOALS)
    out = []
    for row in te:
        r = raw(eh, row)
        feats = {}
        for k, name in enumerate(NUM):
            x = r[k]
            gc, pc = centers[k]
            if x is None or gc is None or pc is None:
                feats[name] = 0.0
            else:
                nx = nrm(x, *ns[k])
                feats[name] = max(0.0, abs(nx - gc) - abs(nx - pc))
        for k, name in enumerate(CAT):
            x = r[nk + k]
            if x is None:
                feats[name] = 0.0
                continue
            (gd, gn), (pd, pn) = cf[k]
            gf = gd.get(x, 0) / gn if gn else 0.0
            pf = pd.get(x, 0) / pn if pn else 0.0
            feats[name] = max(0.0, pf - gf)
        gl = {}
        for j, name in enumerate(names):
            v = getnum(eh, row, name)
            gl[name] = abs(nrm(v, means[j], sds[j]) - heaven[j]) if v is not None else 0.0
        srt = lambda d: sorted(d, key=lambda n: (-round(d[n], 10), n))
        out.append({"goals": gl, "features": feats,
                    "goal_order": srt(gl), "feature_order": srt(feats)})
    return {"diagnoses": out}


# ---- justify ----
def justify(th, tr, eh, te):
    tv = [v for v in goal_values(th, tr) if v is not None]
    means, sds = stats(tv)
    hs = sorted(d2h(v, means, sds) for v in tv)
    cutoff = hs[len(hs) // 2]
    sc = [d2h(v, means, sds) for v in goal_values(eh, te)]
    dg = blame(th, tr, eh, te)["diagnoses"]
    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        if round(s, 12) == round(o, 12):
            w = None
        else:
            w = j if s < o else k
        adv = None
        if w is not None:
            l = k if w == j else j
            a = {g: dg[l]["goals"][g] ** 2 - dg[w]["goals"][g] ** 2 for g in GOALS}
            adv = sorted(a, key=lambda g: (-round(a[g], 10), g))[0]
        weak = dg[j]["goal_order"][0]
        tf = dg[j]["feature_order"][0]
        if not dg[j]["features"][tf] > 1e-10:
            tf = None
        t = "Car %d %s: score %.3f, other score %.3f (car %d), cutoff %.3f; weakest goal %s." % (
            j, "accepted" if acc else "rejected", s, o, k, cutoff, weak)
        if w is not None:
            t += " Recommend car %d; largest advantage in %s." % (w, adv)
        else:
            t += " The comparison is a tie."
        if tf is not None:
            t += " Top feature: %s." % tf
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": bool(acc), "winner": w,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": tf, "text": t})
    return {"explanations": out}


# ---- choose ----
def choose(th, tr, eh, te, budget=10):
    tv = [v for v in goal_values(th, tr) if v is not None]
    means, sds = stats(tv)
    n = len(te)
    pred = guess(th, tr, eh, te)["scores"]
    order = sorted(range(n), key=lambda i: (pred[i], i))
    b = min(budget, n)
    exploit = max(0, b - 3)
    picks = order[:exploit]
    for pos in (exploit + 5, exploit + 20, exploit + 60, exploit + 150):
        if len(picks) >= b:
            break
        p = min(pos, n - 1)
        while p < n and order[p] in picks:
            p += 1
        if p < n:
            picks.append(order[p])
    for i in order:
        if len(picks) >= b:
            break
        if i not in picks:
            picks.append(i)
    names = list(GOALS)
    seen = {}
    for i in picks:
        sys.stdout.write(json.dumps({"inspect": i}) + "\n")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        g = resp["goals"]
        seen[i] = d2h([float(g[k]) for k in names], means, sds)
    top = sorted(seen, key=lambda i: (round(seen[i], 12), i))[:3]
    return {"selected": top}


# ---- fix ----
def fix(th, tr, eh, te):
    gv = goal_values(th, tr)
    keep = [i for i, v in enumerate(gv) if v is not None]
    means, sds = stats([gv[i] for i in keep])
    score = {i: d2h(gv[i], means, sds) for i in keep}
    rows = {i: raw(th, tr[i]) for i in keep}
    nk = len(NUM)
    ns = []
    for k in range(nk):
        col = [rows[i][k] for i in keep if rows[i][k] is not None]
        m = sum(col) / len(col)
        s = math.sqrt(sum((c - m) ** 2 for c in col) / (len(col) - 1)) if len(col) > 1 else 0.0
        ns.append((m, s))

    def normrow(r):
        return [nrm(r[k], *ns[k]) for k in range(nk)] + [r[nk]]

    tn = {i: normrow(rows[i]) for i in keep}

    def dist(a, b):
        s = sum((a[k] - b[k]) ** 2 for k in range(nk))
        s += 0.0 if a[nk] == b[nk] else 1.0
        return math.sqrt(s / (nk + 1))

    def predict(nr):
        ds = sorted(keep, key=lambda i: (round(dist(nr, tn[i]), 12), i))
        return sum(score[i] for i in ds[:5]) / len(ds[:5])

    hs = sorted(score.values())
    cutoff = hs[len(hs) // 2]
    ranked = sorted(keep, key=lambda i: (round(score[i], 12), i))
    good = ranked[:max(1, len(keep) // 4)]
    menu = []
    for i in good:
        p = (rows[i][0], rows[i][1])
        if p not in menu:
            menu.append(p)
        if len(menu) >= 12:
            break
    out = []
    for ri, row in enumerate(te):
        r = raw(eh, row)
        nr = normrow(r)
        before = predict(nr)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": ri, "before": before, "after": before,
                        "changes": {}, "status": "already_good"})
            continue
        best = None
        for c, v in menu:
            ch = (c != r[0]) + (v != r[1])
            if ch == 0:
                continue
            e = [c, v, r[2], r[3]]
            ne = normrow(e)
            after = predict(ne)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(nr, ne), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, c, v)
        if best is None:
            out.append({"row": ri, "before": before, "after": before,
                        "changes": {}, "status": "no_candidate"})
        else:
            _, after, c, v = best
            changes = {}
            if c != r[0]:
                changes["Clndrs"] = c
            if v != r[1]:
                changes["Volume"] = v
            out.append({"row": ri, "before": before, "after": after,
                        "changes": changes, "status": "improved"})
    return {"repairs": out}


# ---- spot ----
def spot(th, tr, eh, te, q=0.975):
    nk = len(NUM)
    trr = [raw(th, r) for r in tr]
    prm = []
    for k in range(nk):
        col = sorted(r[k] for r in trr if r[k] is not None)
        n = len(col)
        med = col[n // 2] if n % 2 else (col[n // 2 - 1] + col[n // 2]) / 2
        dev = sorted(abs(c - med) for c in col)
        mad = dev[n // 2] if n else 0.0
        m = sum(col) / n if n else 0.0
        sd = math.sqrt(sum((c - m) ** 2 for c in col) / (n - 1)) if n > 1 else 0.0
        sc = max(1.4826 * mad, 0.5 * sd, 1e-9)
        prm.append((med, sc))
    freq = []
    for k in range(len(CAT)):
        c = [r[nk + k] for r in trr if r[nk + k] is not None]
        d = {}
        for v in c:
            d[v] = d.get(v, 0) + 1
        freq.append((d, max(1, len(c))))

    def rawscore(r):
        zs = [0.0]
        for k in range(nk):
            if r[k] is not None:
                zs.append(abs(r[k] - prm[k][0]) / prm[k][1])
        for k in range(len(CAT)):
            x = r[nk + k]
            if x is not None:
                d, n = freq[k]
                p = max(d.get(x, 0), 0.5) / n
                zs.append(min(6.0, max(0.0, -math.log(p) - 1.5)))
        return max(zs) + 0.1 * sum(zs) / len(zs)

    def mp(x):
        return x / (1.0 + x)

    ts = sorted(mp(rawscore(r)) for r in trr)
    thr = ts[min(len(ts) - 1, int(q * len(ts)))] if ts else 1.0
    scores = [mp(rawscore(raw(eh, r))) for r in te]
    return {"scores": scores, "alerts": [bool(s > thr) for s in scores],
            "threshold": thr}


# ---- race ----
def race(th, tr, data):
    tv = [v for v in goal_values(th, tr) if v is not None]
    means, sds = stats(tv)
    hs = sorted(d2h(v, means, sds) for v in tv)
    target = round(hs[len(tv) // 4], 12)
    h = [str(c) for c in data["header"]]
    rows = [[str(c) for c in r] for r in data["rows"]]
    pred = guess(th, tr, h, rows)["scores"]
    names = list(GOALS)

    def run(e, strat, idxs):
        obs = []
        for i in idxs:
            sys.stdout.write(json.dumps({"episode": e, "strategy": strat, "inspect": i}) + "\n")
            sys.stdout.flush()
            line = sys.stdin.readline()
            if not line:
                raise SystemExit(1)
            g = json.loads(line)["goals"]
            obs.append(d2h([float(g[k]) for k in names], means, sds))
        lab = 11
        for p, s in enumerate(obs):
            if round(s, 12) <= target:
                lab = p + 1
                break
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lab}

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = ep["pool"]
        ad = sorted(pool, key=lambda i: (pred[i], i))[:10]
        a = run(e, "adaptive", ad)
        r = run(e, "random", ep["random_order"][:10])
        results.append({"episode": e, "adaptive": a, "random": r})
    comp = {}
    for m in ("best5", "best10", "labels_to_target"):
        comp[m] = compare([float(x["adaptive"][m]) for x in results],
                          [float(x["random"][m]) for x in results])
    return {"results": results, "comparisons": comp}


def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("remember", "guess", "certify", "flow", "blame", "justify",
                             "choose", "fix", "spot", "race"):
        sys.exit(1)
    train = test = None
    for i, x in enumerate(a):
        if x == "--train":
            train = a[i + 1]
        elif x == "--test":
            test = a[i + 1]
    if a[0] == "certify":
        with open(test) as f:
            res = certify(json.load(f))
    elif a[0] == "race":
        th, tr = read(train)
        with open(test) as f:
            res = race(th, tr, json.load(f))
    else:
        th, tr = read(train)
        eh, te = read(test)
        if a[0] == "remember":
            res = remember(th, tr, eh, te)
        elif a[0] == "guess":
            res = guess(th, tr, eh, te)
        elif a[0] == "blame":
            res = blame(th, tr, eh, te)
        elif a[0] == "justify":
            res = justify(th, tr, eh, te)
        elif a[0] == "choose":
            res = choose(th, tr, eh, te)
        elif a[0] == "fix":
            res = fix(th, tr, eh, te)
        elif a[0] == "spot":
            res = spot(th, tr, eh, te)
        else:
            res = flow(th, tr, eh, te)
    sys.stdout.write(json.dumps(res))
    sys.stdout.flush()


main()
