import sys, csv, json, math

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]
CAT = ["origin"]


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows


def goal_values(header, rows):
    idx = [header.index(g) for g in GOALS]
    out = []
    for row in rows:
        try:
            out.append([float(row[i]) for i in idx])
        except (ValueError, IndexError):
            out.append(None)
    return out


def stats(tv):
    n = len(tv)
    means, sds = [], []
    for j in range(3):
        col = [v[j] for v in tv]
        m = sum(col) / n
        var = sum((c - m) ** 2 for c in col) / (n - 1) if n > 1 else 0.0
        means.append(m)
        sds.append(math.sqrt(var))
    return means, sds


def d2h(v, means, sds):
    heaven = list(GOALS.values())
    s = 0.0
    for j in range(3):
        z = (v[j] - means[j]) / (sds[j] + 1e-32)
        z = max(-3.0, min(3.0, z))
        nv = 1.0 / (1.0 + math.exp(-1.702 * z))
        s += (nv - heaven[j]) ** 2
    return math.sqrt(s / 3)


def remember(th, tr, eh, te):
    means, sds = stats([v for v in goal_values(th, tr) if v is not None])
    scores = [d2h(v, means, sds) for v in goal_values(eh, te)]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {"scores": scores, "top": order[:10], "best": order[0],
            "median": order[len(order) // 2], "worst": order[-1]}


# ---- guess ----
def getnum(h, row, c):
    try:
        return float(row[h.index(c)])
    except (ValueError, IndexError):
        return None


def getcat(h, row, c):
    try:
        v = row[h.index(c)]
        return None if v in ("?", "") else v
    except (ValueError, IndexError):
        return None


def raw(h, row):
    return [getnum(h, row, c) for c in NUM] + [getcat(h, row, c) for c in CAT]


def feat(r, avail, cats):
    f = []
    for k in range(len(NUM)):
        if avail[k]:
            f += [r[k], r[k] ** 2]
    for k, c in enumerate(CAT):
        if avail[len(NUM) + k]:
            f += [1.0 if r[len(NUM) + k] == v else 0.0 for v in cats[k]]
    return f


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        if abs(M[i][i]) < 1e-12:
            continue
        for r in range(n):
            if r != i:
                k = M[r][i] / M[i][i]
                for c in range(i, n + 1):
                    M[r][c] -= k * M[i][c]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]


def fit(X, ys, lam=1.0):
    n = len(X)
    d = len(X[0]) if X else 0
    mu = [sum(x[j] for x in X) / n for j in range(d)]
    sd = [math.sqrt(sum((x[j] - mu[j]) ** 2 for x in X) / n) or 1.0 for j in range(d)]
    Z = [[(x[j] - mu[j]) / sd[j] for j in range(d)] for x in X]
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0.0) for j in range(d)] for i in range(d)]
    models = []
    for y in ys:
        ym = sum(y) / n
        b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(d)]
        w = solve(A, b) if d else []
        models.append((ym, w))
    return mu, sd, models


def guess(th, tr, eh, te):
    means, sds = stats([v for v in goal_values(th, tr) if v is not None])
    gv = goal_values(th, tr)
    data = []
    for row, g in zip(tr, gv):
        if g is None or g[2] <= 0:
            continue
        data.append((raw(th, row), math.log(g[2]), d2h(g, means, sds)))
    cats = [sorted({r[len(NUM) + k] for r, _, _ in data if r[len(NUM) + k] is not None})
            for k in range(len(CAT))]
    gm = sum(math.exp(y) for _, y, _ in data) / len(data)
    gd = sum(s for _, _, s in data) / len(data)
    cache = {}
    mpg, sc = [], []
    for row in te:
        r = raw(eh, row)
        avail = tuple(x is not None for x in r)
        if avail not in cache:
            sub = [(r2, y, s) for r2, y, s in data
                   if all(a <= (x is not None) for a, x in zip(avail, r2))]
            if len(sub) < 5 or not any(avail):
                cache[avail] = None
            else:
                X = [feat(r2, avail, cats) for r2, _, _ in sub]
                cache[avail] = fit(X, [[y for _, y, _ in sub], [s for _, _, s in sub]])
        m = cache[avail]
        if m is None:
            mpg.append(gm)
            sc.append(gd)
            continue
        mu, sd, models = m
        z = [(a - b) / c for a, b, c in zip(feat(r, avail, cats), mu, sd)]
        p = [ym + sum(wi * zi for wi, zi in zip(w, z)) for ym, w in models]
        mv = math.exp(max(-1.0, min(5.0, p[0])))
        mpg.append(mv if math.isfinite(mv) and mv > 0 else gm)
        s = p[1]
        sc.append(max(0.0, min(1.0, s)) if math.isfinite(s) else gd)
    return {"mpg": mpg, "scores": sc}


def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("remember", "guess"):
        sys.exit(1)
    train = test = None
    for i, x in enumerate(a):
        if x == "--train":
            train = a[i + 1]
        elif x == "--test":
            test = a[i + 1]
    th, tr = read(train)
    eh, te = read(test)
    res = remember(th, tr, eh, te) if a[0] == "remember" else guess(th, tr, eh, te)
    sys.stdout.write(json.dumps(res))


main()
