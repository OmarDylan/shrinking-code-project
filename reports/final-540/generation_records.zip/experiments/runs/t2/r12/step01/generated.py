import sys, csv, json, math

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows


def goal_values(header, rows):
    idx = [header.index(g) for g in GOALS]
    out = []
    for row in rows:
        try:
            out.append([float(row[i]) for i in idx])
        except (ValueError, IndexError):
            out.append(None)
    return out


def main():
    a = sys.argv[1:]
    if not a or a[0] != "remember":
        sys.exit(1)
    train = test = None
    for i, x in enumerate(a):
        if x == "--train":
            train = a[i + 1]
        elif x == "--test":
            test = a[i + 1]
    th, tr = read(train)
    eh, te = read(test)
    tv = [v for v in goal_values(th, tr) if v is not None]
    n = len(tv)
    means, sds = [], []
    for j in range(3):
        col = [v[j] for v in tv]
        m = sum(col) / n
        var = sum((c - m) ** 2 for c in col) / (n - 1) if n > 1 else 0.0
        means.append(m)
        sds.append(math.sqrt(var))
    heaven = list(GOALS.values())
    scores = []
    for v in goal_values(eh, te):
        s = 0.0
        for j in range(3):
            z = (v[j] - means[j]) / (sds[j] + 1e-32)
            z = max(-3.0, min(3.0, z))
            nv = 1.0 / (1.0 + math.exp(-1.702 * z))
            s += (nv - heaven[j]) ** 2
        scores.append(math.sqrt(s / 3))
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    res = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(res))


main()
