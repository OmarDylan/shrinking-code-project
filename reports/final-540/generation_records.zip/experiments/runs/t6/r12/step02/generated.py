import csv, sys, json, argparse
from math import exp, sqrt, log


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if any(c.strip() for c in r)]
    return rows[0], rows[1:]


def num(x):
    try:
        v = float(x)
        return v if v == v and abs(v) != float("inf") else None
    except ValueError:
        return None


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                f = M[r][c] / d
                if f:
                    for k in range(c, n + 1):
                        M[r][k] -= f * M[c][k]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]


def guess(names, train, test, goals, stats, score):
    ix = {s: i for i, s in enumerate(names)}
    ci, vi, mi, oi = ix["Clndrs"], ix["Volume"], ix["Model"], ix["origin"]
    gi = {s[:-1]: i for i, s in enumerate(names) if s[-1] in "+-"}
    train = [r for r in train if all(num(r[i]) is not None for i, _ in goals)]

    def col_mean(i):
        vs = [num(r[i]) for r in train if num(r[i]) is not None]
        return sum(vs) / len(vs) if vs else 0.0

    mean = {i: col_mean(i) for i in (ci, vi, mi)}
    origins = sorted({r[oi] for r in train if r[oi] != "?"})
    byc, byco = {}, {}
    for r in train:
        c, v = num(r[ci]), num(r[vi])
        if c is None or v is None:
            continue
        byc.setdefault(c, []).append(v)
        byco.setdefault((c, r[oi]), []).append(v)

    def vol(r):
        v = num(r[vi])
        if v is not None:
            return v
        c = num(r[ci])
        g = byco.get((c, r[oi]), [])
        if len(g) < 3:
            g = byc.get(c, [])
        return sum(g) / len(g) if g else mean[vi]

    def feats(r):
        c = num(r[ci]); c = mean[ci] if c is None else c
        m = num(r[mi]); m = mean[mi] if m is None else m
        v = max(vol(r), 1.0)
        return [c, log(v), v, m, log(v) * m / 100] + [1.0 if r[oi] == o else 0.0 for o in origins]

    X = [feats(r) for r in train]
    k = len(X[0])
    mu = [sum(x[j] for x in X) / len(X) for j in range(k)]
    sd = [sqrt(sum((x[j] - mu[j]) ** 2 for x in X) / max(1, len(X) - 1)) or 1.0 for j in range(k)]

    def prep(x):
        return [1.0] + [(x[j] - mu[j]) / sd[j] for j in range(k)]

    Z = [prep(x) for x in X]
    lam = 1.0
    A = [[sum(z[a] * z[b] for z in Z) + (lam if a == b and a > 0 else 0.0) for b in range(k + 1)]
         for a in range(k + 1)]

    def fit(ys):
        return solve(A, [sum(z[a] * y for z, y in zip(Z, ys)) for a in range(k + 1)])

    models = {}
    for name, i in gi.items():
        ys = [num(r[i]) for r in train]
        if name == "Mpg":
            ys = [log(max(y, 1e-3)) for y in ys]
        models[i] = (name, fit(ys))

    mpg, scores = [], []
    for r in test:
        z = prep(feats(r))
        pred = {}
        for i, (name, w) in models.items():
            p = sum(a * b for a, b in zip(w, z))
            pred[i] = exp(p) if name == "Mpg" else p
        mp = pred[gi["Mpg"]]
        if not (mp > 0) or mp == float("inf"):
            mp = stats[gi["Mpg"]][0]
        pred[gi["Mpg"]] = mp
        mpg.append(float(mp))
        scores.append(min(1.0, max(0.0, score(pred))))
    return {"mpg": mpg, "scores": scores}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, train = read(a.train)
    tnames, test = read(a.test)
    goals = [(i, 0 if s[-1] == "-" else 1) for i, s in enumerate(names) if s[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        vs = [float(r[i]) for r in train if num(r[i]) is not None]
        n = len(vs)
        mu = sum(vs) / n
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            t += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(t / len(goals))

    if a.cmd == "guess":
        out = guess(names, train, test, goals, stats, score)
    else:
        scores = [score(r) for r in test]
        rank = sorted(range(len(scores)), key=lambda i: (scores[i], i))
        out = {"scores": scores, "top": rank[:10], "best": rank[0],
               "median": rank[len(rank) // 2], "worst": rank[-1]}
    sys.stdout.write(json.dumps(out) + "\n")


main()
