import csv, sys, json, argparse
from math import exp, sqrt


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if any(c.strip() for c in r)]
    return rows[0], rows[1:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, train = read(a.train)
    tnames, test = read(a.test)
    goals = [(i, 0 if s[-1] == "-" else 1) for i, s in enumerate(names) if s[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        vs = [float(r[i]) for r in train]
        n = len(vs)
        mu = sum(vs) / n
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            t += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(t / len(goals))

    scores = [score(r) for r in test]
    rank = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {"scores": scores, "top": rank[:10], "best": rank[0],
           "median": rank[len(rank) // 2], "worst": rank[-1]}
    sys.stdout.write(json.dumps(out) + "\n")


main()
