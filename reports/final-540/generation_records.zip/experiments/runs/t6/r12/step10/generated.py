import csv, sys, json, argparse
from math import exp, sqrt, log
from bisect import bisect_left, bisect_right


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if any(c.strip() for c in r)]
    return rows[0], rows[1:]


def num(x):
    try:
        v = float(x)
        return v if v == v and abs(v) != float("inf") else None
    except ValueError:
        return None


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                f = M[r][c] / d
                if f:
                    for k in range(c, n + 1):
                        M[r][k] -= f * M[c][k]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]


def guess(names, train, test, goals, stats, score):
    ix = {s: i for i, s in enumerate(names)}
    ci, vi, mi, oi = ix["Clndrs"], ix["Volume"], ix["Model"], ix["origin"]
    gi = {s[:-1]: i for i, s in enumerate(names) if s[-1] in "+-"}
    train = [r for r in train if all(num(r[i]) is not None for i, _ in goals)]

    def col_mean(i):
        vs = [num(r[i]) for r in train if num(r[i]) is not None]
        return sum(vs) / len(vs) if vs else 0.0

    mean = {i: col_mean(i) for i in (ci, vi, mi)}
    origins = sorted({r[oi] for r in train if r[oi] != "?"})
    byc, byco = {}, {}
    for r in train:
        c, v = num(r[ci]), num(r[vi])
        if c is None or v is None:
            continue
        byc.setdefault(c, []).append(v)
        byco.setdefault((c, r[oi]), []).append(v)

    def vol(r):
        v = num(r[vi])
        if v is not None:
            return v
        c = num(r[ci])
        g = byco.get((c, r[oi]), [])
        if len(g) < 3:
            g = byc.get(c, [])
        return sum(g) / len(g) if g else mean[vi]

    def feats(r):
        c = num(r[ci]); c = mean[ci] if c is None else c
        m = num(r[mi]); m = mean[mi] if m is None else m
        v = max(vol(r), 1.0)
        return [c, log(v), v, m, log(v) * m / 100] + [1.0 if r[oi] == o else 0.0 for o in origins]

    X = [feats(r) for r in train]
    k = len(X[0])
    mu = [sum(x[j] for x in X) / len(X) for j in range(k)]
    sd = [sqrt(sum((x[j] - mu[j]) ** 2 for x in X) / max(1, len(X) - 1)) or 1.0 for j in range(k)]

    def prep(x):
        return [1.0] + [(x[j] - mu[j]) / sd[j] for j in range(k)]

    Z = [prep(x) for x in X]
    lam = 1.0
    A = [[sum(z[a] * z[b] for z in Z) + (lam if a == b and a > 0 else 0.0) for b in range(k + 1)]
         for a in range(k + 1)]

    def fit(ys):
        return solve(A, [sum(z[a] * y for z, y in zip(Z, ys)) for a in range(k + 1)])

    models = {}
    for name, i in gi.items():
        ys = [num(r[i]) for r in train]
        if name == "Mpg":
            ys = [log(max(y, 1e-3)) for y in ys]
        models[i] = (name, fit(ys))

    mpg, scores = [], []
    for r in test:
        z = prep(feats(r))
        pred = {}
        for i, (name, w) in models.items():
            p = sum(a * b for a, b in zip(w, z))
            pred[i] = exp(p) if name == "Mpg" else p
        mp = pred[gi["Mpg"]]
        if not (mp > 0) or mp == float("inf"):
            mp = stats[gi["Mpg"]][0]
        pred[gi["Mpg"]] = mp
        mpg.append(float(mp))
        scores.append(min(1.0, max(0.0, score(pred))))
    return {"mpg": mpg, "scores": scores}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    sx, sy = sorted(xs), sorted(ys)
    tot = 0
    for x in sx:
        tot += bisect_left(sy, x) - (m - bisect_right(sy, x))
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(sx) | set(sy)):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}


def certify(path):
    with open(path, encoding="utf-8-sig") as f:
        cases = json.load(f)
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def flow(scores, hist, w=20):
    alerts = []
    for i in range(len(scores)):
        if i < w - 1 or len(hist) < 2:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, scores[i - w + 1:i + 1])["same"])
    return alerts


def blame(names, train, test, goals, stats, score):
    def nrm(mu, sd, v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + exp(-1.702 * z))

    gidx = {i for i, _ in goals}
    full = [r for r in train if all(num(r[i]) is not None for i, _ in goals)]
    feats = [i for i, s in enumerate(names)
             if s[-1] not in "+-X" and i not in gidx]
    isnum = {i: names[i][0].isupper() for i in feats}
    st = {}
    for i in feats:
        if isnum[i]:
            vs = [num(r[i]) for r in full if num(r[i]) is not None]
            n = len(vs)
            mu = sum(vs) / n if n else 0.0
            sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
            st[i] = (mu, sd)
    order = sorted(range(len(full)), key=lambda j: (round(score(full[j]), 12), j))
    q = max(1, len(full) // 4)
    good = [full[j] for j in order[:q]]
    poor = [full[j] for j in order[len(order) - q:]] if full else []
    cen, freq = {}, {}
    for i in feats:
        if isnum[i]:
            cs = []
            for g in (good, poor):
                vs = [num(r[i]) for r in g if num(r[i]) is not None]
                cs.append(nrm(*st[i], sum(vs) / len(vs)) if vs else None)
            cen[i] = cs
        else:
            fs = []
            for g in (good, poor):
                kn = [r[i] for r in g if r[i] != "?"]
                d = {}
                for v in kn:
                    d[v] = d.get(v, 0) + 1
                fs.append((d, len(kn)))
            freq[i] = fs

    out = []
    for r in test:
        fe = {}
        for i in feats:
            nm = names[i]
            v = r[i]
            e = 0.0
            if v != "?":
                if isnum[i]:
                    x = num(v)
                    gc, pc = cen[i]
                    if x is not None and gc is not None and pc is not None:
                        nx = nrm(*st[i], x)
                        e = max(0.0, abs(nx - gc) - abs(nx - pc))
                else:
                    (gd, gn), (pd, pn) = freq[i]
                    gf = gd.get(v, 0) / gn if gn else 0.0
                    pf = pd.get(v, 0) / pn if pn else 0.0
                    e = max(0.0, pf - gf)
            fe[nm] = min(1.0, e)
        go = {}
        for i, h in goals:
            x = num(r[i])
            mu, sd = stats[i]
            go[names[i][:-1]] = abs(nrm(mu, sd, x) - h) if x is not None else 0.0
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": go, "features": fe,
                    "goal_order": key(go), "feature_order": key(fe)})
    return {"diagnoses": out}


def justify(names, train, test, goals, stats, score):
    diag = blame(names, train, test, goals, stats, score)["diagnoses"]
    full = [score(r) for r in train if all(num(r[i]) is not None for i, _ in goals)]
    srt = sorted(full)
    cutoff = srt[min(len(srt) // 2, len(srt) - 1)] if srt else 0.0
    scores = [score(r) for r in test]
    n = len(test)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        d = diag[j]
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: diag[loser]["goals"][g] ** 2 - diag[winner]["goals"][g] ** 2
                   for g in d["goals"]}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        weakest = d["goal_order"][0]
        tf = d["feature_order"][0] if d["feature_order"] else None
        if tf is not None and not d["features"][tf] > 1e-10:
            tf = None
        text = (f"Car {j} {'accepted' if accepted else 'rejected'}: score {s:.3f} "
                f"vs other car {k} score {o:.3f}, cutoff {cutoff:.3f}; "
                f"weakest goal {weakest}. ")
        if winner is not None:
            text += f"Recommend car {winner} because of advantage in {adv_goal}. "
        else:
            text += "The cars tie. "
        if tf is not None:
            text += f"Top feature associated: {tf}."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": bool(accepted),
                    "winner": winner, "advantage_goal": adv_goal,
                    "weakest_goal": weakest, "top_feature": tf, "text": text})
    return {"explanations": out}


def choose(names, train, test, goals, stats, score):
    """Model-guided active search: predict d2h, inspect the best adjusted
    candidate, correct predictions with kernel-weighted observed residuals."""
    n = len(test)
    budget = min(10, n)
    pred = guess(names, train, test, goals, stats, score)["scores"]
    ix = {s: i for i, s in enumerate(names)}
    numc = [ix["Clndrs"], ix["Volume"], ix["Model"]]
    oi = ix["origin"]
    sc = []
    for i in numc:
        vs = [num(r[i]) for r in train if num(r[i]) is not None]
        mu = sum(vs) / len(vs) if vs else 0.0
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / max(1, len(vs) - 1)) if vs else 1.0
        sc.append((mu, sd or 1.0))

    def gap(a, b):
        t = 0.0
        for (i, (mu, sd)) in zip(numc, sc):
            x, y = num(a[i]), num(b[i])
            t += 0.25 if x is None or y is None else ((x - y) / sd) ** 2
        t += 1.0 if (a[oi] != b[oi]) else 0.0
        return sqrt(t / 4)

    def d2h(g):
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(g[names[i]]) - mu) / (sd + 1e-32)))
            t += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(t / len(goals))

    seen = {}
    while len(seen) < budget:
        best, bs = None, None
        for j in range(n):
            if j in seen:
                continue
            ws = rs = 0.0
            for k, (d, _) in seen.items():
                w = exp(-(gap(test[j], test[k]) / 0.5) ** 2)
                ws += w
                rs += w * (d - pred[k])
            adj = pred[j] + (rs / (ws + 1.0) if seen else 0.0)
            if bs is None or adj < bs:
                best, bs = j, adj
        sys.stdout.write(json.dumps({"inspect": best}) + "\n")
        sys.stdout.flush()
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        seen[best] = (d2h(resp["goals"]), None)
    rank = sorted(seen, key=lambda j: (round(seen[j][0], 12), j))
    return {"selected": rank[:3]}


def fix(names, train, test, goals, stats, score):
    ix = {s: i for i, s in enumerate(names)}
    ci, vi, mi, oi = ix["Clndrs"], ix["Volume"], ix["Model"], ix["origin"]
    numc = [ci, vi, mi]
    full = [r for r in train if all(num(r[i]) is not None for i, _ in goals)]
    st = {}
    for i in numc:
        vs = [num(r[i]) for r in full if num(r[i]) is not None]
        n = len(vs)
        mu = sum(vs) / n if n else 0.0
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        st[i] = (mu, sd)

    def nrm(i, v):
        mu, sd = st[i]
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + exp(-1.702 * z))

    def prep(r):
        return ([None if num(r[i]) is None else nrm(i, num(r[i])) for i in numc], r[oi])

    def dist(a, b):
        t = 0.0
        for x, y in zip(a[0], b[0]):
            t += 1.0 if x is None or y is None else (x - y) ** 2
        t += 0.0 if a[1] == b[1] else 1.0
        return sqrt(t / 4)

    tp = [prep(r) for r in full]
    d2 = [score(r) for r in full]

    def predict(p):
        ds = sorted(range(len(tp)), key=lambda j: (round(dist(p, tp[j]), 12), j))[:5]
        return sum(d2[j] for j in ds) / len(ds) if ds else 0.0

    srt = sorted(d2)
    cutoff = srt[min(len(srt) // 2, len(srt) - 1)] if srt else 0.0
    order = sorted(range(len(full)), key=lambda j: (round(d2[j], 12), j))
    good = order[:max(1, len(full) // 4)]
    menu = []
    for j in good:
        pr = (num(full[j][ci]), num(full[j][vi]))
        if pr not in menu:
            menu.append(pr)
        if len(menu) == 12:
            break

    out = []
    for idx, r in enumerate(test):
        p = prep(r)
        before = predict(p)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "already_good"})
            continue
        oc, ov = num(r[ci]), num(r[vi])
        best = None
        for nc, nv in menu:
            ch = int(oc != nc) + int(ov != nv)
            if ch == 0:
                continue
            q = ([nrm(ci, nc), nrm(vi, nv), p[0][2]], p[1])
            after = predict(q)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(p, q), 10), round(after, 10), (nc, nv))
                if best is None or key < best[0]:
                    best = (key, after, nc, nv)
        if best is None:
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "no_candidate"})
        else:
            _, after, nc, nv = best
            changes = {}
            if oc != nc:
                changes[names[ci]] = nc
            if ov != nv:
                changes[names[vi]] = nv
            out.append({"row": idx, "before": before, "after": after,
                        "changes": changes, "status": "improved"})
    return {"repairs": out}


def spot(names, train, test, q=0.97, k=5):
    """Unsupervised anomaly score from training inputs only:
    robust per-column z-scores + kNN distance (standardized numerics, origin mismatch)."""
    ix = {s: i for i, s in enumerate(names)}
    numc = [ix["Clndrs"], ix["Volume"], ix["Model"]]
    oi = ix["origin"]
    st = []
    for i in numc:
        vs = sorted(v for v in (num(r[i]) for r in train) if v is not None)
        n = len(vs)
        med = vs[n // 2] if n else 0.0
        mad = sorted(abs(v - med) for v in vs)[n // 2] * 1.4826 if n else 0.0
        mu = sum(vs) / n if n else 0.0
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / max(1, n - 1)) if n else 1.0
        st.append((med, mad or sd or 1.0, sd or 1.0))
    cnt = {}
    for r in train:
        cnt[r[oi]] = cnt.get(r[oi], 0) + 1
    tot = max(1, sum(v for o, v in cnt.items() if o != "?"))

    def vec(r):
        return [num(r[i]) for i in numc]

    def dist(a, b):
        t = c = 0
        for x, y, (_, _, sd) in zip(a[0], b[0], st):
            if x is not None and y is not None:
                t += ((x - y) / sd) ** 2
                c += 1
        if a[1] != "?" and b[1] != "?":
            t += 0.0 if a[1] == b[1] else 1.0
            c += 1
        return sqrt(t / c) if c else 0.0

    def uni(r):
        z = 0.0
        for x, (med, s, _) in zip(vec(r), st):
            if x is not None:
                z = max(z, abs(x - med) / s)
        if r[oi] != "?":
            f = cnt.get(r[oi], 0) / tot
            if f < 0.01:
                z = max(z, 3.0)
        return z

    tp = [(vec(r), r[oi]) for r in train]

    def knn(p, skip=None):
        ds = sorted(dist(p, t) for j, t in enumerate(tp) if j != skip)[:k]
        return sum(ds) / len(ds) if ds else 0.0

    kt = [knn(tp[j], j) for j in range(len(tp))]
    kref = sorted(kt)[len(kt) // 2] if kt else 1.0
    kref = kref or 1.0

    def raw(r, kd):
        return kd / kref + uni(r) / 3.0

    rt = sorted(raw(r, kd) for r, kd in zip(train, kt))
    m = rt[len(rt) // 2] if rt else 1.0
    m = m or 1.0

    def squash(x):
        return min(1.0, max(0.0, x / (x + m)))

    thr_raw = rt[min(len(rt) - 1, int(q * len(rt)))] if rt else 1.0
    thr = squash(thr_raw)
    scores = [squash(raw(r, knn((vec(r), r[oi])))) for r in test]
    return {"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}


def race(names, train, path, goals, stats, score):
    """Per episode: model-guided adaptive search vs supplied random order."""
    with open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    rows = [[str(c) for c in r] for r in data["rows"]]
    full = [r for r in train if all(num(r[i]) is not None for i, _ in goals)]
    d2 = sorted(score(r) for r in full)
    target = d2[min(len(d2) // 4, len(d2) - 1)] if d2 else 0.0
    pred = guess(names, train, rows, goals, stats, score)["scores"]
    ix = {s: i for i, s in enumerate(names)}
    numc = [ix["Clndrs"], ix["Volume"], ix["Model"]]
    oi = ix["origin"]
    sc = []
    for i in numc:
        vs = [num(r[i]) for r in train if num(r[i]) is not None]
        mu = sum(vs) / len(vs) if vs else 0.0
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / max(1, len(vs) - 1)) if vs else 1.0
        sc.append(sd or 1.0)

    def gap(a, b):
        t = 0.0
        for i, sd in zip(numc, sc):
            x, y = num(a[i]), num(b[i])
            t += 0.25 if x is None or y is None else ((x - y) / sd) ** 2
        t += 1.0 if a[oi] != b[oi] else 0.0
        return sqrt(t / 4)

    def d2h(g):
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(g[names[i]]) - mu) / (sd + 1e-32)))
            t += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(t / len(goals))

    def look(ep, strat, i):
        sys.stdout.write(json.dumps({"episode": ep, "strategy": strat, "inspect": i}) + "\n")
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        return d2h(resp["goals"])

    def metrics(obs):
        lt = next((k + 1 for k, o in enumerate(obs) if round(o, 12) <= round(target, 12)), 11)
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lt}

    results = []
    for ep, e in enumerate(data["episodes"]):
        pool = list(e["pool"])
        seen = {}
        obs = []
        for _ in range(min(10, len(pool))):
            best, bs = None, None
            for j in pool:
                if j in seen:
                    continue
                ws = rs = 0.0
                for kk, d in seen.items():
                    w = exp(-(gap(rows[j], rows[kk]) / 0.5) ** 2)
                    ws += w
                    rs += w * (d - pred[kk])
                adj = pred[j] + (rs / (ws + 1.0) if seen else 0.0)
                if bs is None or adj < bs:
                    best, bs = j, adj
            seen[best] = look(ep, "adaptive", best)
            obs.append(seen[best])
        ad = metrics(obs)
        robs = [look(ep, "random", i) for i in e["random_order"][:10]]
        results.append({"episode": ep, "adaptive": ad, "random": metrics(robs)})
    comps = {}
    for m in ("best5", "best10", "labels_to_target"):
        comps[m] = compare([r["adaptive"][m] for r in results],
                           [r["random"][m] for r in results])
    return {"results": results, "comparisons": comps}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd == "certify":
        sys.stdout.write(json.dumps(certify(a.test)) + "\n")
        return
    names, train = read(a.train)
    if a.cmd == "race":
        test = None
    else:
        tnames, test = read(a.test)
    if a.cmd == "spot":
        sys.stdout.write(json.dumps(spot(names, train, test)) + "\n")
        return
    goals = [(i, 0 if s[-1] == "-" else 1) for i, s in enumerate(names) if s[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        vs = [float(r[i]) for r in train if num(r[i]) is not None]
        n = len(vs)
        mu = sum(vs) / n
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            t += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(t / len(goals))

    if a.cmd == "race":
        out = race(names, train, a.test, goals, stats, score)
    elif a.cmd == "guess":
        out = guess(names, train, test, goals, stats, score)
    elif a.cmd == "flow":
        out = guess(names, train, test, goals, stats, score)
        hist = [score(r) for r in train if all(num(r[i]) is not None for i, _ in goals)]
        out["alerts"] = flow(out["scores"], hist)
    elif a.cmd == "blame":
        out = blame(names, train, test, goals, stats, score)
    elif a.cmd == "justify":
        out = justify(names, train, test, goals, stats, score)
    elif a.cmd == "choose":
        out = choose(names, train, test, goals, stats, score)
    elif a.cmd == "fix":
        out = fix(names, train, test, goals, stats, score)
    else:
        scores = [score(r) for r in test]
        rank = sorted(range(len(scores)), key=lambda i: (scores[i], i))
        out = {"scores": scores, "top": rank[:10], "best": rank[0],
               "median": rank[len(rank) // 2], "worst": rank[-1]}
    sys.stdout.write(json.dumps(out) + "\n")


main()
