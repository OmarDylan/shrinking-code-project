import sys, csv, json, argparse
from math import exp, sqrt, log
from bisect import bisect_left, bisect_right

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def gstats(hn, tr, goals):
    st = {}
    for n, _ in goals:
        i = hn.index(n)
        v = [float(r[i]) for r in tr if r[i] != "?"]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st[n] = (m, sd)
    return st

def d2h(vals, goals, st):
    s = 0.0
    for (n, h), x in zip(goals, vals):
        m, sd = st[n]
        z = max(-3.0, min(3.0, (x - m) / (sd + 1e-32)))
        s += (1 / (1 + exp(-1.702 * z)) - h) ** 2
    return sqrt(s / len(goals))

def remember(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    scores = [d2h([float(r[hs.index(n)]) for n, _ in goals], goals, st) for r in te]
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    print(json.dumps({"scores": scores, "top": order[:10], "best": order[0],
                      "median": order[len(te) // 2], "worst": order[-1]}))

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        if abs(M[c][c]) < 1e-12:
            continue
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                for k in range(c, n + 1):
                    M[r][k] -= f * M[c][k]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]

class Ridge:
    def __init__(self, X, y, lam=1.0):
        d, n = len(X[0]), len(X)
        self.mu = [sum(r[j] for r in X) / n for j in range(d)]
        self.sd = [sqrt(sum((r[j] - self.mu[j]) ** 2 for r in X) / n) or 1.0 for j in range(d)]
        Z = [[(r[j] - self.mu[j]) / self.sd[j] for j in range(d)] for r in X]
        self.ym = sum(y) / n
        yc = [v - self.ym for v in y]
        A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0) for j in range(d)] for i in range(d)]
        b = [sum(z[i] * v for z, v in zip(Z, yc)) for i in range(d)]
        self.w = solve(A, b)
    def __call__(self, x):
        return self.ym + sum(w * (v - m) / s for w, v, m, s in zip(self.w, x, self.mu, self.sd))

def predict(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    ic, iv, im, io = (hn.index(k) for k in ("Clndrs", "Volume", "Model", "origin"))
    tc, tv, tm, to = (hs.index(k) for k in ("Clndrs", "Volume", "Model", "origin"))
    cats = sorted({r[io] for r in tr if r[io] != "?"})
    def col(rows, i):
        return [num(r[i]) for r in rows]
    def mean(v):
        v = [x for x in v if x is not None]
        return sum(v) / len(v)
    dc, dv, dm = mean(col(tr, ic)), mean(col(tr, iv)), mean(col(tr, im))
    def feats(c, v, m, o, usev):
        c = dc if c is None else c
        m = dm if m is None else m
        f = [c, m, c * c] + [1.0 if o == k else 0.0 for k in cats]
        if usev:
            v = dv if v is None else v
            f += [log(max(v, 1.0)), v]
        return f
    def trf(r, usev):
        return feats(num(r[ic]), num(r[iv]), num(r[im]), r[io], usev)
    gi = {n: hn.index(n) for n, _ in goals}
    def tgt(r):
        return [float(r[gi[n]]) for n, _ in goals]
    rows = [r for r in tr if all(r[gi[n]] != "?" for n, _ in goals)]
    Y = [tgt(r) for r in rows]
    D = [d2h(y, goals, st) for y in Y]
    mi = [n for n, _ in goals].index("Mpg+")
    models = {}
    for usev in (True, False):
        X = [trf(r, usev) for r in rows]
        ms = []
        for j in range(len(goals)):
            ys = [log(max(y[j], 1e-6)) if j == mi else y[j] for y in Y]
            ms.append(Ridge(X, ys, 1.0))
        models[usev] = (ms, Ridge(X, D, 1.0))
    mpg, sc = [], []
    for r in te:
        usev = num(r[tv]) is not None
        x = feats(num(r[tc]), num(r[tv]), num(r[tm]), r[to], usev)
        ms, md = models[usev]
        pv = []
        for j, m in enumerate(ms):
            p = m(x)
            pv.append(exp(p) if j == mi else p)
        mpg.append(max(pv[mi], 1e-3))
        s = 0.5 * d2h(pv, goals, st) + 0.5 * md(x)
        sc.append(max(0.0, min(1.0, s)))
    return mpg, sc, D

def guess(a):
    mpg, sc, _ = predict(a)
    print(json.dumps({"mpg": mpg, "scores": sc}))

def compare(xs, ys):
    xs, ys = sorted(float(v) for v in xs), sorted(float(v) for v in ys)
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    tot = 0
    for x in xs:
        tot += bisect_left(ys, x) - (m - bisect_right(ys, x))
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        d = max(d, abs(bisect_right(xs, v) / n - bisect_right(ys, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    same = bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": same}

def certify(a):
    with open(a.test, encoding="utf-8-sig") as f:
        cases = json.load(f)
    print(json.dumps({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}))

def flow(a):
    mpg, sc, hist = predict(a)
    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": alerts}))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd == "remember":
        remember(a)
    elif a.cmd == "guess":
        guess(a)
    elif a.cmd == "certify":
        certify(a)
    elif a.cmd == "flow":
        flow(a)
    else:
        sys.exit("unknown command")

if __name__ == "__main__":
    main()
