import sys, csv, json, argparse
from math import exp, sqrt

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd != "remember":
        sys.exit("unknown command")
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    stats = {}
    for n, _ in goals:
        i = hn.index(n)
        v = [float(r[i]) for r in tr if r[i] != "?"]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        stats[n] = (m, sd)
    scores = []
    for r in te:
        s = 0.0
        for n, h in goals:
            m, sd = stats[n]
            x = float(r[hs.index(n)])
            z = max(-3.0, min(3.0, (x - m) / (sd + 1e-32)))
            nv = 1 / (1 + exp(-1.702 * z))
            s += (nv - h) ** 2
        scores.append(sqrt(s / len(goals)))
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    out = {"scores": scores, "top": order[:10],
           "best": order[0], "median": order[len(te) // 2], "worst": order[-1]}
    print(json.dumps(out))

if __name__ == "__main__":
    main()
