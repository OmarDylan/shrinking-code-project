import sys, csv, json, argparse
from math import exp, sqrt, log
from bisect import bisect_left, bisect_right

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def gstats(hn, tr, goals):
    st = {}
    for n, _ in goals:
        i = hn.index(n)
        v = [float(r[i]) for r in tr if r[i] != "?"]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st[n] = (m, sd)
    return st

def d2h(vals, goals, st):
    s = 0.0
    for (n, h), x in zip(goals, vals):
        m, sd = st[n]
        z = max(-3.0, min(3.0, (x - m) / (sd + 1e-32)))
        s += (1 / (1 + exp(-1.702 * z)) - h) ** 2
    return sqrt(s / len(goals))

def remember(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    scores = [d2h([float(r[hs.index(n)]) for n, _ in goals], goals, st) for r in te]
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    print(json.dumps({"scores": scores, "top": order[:10], "best": order[0],
                      "median": order[len(te) // 2], "worst": order[-1]}))

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        if abs(M[c][c]) < 1e-12:
            continue
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                for k in range(c, n + 1):
                    M[r][k] -= f * M[c][k]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]

class Ridge:
    def __init__(self, X, y, lam=1.0):
        d, n = len(X[0]), len(X)
        self.mu = [sum(r[j] for r in X) / n for j in range(d)]
        self.sd = [sqrt(sum((r[j] - self.mu[j]) ** 2 for r in X) / n) or 1.0 for j in range(d)]
        Z = [[(r[j] - self.mu[j]) / self.sd[j] for j in range(d)] for r in X]
        self.ym = sum(y) / n
        yc = [v - self.ym for v in y]
        A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0) for j in range(d)] for i in range(d)]
        b = [sum(z[i] * v for z, v in zip(Z, yc)) for i in range(d)]
        self.w = solve(A, b)
    def __call__(self, x):
        return self.ym + sum(w * (v - m) / s for w, v, m, s in zip(self.w, x, self.mu, self.sd))

def predict(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    ic, iv, im, io = (hn.index(k) for k in ("Clndrs", "Volume", "Model", "origin"))
    tc, tv, tm, to = (hs.index(k) for k in ("Clndrs", "Volume", "Model", "origin"))
    cats = sorted({r[io] for r in tr if r[io] != "?"})
    def col(rows, i):
        return [num(r[i]) for r in rows]
    def mean(v):
        v = [x for x in v if x is not None]
        return sum(v) / len(v)
    dc, dv, dm = mean(col(tr, ic)), mean(col(tr, iv)), mean(col(tr, im))
    def feats(c, v, m, o, usev):
        c = dc if c is None else c
        m = dm if m is None else m
        f = [c, m, c * c] + [1.0 if o == k else 0.0 for k in cats]
        if usev:
            v = dv if v is None else v
            f += [log(max(v, 1.0)), v]
        return f
    def trf(r, usev):
        return feats(num(r[ic]), num(r[iv]), num(r[im]), r[io], usev)
    gi = {n: hn.index(n) for n, _ in goals}
    def tgt(r):
        return [float(r[gi[n]]) for n, _ in goals]
    rows = [r for r in tr if all(r[gi[n]] != "?" for n, _ in goals)]
    Y = [tgt(r) for r in rows]
    D = [d2h(y, goals, st) for y in Y]
    mi = [n for n, _ in goals].index("Mpg+")
    models = {}
    for usev in (True, False):
        X = [trf(r, usev) for r in rows]
        ms = []
        for j in range(len(goals)):
            ys = [log(max(y[j], 1e-6)) if j == mi else y[j] for y in Y]
            ms.append(Ridge(X, ys, 1.0))
        models[usev] = (ms, Ridge(X, D, 1.0))
    mpg, sc = [], []
    for r in te:
        usev = num(r[tv]) is not None
        x = feats(num(r[tc]), num(r[tv]), num(r[tm]), r[to], usev)
        ms, md = models[usev]
        pv = []
        for j, m in enumerate(ms):
            p = m(x)
            pv.append(exp(p) if j == mi else p)
        mpg.append(max(pv[mi], 1e-3))
        s = 0.5 * d2h(pv, goals, st) + 0.5 * md(x)
        sc.append(max(0.0, min(1.0, s)))
    return mpg, sc, D

def guess(a):
    mpg, sc, _ = predict(a)
    print(json.dumps({"mpg": mpg, "scores": sc}))

def compare(xs, ys):
    xs, ys = sorted(float(v) for v in xs), sorted(float(v) for v in ys)
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    tot = 0
    for x in xs:
        tot += bisect_left(ys, x) - (m - bisect_right(ys, x))
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        d = max(d, abs(bisect_right(xs, v) / n - bisect_right(ys, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    same = bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": same}

def certify(a):
    with open(a.test, encoding="utf-8-sig") as f:
        cases = json.load(f)
    print(json.dumps({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}))

def flow(a):
    mpg, sc, hist = predict(a)
    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": alerts}))

def nrm(v, ms):
    m, sd = ms
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1 / (1 + exp(-1.702 * z))

def diagnose(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    gi = {n: hn.index(n) for n, _ in goals}
    full = [r for r in tr if all(r[gi[n]] != "?" for n, _ in goals)]
    sc = [(round(d2h([float(r[gi[n]]) for n, _ in goals], goals, st), 12), i)
          for i, r in enumerate(full)]
    sc.sort()
    q = max(1, len(full) // 4)
    good = [full[i] for _, i in sc[:q]]
    poor = [full[i] for _, i in sc[-q:]]
    numf = ["Clndrs", "Volume", "Model"]
    cf = "origin"
    prof = {}
    for f in numf:
        i = hn.index(f)
        v = [float(r[i]) for r in tr if num(r[i]) is not None]
        m = sum(v) / len(v) if v else 0.0
        sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        ms = (m, sd)
        def center(g, i=i, m=m, ms=ms):
            w = [float(r[i]) for r in g if num(r[i]) is not None]
            return nrm(sum(w) / len(w) if w else m, ms)
        prof[f] = (ms, center(good), center(poor))
    ci = hn.index(cf)
    def freq(g):
        k = [r[ci] for r in g if r[ci] != "?"]
        d = {}
        for x in k:
            d[x] = d.get(x, 0) + 1
        return {x: c / len(k) for x, c in d.items()}
    fg, fp = freq(good), freq(poor)
    out = []
    for r in te:
        feats = {}
        for f in numf:
            ms, g, p = prof[f]
            x = num(r[hs.index(f)])
            if x is None:
                feats[f] = 0.0
            else:
                nx = nrm(x, ms)
                feats[f] = max(0.0, abs(nx - g) - abs(nx - p))
        o = r[hs.index(cf)]
        feats[cf] = 0.0 if o == "?" else max(0.0, fp.get(o, 0.0) - fg.get(o, 0.0))
        gl = {}
        for n, h in goals:
            v = num(r[hs.index(n)])
            gl[n] = 0.0 if v is None else abs(nrm(v, st[n]) - h)
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gl, "features": feats,
                    "goal_order": key(gl), "feature_order": key(feats)})
    return out

def blame(a):
    print(json.dumps({"diagnoses": diagnose(a)}))

def justify(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    gi = {n: hn.index(n) for n, _ in goals}
    full = [r for r in tr if all(r[gi[n]] != "?" for n, _ in goals)]
    ts = sorted(d2h([float(r[gi[n]]) for n, _ in goals], goals, st) for r in full)
    cutoff = ts[len(ts) // 2]
    scores = [d2h([float(r[hs.index(n)]) for n, _ in goals], goals, st) for r in te]
    dg = diagnose(a)
    N = len(te)
    out = []
    for j in range(N):
        k = (j + 1) % N
        s, o = scores[j], scores[k]
        acc = bool(round(s, 12) <= round(cutoff, 12))
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            gw, gl = dg[win]["goals"], dg[lose]["goals"]
            a_ = {n: gl[n] ** 2 - gw[n] ** 2 for n, _ in goals}
            adv = sorted(a_, key=lambda n: (-round(a_[n], 10), n))[0]
        weak = dg[j]["goal_order"][0]
        fo = dg[j]["feature_order"][0]
        top = fo if dg[j]["features"][fo] > 1e-10 else None
        text = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
                f"other score {o:.3f} (car {k}), cutoff {cutoff:.3f}; "
                f"weakest_goal {weak}. ")
        if win is not None:
            text += f"Recommend car {win} because of advantage_goal {adv}. "
        else:
            text += "The comparison is a tie. "
        if top is not None:
            text += f"Top feature {top} (retrospective, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": text})
    print(json.dumps({"explanations": out}))

def choose(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    _, pred, _ = predict(a)
    N = len(te)
    nf = ["Clndrs", "Volume", "Model"]
    stx = {}
    for f in nf:
        v = [num(r[hn.index(f)]) for r in tr]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
        stx[f] = (m, sd)
    def vec(r):
        return ([num(r[hs.index(f)]) for f in nf], r[hs.index("origin")])
    V = [vec(r) for r in te]
    def xd(i, j):
        s = 0.0
        for f, p, q in zip(nf, V[i][0], V[j][0]):
            if p is None or q is None:
                s += 0.25
            else:
                s += ((p - q) / stx[f][1]) ** 2
        s += 0.0 if V[i][1] == V[j][1] else 1.0
        return sqrt(s / 4)
    K = min(10, N)
    seen = {}
    def inspect(i):
        print(json.dumps({"inspect": i}))
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        g = resp["goals"]
        seen[i] = round(d2h([float(g[n]) for n, _ in goals], goals, st), 12)
    while len(seen) < K:
        left = [i for i in range(N) if i not in seen]
        if len(seen) < 5:
            i = min(left, key=lambda c: (pred[c], c))
        else:
            b = min(seen, key=lambda c: (seen[c], c))
            i = min(left, key=lambda c: (pred[c] + 0.3 * xd(c, b), c))
        inspect(i)
    top = sorted(seen, key=lambda i: (seen[i], i))[:3]
    print(json.dumps({"selected": top}))
    sys.stdout.flush()

def fix(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in hn if n.endswith(("-", "+"))]
    st = gstats(hn, tr, goals)
    gi = {n: hn.index(n) for n, _ in goals}
    nf = ["Clndrs", "Volume", "Model"]
    stx = {}
    for f in nf:
        v = [num(r[hn.index(f)]) for r in tr]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        stx[f] = (m, sd)
    ti = [hn.index(f) for f in nf]
    to = hn.index("origin")
    full = [r for r in tr if all(r[gi[n]] != "?" for n, _ in goals)]
    D = [d2h([float(r[gi[n]]) for n, _ in goals], goals, st) for r in full]
    def xv(vals, o):
        return ([None if v is None else nrm(v, stx[f]) for f, v in zip(nf, vals)], o)
    T = [xv([num(r[i]) for i in ti], r[to]) for r in full]
    def dist(p, q):
        s = 0.0
        for x, y in zip(p[0], q[0]):
            s += 1.0 if x is None or y is None else (x - y) ** 2
        s += 0.0 if p[1] == q[1] else 1.0
        return sqrt(s / 4)
    def pred(p):
        k = min(5, len(T))
        ds = sorted((round(dist(p, t), 12), i) for i, t in enumerate(T))[:k]
        return sum(D[i] for _, i in ds) / k
    cutoff = sorted(D)[len(D) // 2]
    rk = sorted(range(len(D)), key=lambda i: (round(D[i], 12), i))
    q = max(1, len(D) // 4)
    menu, seen = [], set()
    for i in rk[:q]:
        c, v = num(full[i][ti[0]]), num(full[i][ti[1]])
        if c is None or v is None or (c, v) in seen:
            continue
        seen.add((c, v))
        menu.append((c, v))
        if len(menu) == 12:
            break
    out = []
    for idx, r in enumerate(te):
        vals = [num(r[hs.index(f)]) for f in nf]
        o = r[hs.index("origin")]
        p0 = xv(vals, o)
        before = pred(p0)
        res = {"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"}
        if round(before, 10) > round(cutoff, 10):
            res["status"] = "no_candidate"
            best = None
            for c, v in menu:
                ch = int(vals[0] != c) + int(vals[1] != v)
                if ch == 0:
                    continue
                p1 = xv([c, v, vals[2]], o)
                after = pred(p1)
                if round(before - after, 10) >= 0.05:
                    key = (ch, round(dist(p0, p1), 10), round(after, 10), (c, v))
                    if best is None or key < best[0]:
                        best = (key, c, v, after)
            if best:
                _, c, v, after = best
                chg = {}
                if vals[0] != c:
                    chg["Clndrs"] = c
                if vals[1] != v:
                    chg["Volume"] = v
                res.update(after=after, changes=chg, status="improved")
        out.append(res)
    print(json.dumps({"repairs": out}))

def spot(a):
    hn, tr = read(a.train)
    hs, te = read(a.test)
    nf = ["Clndrs", "Volume", "Model"]
    stx = []
    for f in nf:
        v = [x for x in (num(r[hn.index(f)]) for r in tr) if x is not None]
        m = sum(v) / len(v)
        sd = sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
        stx.append((m, sd))
    def vec(r, h):
        return ([num(r[h.index(f)]) for f in nf], r[h.index("origin")])
    T = [vec(r, hn) for r in tr]
    def dist(p, q):
        s, n = 0.0, 0
        for x, y, (_, sd) in zip(p[0], q[0], stx):
            if x is None or y is None:
                continue
            s += ((x - y) / sd) ** 2
            n += 1
        if p[1] != "?" and q[1] != "?":
            s += 0.0 if p[1] == q[1] else 1.0
            n += 1
        return sqrt(s / n) if n else 0.0
    K = 5
    def raw(p, skip=None):
        ds = sorted(dist(p, t) for i, t in enumerate(T) if i != skip)[:K]
        return sum(ds) / len(ds) if ds else 0.0
    ref = sorted(raw(p, i) for i, p in enumerate(T))
    n = len(ref)
    cdf = lambda x: bisect_right(ref, x) / (n + 1)
    scores = [cdf(raw(vec(r, hs))) for r in te]
    thr = 0.95
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    cmds = {"remember": remember, "guess": guess, "certify": certify, "flow": flow,
            "blame": blame, "justify": justify, "choose": choose, "fix": fix,
            "spot": spot}
    if a.cmd in cmds:
        cmds[a.cmd](a)
    else:
        sys.exit("unknown command")

if __name__ == "__main__":
    main()
