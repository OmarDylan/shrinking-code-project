import sys, csv, json, argparse
from math import exp, sqrt

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, tr = read(a.train)
    _, te = read(a.test)
    goals = [(i, n[-1] == "+") for i, n in enumerate(names) if n[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        xs = [float(r[i]) for r in tr]
        n = len(xs)
        mu = sum(xs) / n
        sd = sqrt(sum((x - mu) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        s = 0.0
        for i, mx in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            v = 1 / (1 + exp(-1.702 * z))
            s += (v - (1.0 if mx else 0.0)) ** 2
        return sqrt(s / len(goals))

    scores = [score(r) for r in te]
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    json.dump({"scores": scores, "top": order[:10], "best": order[0],
               "median": order[len(te) // 2], "worst": order[-1]}, sys.stdout)

main()
