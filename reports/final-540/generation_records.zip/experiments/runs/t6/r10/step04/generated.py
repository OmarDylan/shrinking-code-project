import sys, csv, json, argparse
from math import exp, sqrt
from bisect import bisect_left, bisect_right

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def fnum(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    sx, sy = sorted(xs), sorted(ys)
    tot = 0
    for x in sx:
        lt = bisect_left(sy, x)
        gt = m - bisect_right(sy, x)
        tot += lt - gt
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(sx) | set(sy)):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}

def predict(names, tr, tnames, te, goals, score):
    gi = {i for i, _ in goals}
    feats = [i for i, n in enumerate(names) if n[-1] != "X" and i not in gi]
    tpos = {n: j for j, n in enumerate(tnames)}
    isnum = {i: names[i][0].isupper() for i in feats}
    wt = {i: (0.5 if names[i] in ("Model", "origin") else 1.0) for i in feats}

    def getf(r, i, pos):
        if pos is None or pos >= len(r):
            return None
        v = r[pos]
        if v == "?" or v == "":
            return None
        return fnum(v) if isnum[i] else v

    trf = [{i: getf(r, i, i) for i in feats} for r in tr]
    sds = {}
    for i in feats:
        if isnum[i]:
            xs = [f[i] for f in trf if f[i] is not None]
            if len(xs) > 1:
                m = sum(xs) / len(xs)
                sds[i] = sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) or 1.0
            else:
                sds[i] = 1.0
    mpgi = next((i for i, _ in goals if names[i].startswith("Mpg")), goals[-1][0])
    ys = [(float(r[mpgi]), score(r)) for r in tr]
    K = 5
    mpg, sc = [], []
    for r in te:
        q = {i: getf(r, i, tpos.get(names[i])) for i in feats}
        ds = []
        for f, y in zip(trf, ys):
            s = w = 0.0
            for i in feats:
                x, z = q[i], f[i]
                if x is None or z is None:
                    continue
                d = ((x - z) / sds[i]) ** 2 if isnum[i] else (0.0 if x == z else 1.0)
                s += wt[i] * d
                w += wt[i]
            ds.append((sqrt(s / w) if w else 1.0, y))
        ds.sort(key=lambda t: t[0])
        nb = ds[:K]
        ws = [1 / (d + 0.05) for d, _ in nb]
        tw = sum(ws)
        m = sum(w_ * y[0] for w_, (_, y) in zip(ws, nb)) / tw
        s = sum(w_ * y[1] for w_, (_, y) in zip(ws, nb)) / tw
        mpg.append(max(m, 1e-3))
        sc.append(min(1.0, max(0.0, s)))
    return mpg, sc

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()

    if a.cmd == "certify":
        with open(a.test, encoding="utf-8-sig") as f:
            cases = json.load(f)
        json.dump({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}, sys.stdout)
        return

    names, tr = read(a.train)
    tnames, te = read(a.test)
    goals = [(i, n[-1] == "+") for i, n in enumerate(names) if n[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        xs = [float(r[i]) for r in tr]
        n = len(xs)
        mu = sum(xs) / n
        sd = sqrt(sum((x - mu) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        s = 0.0
        for i, mx in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            v = 1 / (1 + exp(-1.702 * z))
            s += (v - (1.0 if mx else 0.0)) ** 2
        return sqrt(s / len(goals))

    if a.cmd == "guess":
        mpg, sc = predict(names, tr, tnames, te, goals, score)
        json.dump({"mpg": mpg, "scores": sc}, sys.stdout)
        return

    if a.cmd == "flow":
        mpg, sc = predict(names, tr, tnames, te, goals, score)
        hist = [score(r) for r in tr]
        W = 20
        alerts = []
        for k in range(len(sc)):
            if k < W - 1 or len(hist) < 2:
                alerts.append(False)
            else:
                alerts.append(not compare(hist, sc[k - W + 1:k + 1])["same"])
        json.dump({"mpg": mpg, "scores": sc, "alerts": alerts}, sys.stdout)
        return

    scores = [score(r) for r in te]
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    json.dump({"scores": scores, "top": order[:10], "best": order[0],
               "median": order[len(te) // 2], "worst": order[-1]}, sys.stdout)

main()
