import sys, csv, json, argparse
from math import exp, sqrt
from bisect import bisect_left, bisect_right

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def fnum(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def nrm(mu, sd, v):
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + exp(-1.702 * z))

def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    sx, sy = sorted(xs), sorted(ys)
    tot = 0
    for x in sx:
        lt = bisect_left(sy, x)
        gt = m - bisect_right(sy, x)
        tot += lt - gt
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(sx) | set(sy)):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}

def predict(names, tr, tnames, te, goals, score):
    gi = {i for i, _ in goals}
    feats = [i for i, n in enumerate(names) if n[-1] != "X" and i not in gi]
    tpos = {n: j for j, n in enumerate(tnames)}
    isnum = {i: names[i][0].isupper() for i in feats}
    wt = {i: (0.5 if names[i] in ("Model", "origin") else 1.0) for i in feats}

    def getf(r, i, pos):
        if pos is None or pos >= len(r):
            return None
        v = r[pos]
        if v == "?" or v == "":
            return None
        return fnum(v) if isnum[i] else v

    trf = [{i: getf(r, i, i) for i in feats} for r in tr]
    sds = {}
    for i in feats:
        if isnum[i]:
            xs = [f[i] for f in trf if f[i] is not None]
            if len(xs) > 1:
                m = sum(xs) / len(xs)
                sds[i] = sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) or 1.0
            else:
                sds[i] = 1.0
    mpgi = next((i for i, _ in goals if names[i].startswith("Mpg")), goals[-1][0])
    ys = [(float(r[mpgi]), score(r)) for r in tr]
    K = 5
    mpg, sc = [], []
    for r in te:
        q = {i: getf(r, i, tpos.get(names[i])) for i in feats}
        ds = []
        for f, y in zip(trf, ys):
            s = w = 0.0
            for i in feats:
                x, z = q[i], f[i]
                if x is None or z is None:
                    continue
                d = ((x - z) / sds[i]) ** 2 if isnum[i] else (0.0 if x == z else 1.0)
                s += wt[i] * d
                w += wt[i]
            ds.append((sqrt(s / w) if w else 1.0, y))
        ds.sort(key=lambda t: t[0])
        nb = ds[:K]
        ws = [1 / (d + 0.05) for d, _ in nb]
        tw = sum(ws)
        m = sum(w_ * y[0] for w_, (_, y) in zip(ws, nb)) / tw
        s = sum(w_ * y[1] for w_, (_, y) in zip(ws, nb)) / tw
        mpg.append(max(m, 1e-3))
        sc.append(min(1.0, max(0.0, s)))
    return mpg, sc

def blame(names, tr, tnames, te, goals, stats, score):
    gi = {i for i, _ in goals}
    feats = [i for i, n in enumerate(names) if n[-1] != "X" and i not in gi]
    tpos = {n: j for j, n in enumerate(tnames)}
    isnum = {i: names[i][0].isupper() for i in feats}

    def val(r, pos):
        if pos is None or pos >= len(r) or r[pos] in ("?", ""):
            return None
        return r[pos]

    d2h = [round(score(r), 12) for r in tr]
    order = sorted(range(len(tr)), key=lambda k: (d2h[k], k))
    q = max(1, len(tr) // 4)
    good = [tr[k] for k in order[:q]]
    poor = [tr[k] for k in order[-q:]]

    info = {}
    for i in feats:
        if isnum[i]:
            xs = [fnum(r[i]) for r in tr if val(r, i) is not None]
            xs = [x for x in xs if x is not None]
            n = len(xs)
            mu = sum(xs) / n if n else 0.0
            sd = sqrt(sum((x - mu) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0
            cs = []
            for g in (good, poor):
                gx = [fnum(r[i]) for r in g if val(r, i) is not None]
                gx = [x for x in gx if x is not None]
                cs.append(nrm(mu, sd, sum(gx) / len(gx)) if gx else None)
            info[i] = (mu, sd, cs[0], cs[1])
        else:
            fr = []
            for g in (good, poor):
                kn = [r[i] for r in g if val(r, i) is not None]
                c = {}
                for v in kn:
                    c[v] = c.get(v, 0) + 1
                fr.append((c, len(kn)))
            info[i] = fr

    def ordr(d):
        return [k for k, _ in sorted(d.items(), key=lambda t: (-round(t[1], 10), t[0]))]

    out = []
    for r in te:
        gl = {}
        for i, mx in goals:
            mu, sd = stats[i]
            gl[names[i]] = abs(nrm(mu, sd, float(r[tpos[names[i]]])) - (1.0 if mx else 0.0))
        ft = {}
        for i in feats:
            v = val(r, tpos.get(names[i]))
            e = 0.0
            if v is not None:
                if isnum[i]:
                    x = fnum(v)
                    mu, sd, gc, pc = info[i]
                    if x is not None and gc is not None and pc is not None:
                        nx = nrm(mu, sd, x)
                        e = max(0.0, abs(nx - gc) - abs(nx - pc))
                else:
                    (gc, gn), (pc, pn) = info[i]
                    pf = pc.get(v, 0) / pn if pn else 0.0
                    gf = gc.get(v, 0) / gn if gn else 0.0
                    e = max(0.0, pf - gf)
            ft[names[i]] = e
        out.append({"goals": gl, "features": ft,
                    "goal_order": ordr(gl), "feature_order": ordr(ft)})
    return out

def justify(names, tr, tnames, te, goals, stats, score):
    diag = blame(names, tr, tnames, te, goals, stats, score)
    tpos = {n: j for j, n in enumerate(tnames)}
    ts = [score(r) for r in te]
    cut = sorted(score(r) for r in tr)[len(tr) // 2]
    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = ts[j], ts[k]
        acc = round(s, 12) <= round(cut, 12)
        if round(s, 12) == round(o, 12):
            win = None
        else:
            win = j if s < o else k
        adv_goal = None
        if win is not None:
            lose = k if win == j else j
            adv = {g: diag[lose]["goals"][g] ** 2 - diag[win]["goals"][g] ** 2
                   for g in diag[j]["goals"]}
            adv_goal = sorted(adv.items(), key=lambda t: (-round(t[1], 10), t[0]))[0][0]
        weak = diag[j]["goal_order"][0]
        fo = diag[j]["feature_order"][0] if diag[j]["feature_order"] else None
        top = fo if fo is not None and diag[j]["features"][fo] > 1e-10 else None
        text = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
                f"other score {o:.3f}, cutoff {cut:.3f}; weakest goal {weak}. ")
        if win is not None:
            text += f"Recommend car {win} because of {adv_goal}. "
        else:
            text += "The comparison is a tie. "
        if top is not None:
            text += f"Top feature: {top}. "
        text += "Retrospective association, not causation."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cut, "accepted": bool(acc), "winner": win,
                    "advantage_goal": adv_goal, "weakest_goal": weak,
                    "top_feature": top, "text": text})
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()

    if a.cmd == "certify":
        with open(a.test, encoding="utf-8-sig") as f:
            cases = json.load(f)
        json.dump({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}, sys.stdout)
        return

    names, tr = read(a.train)
    tnames, te = read(a.test)
    goals = [(i, n[-1] == "+") for i, n in enumerate(names) if n[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        xs = [float(r[i]) for r in tr]
        n = len(xs)
        mu = sum(xs) / n
        sd = sqrt(sum((x - mu) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)

    def score(r):
        s = 0.0
        for i, mx in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            v = 1 / (1 + exp(-1.702 * z))
            s += (v - (1.0 if mx else 0.0)) ** 2
        return sqrt(s / len(goals))

    if a.cmd == "guess":
        mpg, sc = predict(names, tr, tnames, te, goals, score)
        json.dump({"mpg": mpg, "scores": sc}, sys.stdout)
        return

    if a.cmd == "flow":
        mpg, sc = predict(names, tr, tnames, te, goals, score)
        hist = [score(r) for r in tr]
        W = 20
        alerts = []
        for k in range(len(sc)):
            if k < W - 1 or len(hist) < 2:
                alerts.append(False)
            else:
                alerts.append(not compare(hist, sc[k - W + 1:k + 1])["same"])
        json.dump({"mpg": mpg, "scores": sc, "alerts": alerts}, sys.stdout)
        return

    if a.cmd == "blame":
        json.dump({"diagnoses": blame(names, tr, tnames, te, goals, stats, score)}, sys.stdout)
        return

    if a.cmd == "justify":
        json.dump({"explanations": justify(names, tr, tnames, te, goals, stats, score)}, sys.stdout)
        return

    scores = [score(r) for r in te]
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    json.dump({"scores": scores, "top": order[:10], "best": order[0],
               "median": order[len(te) // 2], "worst": order[-1]}, sys.stdout)

main()
