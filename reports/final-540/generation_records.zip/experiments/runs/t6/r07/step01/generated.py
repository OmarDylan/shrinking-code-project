import sys, csv, json, math

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def main():
    a = sys.argv[1:]
    if not a or a[0] != "remember":
        sys.exit(1)
    train = test = None
    i = 1
    while i < len(a):
        if a[i] == "--train": train = a[i + 1]; i += 2
        elif a[i] == "--test": test = a[i + 1]; i += 2
        else: i += 1
    hn, tr = load(train)
    hn2, te = load(test)
    goals = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    stats = {}
    for j, _ in goals:
        v = [float(r[j]) for r in tr]
        n = len(v)
        mu = sum(v) / n
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
        stats[j] = (mu, sd)
    idx2 = {n: j for j, n in enumerate(hn2)}
    scores = []
    for r in te:
        s = 0.0
        for j, h in goals:
            mu, sd = stats[j]
            v = float(r[idx2[hn[j]]])
            z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        scores.append(math.sqrt(s / len(goals)))
    order = sorted(range(len(scores)), key=lambda k: (scores[k], k))
    print(json.dumps({"scores": scores, "top": order[:10], "best": order[0],
                      "median": order[len(order) // 2], "worst": order[-1]}))

main()
