import sys, csv, json, math
from bisect import bisect_left, bisect_right

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def args():
    a = sys.argv[1:]
    d = {}
    for i, x in enumerate(a):
        if x in ("--train", "--test") and i + 1 < len(a):
            d[x[2:]] = a[i + 1]
    return a[0] if a else "", d

def goal_stats(hn, tr):
    goals = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    stats = {}
    for j, _ in goals:
        v = [float(r[j]) for r in tr]
        n = len(v)
        mu = sum(v) / n
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
        stats[j] = (mu, sd)
    return goals, stats

def d2h(vals, goals, stats):
    s = 0.0
    for (j, h), v in zip(goals, vals):
        mu, sd = stats[j]
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
    return math.sqrt(s / len(goals))

def remember(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals, stats = goal_stats(hn, tr)
    idx2 = {n: j for j, n in enumerate(hn2)}
    scores = [d2h([float(r[idx2[hn[j]]]) for j, _ in goals], goals, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda k: (scores[k], k))
    print(json.dumps({"scores": scores, "top": order[:10], "best": order[0],
                      "median": order[len(order) // 2], "worst": order[-1]}))

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError):
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for r in range(n):
            if r != i:
                f = M[r][i] / d
                if f:
                    M[r] = [x - f * y for x, y in zip(M[r], M[i])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

def ridge(X, y, lam=1.0):
    k = len(X[0]) + 1
    A = [[0.0] * k for _ in range(k)]
    b = [0.0] * k
    for x, t in zip(X, y):
        x = [1.0] + x
        for i in range(k):
            b[i] += x[i] * t
            for j in range(k):
                A[i][j] += x[i] * x[j]
    for i in range(1, k):
        A[i][i] += lam
    w = solve(A, b)
    return lambda x: w[0] + sum(c * v for c, v in zip(w[1:], x))

def predict(a):
    """Shared by guess, flow, choose: returns (mpg, scores, training d2h history)."""
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals, stats = goal_stats(hn, tr)
    col = {n: j for j, n in enumerate(hn)}
    c2 = {n: j for j, n in enumerate(hn2)}
    def get(r, n, tab=None):
        j = (tab or col).get(n)
        return num(r[j]) if j is not None and j < len(r) else None
    mj = next(j for j, n in enumerate(hn) if n.startswith("Mpg"))
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals)]
    names = ["Clndrs", "Volume", "Model"]
    mean = {}; sdv = {}
    for n in names:
        v = [x for x in (get(r, n) for r in tr) if x is not None]
        mu = sum(v) / len(v)
        mean[n] = mu
        sdv[n] = math.sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
    oi = col["origin"]
    orgs = sorted({r[oi] for r in tr if r[oi] != "?"})
    def feats(r, tab, vol):
        out = []
        for n in names:
            if n == "Volume" and not vol:
                continue
            x = get(r, n, tab)
            if x is None:
                x = mean[n]
            out.append((x - mean[n]) / sdv[n])
        if vol:
            x = get(r, "Volume", tab)
            if x is None: x = mean["Volume"]
            out.append(math.log(max(x, 1.0) / max(mean["Volume"], 1.0)))
        j = tab.get("origin")
        o = r[j] if j is not None and j < len(r) else "?"
        out += [1.0 if o == g else 0.0 for g in orgs]
        return out
    ys = [d2h([float(r[j]) for j, _ in goals], goals, stats) for r in tr]
    lm = [math.log(max(float(r[mj]), 1e-3)) for r in tr]
    models = {}
    for vol in (True, False):
        X = [feats(r, col, vol) for r in tr]
        models[vol] = (ridge(X, lm, 1.0), ridge(X, ys, 1.0))
    mpg, sc = [], []
    for r in te:
        vol = get(r, "Volume", c2) is not None
        x = feats(r, c2, vol)
        fm, fd = models[vol]
        mpg.append(max(1e-3, min(100.0, math.exp(fm(x)))))
        sc.append(max(0.0, min(1.0, fd(x))))
    return mpg, sc, ys

def guess(a):
    mpg, sc, _ = predict(a)
    print(json.dumps({"mpg": mpg, "scores": sc}))

def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)
    sy = sorted(ys)
    sx = sorted(xs)
    tot = 0
    for x in xs:
        lo = bisect_left(sy, x)
        hi = bisect_right(sy, x)
        tot += lo - (m - hi)
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    same = bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": same}

def certify(a):
    with open(a["test"], encoding="utf-8-sig") as f:
        cases = json.load(f)
    print(json.dumps({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}))

def flow(a):
    mpg, sc, hist = predict(a)
    alerts = []
    for i in range(len(sc)):
        if i < 19 or len(hist) < 2:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": alerts}))

def nrm(v, mu, sd):
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def blame_data(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals0 = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals0)]
    goals, stats = goal_stats(hn, tr)
    col = {n: j for j, n in enumerate(hn)}
    c2 = {n: j for j, n in enumerate(hn2)}
    ys = [d2h([float(r[j]) for j, _ in goals], goals, stats) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(ys[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    nums = ["Clndrs", "Volume", "Model"]
    cat = "origin"
    ns = {}
    for n in nums:
        v = [x for x in (num(r[col[n]]) for r in tr) if x is not None]
        if not v:
            continue
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        def center(g, n=n, mu=mu, sd=sd):
            w = [x for x in (num(r[col[n]]) for r in g) if x is not None]
            return nrm(sum(w) / len(w), mu, sd) if w else None
        ns[n] = (mu, sd, center(good), center(poor))
    def freq(g):
        w = [r[col[cat]] for r in g if r[col[cat]] != "?"]
        f = {}
        for x in w:
            f[x] = f.get(x, 0) + 1
        return {k: c / len(w) for k, c in f.items()}
    fg, fp = freq(good), freq(poor)
    out = []
    for r in te:
        goalsd = {}
        for j, h in goals:
            name = hn[j]
            k = c2.get(name)
            v = num(r[k]) if k is not None and k < len(r) else None
            mu, sd = stats[j]
            goalsd[name] = abs(nrm(v, mu, sd) - h) if v is not None else 0.0
        feat = {}
        for n in nums:
            k = c2.get(n)
            x = num(r[k]) if k is not None and k < len(r) else None
            e = 0.0
            if x is not None and n in ns:
                mu, sd, cg, cp = ns[n]
                if cg is not None and cp is not None:
                    nx = nrm(x, mu, sd)
                    e = max(0.0, abs(nx - cg) - abs(nx - cp))
            feat[n] = e
        k = c2.get(cat)
        o = r[k] if k is not None and k < len(r) else "?"
        feat[cat] = 0.0 if o == "?" else max(0.0, fp.get(o, 0.0) - fg.get(o, 0.0))
        so = lambda d: [n for n in sorted(d, key=lambda n: (-round(d[n], 10), n))]
        out.append({"goals": goalsd, "features": feat,
                    "goal_order": so(goalsd), "feature_order": so(feat)})
    return out

def blame(a):
    print(json.dumps({"diagnoses": blame_data(a)}))

def justify(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals0 = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals0)]
    goals, stats = goal_stats(hn, tr)
    idx2 = {n: j for j, n in enumerate(hn2)}
    tys = sorted(d2h([float(r[j]) for j, _ in goals], goals, stats) for r in tr)
    cutoff = tys[len(tys) // 2]
    scores = [d2h([float(r[idx2[hn[j]]]) for j, _ in goals], goals, stats) for r in te]
    diag = blame_data(a)
    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        acc = bool(round(s, 12) <= round(cutoff, 12))
        win = None
        adv = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
            los = k if win == j else j
            gw, gl = diag[win]["goals"], diag[los]["goals"]
            ad = {g: gl[g] ** 2 - gw[g] ** 2 for g in gw}
            adv = sorted(ad, key=lambda g: (-round(ad[g], 10), g))[0]
        d = diag[j]
        weak = d["goal_order"][0]
        tf = d["feature_order"][0]
        top = tf if d["features"][tf] > 1e-10 else None
        text = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
                f"other score {o:.3f} (car {k}), cutoff {cutoff:.3f}. "
                f"Weakest goal: {weak}. ")
        if win is not None:
            text += f"Recommend car {win}; advantage goal: {adv}. "
        else:
            text += "The comparison is a tie. "
        if top is not None:
            text += f"Top feature: {top}. "
        text += "This is a retrospective association, not a causal claim."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": text})
    print(json.dumps({"explanations": out}))

def choose(a):
    hn, tr = load(a["train"])
    _, te = load(a["test"])
    goals0 = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals0)]
    goals, stats = goal_stats(hn, tr)
    _, sc, _ = predict(a)
    n = len(te)
    cand = sorted(range(n), key=lambda i: (sc[i], i))[:min(10, n)]
    seen = {}
    for i in cand:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        g = resp["goals"]
        vals = [float(g[hn[j]]) for j, _ in goals]
        seen[i] = d2h(vals, goals, stats)
    top = sorted(seen, key=lambda i: (round(seen[i], 12), i))[:3]
    print(json.dumps({"selected": top}), flush=True)

def fix(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals0 = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals0)]
    goals, stats = goal_stats(hn, tr)
    col = {n: j for j, n in enumerate(hn)}
    c2 = {n: j for j, n in enumerate(hn2)}
    nums = ["Clndrs", "Volume", "Model"]
    ns = {}
    for n in nums:
        v = [x for x in (num(r[col[n]]) for r in tr) if x is not None]
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        ns[n] = (mu, sd)
    def mk(r, tab):
        """row -> [Clndrs, Volume, Model] raw values (or None), origin."""
        vals = []
        for n in nums:
            j = tab.get(n)
            vals.append(num(r[j]) if j is not None and j < len(r) else None)
        j = tab.get("origin")
        o = r[j] if j is not None and j < len(r) else "?"
        return vals, o
    def nz(vals):
        return [None if v is None else nrm(v, *ns[n]) for n, v in zip(nums, vals)]
    def dist(x, ox, y, oy):
        s = 0.0
        for p, q in zip(x, y):
            g = 1.0 if p is None or q is None else p - q
            s += g * g
        g = 1.0 if (ox == "?" or oy == "?") else (0.0 if ox == oy else 1.0)
        s += g * g
        return math.sqrt(s / 4)
    ys = [d2h([float(r[j]) for j, _ in goals], goals, stats) for r in tr]
    T = []
    for r in tr:
        v, o = mk(r, col)
        T.append((v, nz(v), o))
    def pred(xn, o):
        ds = sorted(range(len(T)), key=lambda i: (round(dist(xn, o, T[i][1], T[i][2]), 12), i))
        k = ds[:5]
        return sum(ys[i] for i in k) / len(k)
    cutoff = sorted(ys)[len(ys) // 2]
    order = sorted(range(len(tr)), key=lambda i: (round(ys[i], 12), i))
    q = max(1, len(tr) // 4)
    menu = []
    for i in order[:q]:
        p = (T[i][0][0], T[i][0][1])
        if p not in menu:
            menu.append(p)
        if len(menu) >= 12:
            break
    out = []
    for idx, r in enumerate(te):
        v, o = mk(r, c2)
        xn = nz(v)
        before = pred(xn, o)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "already_good"})
            continue
        best = None
        for (nc, nv) in menu:
            ch = {}
            if v[0] != nc:
                ch["Clndrs"] = nc
            if v[1] != nv:
                ch["Volume"] = nv
            if not ch:
                continue
            ev = [nc, nv, v[2]]
            en = nz(ev)
            after = pred(en, o)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(xn, o, en, o), 10), round(after, 10), (nc, nv))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best is None:
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "no_candidate"})
        else:
            out.append({"row": idx, "before": before, "after": best[1],
                        "changes": {k: float(x) for k, x in best[2].items()},
                        "status": "improved"})
    print(json.dumps({"repairs": out}))

def main():
    cmd, a = args()
    if cmd == "remember" and "train" in a and "test" in a:
        remember(a)
    elif cmd == "guess" and "train" in a and "test" in a:
        guess(a)
    elif cmd == "certify" and "test" in a:
        certify(a)
    elif cmd == "flow" and "train" in a and "test" in a:
        flow(a)
    elif cmd == "blame" and "train" in a and "test" in a:
        blame(a)
    elif cmd == "justify" and "train" in a and "test" in a:
        justify(a)
    elif cmd == "choose" and "train" in a and "test" in a:
        choose(a)
    elif cmd == "fix" and "train" in a and "test" in a:
        fix(a)
    else:
        sys.exit(1)

main()
