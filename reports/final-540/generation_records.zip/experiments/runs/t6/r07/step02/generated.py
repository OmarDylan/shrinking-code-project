import sys, csv, json, math

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def args():
    a = sys.argv[1:]
    d = {}
    for i, x in enumerate(a):
        if x in ("--train", "--test") and i + 1 < len(a):
            d[x[2:]] = a[i + 1]
    return a[0] if a else "", d

def goal_stats(hn, tr):
    goals = [(j, 0 if n.endswith("-") else 1) for j, n in enumerate(hn) if n.endswith(("+", "-"))]
    stats = {}
    for j, _ in goals:
        v = [float(r[j]) for r in tr]
        n = len(v)
        mu = sum(v) / n
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
        stats[j] = (mu, sd)
    return goals, stats

def d2h(vals, goals, stats):
    s = 0.0
    for (j, h), v in zip(goals, vals):
        mu, sd = stats[j]
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
    return math.sqrt(s / len(goals))

def remember(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals, stats = goal_stats(hn, tr)
    idx2 = {n: j for j, n in enumerate(hn2)}
    scores = [d2h([float(r[idx2[hn[j]]]) for j, _ in goals], goals, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda k: (scores[k], k))
    print(json.dumps({"scores": scores, "top": order[:10], "best": order[0],
                      "median": order[len(order) // 2], "worst": order[-1]}))

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError):
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for r in range(n):
            if r != i:
                f = M[r][i] / d
                if f:
                    M[r] = [x - f * y for x, y in zip(M[r], M[i])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

def ridge(X, y, lam=1.0):
    k = len(X[0]) + 1
    A = [[0.0] * k for _ in range(k)]
    b = [0.0] * k
    for x, t in zip(X, y):
        x = [1.0] + x
        for i in range(k):
            b[i] += x[i] * t
            for j in range(k):
                A[i][j] += x[i] * x[j]
    for i in range(1, k):
        A[i][i] += lam
    w = solve(A, b)
    return lambda x: w[0] + sum(c * v for c, v in zip(w[1:], x))

def guess(a):
    hn, tr = load(a["train"])
    hn2, te = load(a["test"])
    goals, stats = goal_stats(hn, tr)
    col = {n: j for j, n in enumerate(hn)}
    c2 = {n: j for j, n in enumerate(hn2)}
    def get(r, n, tab=None):
        j = (tab or col).get(n)
        return num(r[j]) if j is not None and j < len(r) else None
    mj = next(j for j, n in enumerate(hn) if n.startswith("Mpg"))
    tr = [r for r in tr if all(num(r[j]) is not None for j, _ in goals)]
    names = ["Clndrs", "Volume", "Model"]
    mean = {}; sdv = {}
    for n in names:
        v = [x for x in (get(r, n) for r in tr) if x is not None]
        mu = sum(v) / len(v)
        mean[n] = mu
        sdv[n] = math.sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
    oi = col["origin"]
    orgs = sorted({r[oi] for r in tr if r[oi] != "?"})
    def feats(r, tab, vol):
        out = []
        for n in names:
            if n == "Volume" and not vol:
                continue
            x = get(r, n, tab)
            if x is None:
                x = mean[n]
            out.append((x - mean[n]) / sdv[n])
        if vol:
            x = get(r, "Volume", tab)
            if x is None: x = mean["Volume"]
            out.append(math.log(max(x, 1.0) / max(mean["Volume"], 1.0)))
        j = tab.get("origin")
        o = r[j] if j is not None and j < len(r) else "?"
        out += [1.0 if o == g else 0.0 for g in orgs]
        return out
    ys = [d2h([float(r[j]) for j, _ in goals], goals, stats) for r in tr]
    lm = [math.log(max(float(r[mj]), 1e-3)) for r in tr]
    models = {}
    for vol in (True, False):
        X = [feats(r, col, vol) for r in tr]
        models[vol] = (ridge(X, lm, 1.0), ridge(X, ys, 1.0))
    mpg, sc = [], []
    for i, r in enumerate(te):
        vol = get(r, "Volume", c2) is not None and i % 2 == 1 or (get(r, "Volume", c2) is not None and i % 2 == 0 and False)
        vol = get(r, "Volume", c2) is not None
        x = feats(r, c2, vol)
        fm, fd = models[vol]
        mpg.append(max(1e-3, min(100.0, math.exp(fm(x)))))
        sc.append(max(0.0, min(1.0, fd(x))))
    print(json.dumps({"mpg": mpg, "scores": sc}))

def main():
    cmd, a = args()
    if cmd == "remember" and "train" in a and "test" in a:
        remember(a)
    elif cmd == "guess" and "train" in a and "test" in a:
        guess(a)
    else:
        sys.exit(1)

main()
