import sys, csv, json, argparse
from bisect import bisect_left, bisect_right
from math import exp, sqrt, log


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]


def goal_stats(vs):
    n = len(vs)
    mu = sum(vs) / n
    sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
    return mu, sd


def d2h_of(vals, stats, goals):
    s = 0.0
    for v, (mu, sd), (_, h) in zip(vals, stats, goals):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        s += (1 / (1 + exp(-1.702 * z)) - h) ** 2
    return sqrt(s / len(goals))


def remember(a):
    names, train = load(a.train)
    tnames, test = load(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi_tr = [names.index(n) for n, _ in goals]
    gi_te = [tnames.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi_tr]
    scores = [d2h_of([float(r[i]) for i in gi_te], stats, goals) for r in test]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                f = M[r][c] / d
                if f:
                    M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]


class Ridge:
    def __init__(self, X, y, lam=0.5):
        p = len(X[0])
        self.mu = [sum(r[j] for r in X) / len(X) for j in range(p)]
        self.sd = [sqrt(sum((r[j] - self.mu[j]) ** 2 for r in X) / len(X)) or 1.0 for j in range(p)]
        Z = [[1.0] + [(r[j] - self.mu[j]) / self.sd[j] for j in range(p)] for r in X]
        q = p + 1
        A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j and i > 0 else 0.0) for j in range(q)] for i in range(q)]
        b = [sum(z[i] * t for z, t in zip(Z, y)) for i in range(q)]
        self.w = solve(A, b)

    def __call__(self, x):
        z = [1.0] + [(v - m) / s for v, m, s in zip(x, self.mu, self.sd)]
        return sum(w * v for w, v in zip(self.w, z))


def guess(a):
    names, train = load(a.train)
    tnames, test = load(a.test)
    base = lambda n: n.rstrip("+-X")
    col = {base(n): i for i, n in enumerate(names)}
    tcol = {base(n): i for i, n in enumerate(tnames)}
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]

    def num(r, c, k):
        j = c.get(k)
        if j is None or j >= len(r) or r[j] in ("?", ""):
            return None
        try:
            return float(r[j])
        except ValueError:
            return None

    def cat(r, c):
        j = c.get("origin")
        return r[j] if j is not None and j < len(r) else "?"

    cats = sorted({cat(r, col) for r in train})
    nk = ["Clndrs", "Volume", "Model"]
    means = {k: sum(v for v in (num(r, col, k) for r in train) if v is not None) /
             max(1, sum(1 for r in train if num(r, col, k) is not None)) for k in nk}

    def feats(r, c, vol):
        f = []
        for k in nk:
            if k == "Volume" and not vol:
                continue
            v = num(r, c, k)
            f.append(means[k] if v is None else v)
        o = cat(r, c)
        f += [1.0 if o == x else 0.0 for x in cats]
        return f

    # per-goal transform: log for positive-skewed goals
    tf = []
    for (n, _), i in zip(goals, gi):
        pos = all(float(r[i]) > 0 for r in train)
        tf.append(pos)
    ys = [[(log(float(r[i])) if pos else float(r[i])) for r in train] for i, pos in zip(gi, tf)]
    models = {}
    for vol in (True, False):
        X = [feats(r, col, vol) for r in train]
        models[vol] = [Ridge(X, y) for y in ys]

    mi = next(k for k, (n, _) in enumerate(goals) if base(n) == "Mpg")
    mpg, scores = [], []
    for r in test:
        vol = num(r, tcol, "Volume") is not None
        x = feats(r, tcol, vol)
        vals = []
        for m, pos in zip(models[vol], tf):
            p = m(x)
            vals.append(exp(p) if pos else p)
        mp = vals[mi]
        if not (mp > 0) or mp != mp or mp == float("inf"):
            mp = stats[mi][0]
        vals[mi] = mp
        mpg.append(mp)
        scores.append(max(0.0, min(1.0, d2h_of(vals, stats, goals))))
    return {"mpg": mpg, "scores": scores}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    sx, sy = sorted(xs), sorted(ys)
    tot = 0
    for x in xs:
        tot += bisect_left(sy, x) - (m - bisect_right(sy, x))
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in set(sx) | set(sy):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    same = bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": same}


def certify(a):
    with open(a.test, encoding="utf-8-sig") as f:
        cases = json.load(f)
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd == "remember":
        out = remember(a)
    elif a.cmd == "guess":
        out = guess(a)
    elif a.cmd == "certify":
        out = certify(a)
    else:
        sys.exit("unknown command")
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
