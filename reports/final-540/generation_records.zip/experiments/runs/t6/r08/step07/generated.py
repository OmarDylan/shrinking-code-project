import sys, csv, json, argparse, random
from bisect import bisect_left, bisect_right
from math import exp, sqrt, log


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]


def goal_stats(vs):
    n = len(vs)
    mu = sum(vs) / n
    sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
    return mu, sd


def nz(v, st):
    z = max(-3.0, min(3.0, (v - st[0]) / (st[1] + 1e-32)))
    return 1 / (1 + exp(-1.702 * z))


def d2h_of(vals, stats, goals):
    s = 0.0
    for v, (mu, sd), (_, h) in zip(vals, stats, goals):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        s += (1 / (1 + exp(-1.702 * z)) - h) ** 2
    return sqrt(s / len(goals))


def remember(a):
    names, train = load(a.train)
    tnames, test = load(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi_tr = [names.index(n) for n, _ in goals]
    gi_te = [tnames.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi_tr]
    scores = [d2h_of([float(r[i]) for i in gi_te], stats, goals) for r in test]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                f = M[r][c] / d
                if f:
                    M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]


class Ridge:
    def __init__(self, X, y, lam=0.5):
        p = len(X[0])
        self.mu = [sum(r[j] for r in X) / len(X) for j in range(p)]
        self.sd = [sqrt(sum((r[j] - self.mu[j]) ** 2 for r in X) / len(X)) or 1.0 for j in range(p)]
        Z = [[1.0] + [(r[j] - self.mu[j]) / self.sd[j] for j in range(p)] for r in X]
        q = p + 1
        A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j and i > 0 else 0.0) for j in range(q)] for i in range(q)]
        b = [sum(z[i] * t for z, t in zip(Z, y)) for i in range(q)]
        self.w = solve(A, b)

    def __call__(self, x):
        z = [1.0] + [(v - m) / s for v, m, s in zip(x, self.mu, self.sd)]
        return sum(w * v for w, v in zip(self.w, z))


def guess(a):
    names, train = load(a.train)
    tnames, test = load(a.test)
    base = lambda n: n.rstrip("+-X")
    col = {base(n): i for i, n in enumerate(names)}
    tcol = {base(n): i for i, n in enumerate(tnames)}
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]

    def num(r, c, k):
        j = c.get(k)
        if j is None or j >= len(r) or r[j] in ("?", ""):
            return None
        try:
            return float(r[j])
        except ValueError:
            return None

    def cat(r, c):
        j = c.get("origin")
        return r[j] if j is not None and j < len(r) else "?"

    cats = sorted({cat(r, col) for r in train})
    nk = ["Clndrs", "Volume", "Model"]
    means = {k: sum(v for v in (num(r, col, k) for r in train) if v is not None) /
             max(1, sum(1 for r in train if num(r, col, k) is not None)) for k in nk}

    def feats(r, c, vol):
        f = []
        for k in nk:
            if k == "Volume" and not vol:
                continue
            v = num(r, c, k)
            f.append(means[k] if v is None else v)
        o = cat(r, c)
        f += [1.0 if o == x else 0.0 for x in cats]
        return f

    tf = []
    for (n, _), i in zip(goals, gi):
        pos = all(float(r[i]) > 0 for r in train)
        tf.append(pos)
    ys = [[(log(float(r[i])) if pos else float(r[i])) for r in train] for i, pos in zip(gi, tf)]
    models = {}
    for vol in (True, False):
        X = [feats(r, col, vol) for r in train]
        models[vol] = [Ridge(X, y) for y in ys]

    mi = next(k for k, (n, _) in enumerate(goals) if base(n) == "Mpg")
    mpg, scores = [], []
    for r in test:
        vol = num(r, tcol, "Volume") is not None
        x = feats(r, tcol, vol)
        vals = []
        for m, pos in zip(models[vol], tf):
            p = m(x)
            vals.append(exp(p) if pos else p)
        mp = vals[mi]
        if not (mp > 0) or mp != mp or mp == float("inf"):
            mp = stats[mi][0]
        vals[mi] = mp
        mpg.append(mp)
        scores.append(max(0.0, min(1.0, d2h_of(vals, stats, goals))))
    return {"mpg": mpg, "scores": scores}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (sqrt(pooled) + 1e-32)
    sx, sy = sorted(xs), sorted(ys)
    tot = 0
    for x in xs:
        tot += bisect_left(sy, x) - (m - bisect_right(sy, x))
    cliffs = abs(tot) / (n * m)
    d = 0.0
    for v in set(sx) | set(sy):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / sqrt(1 / n + 1 / m)
    same = bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": same}


def certify(a):
    with open(a.test, encoding="utf-8-sig") as f:
        cases = json.load(f)
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def flow(a):
    out = guess(a)
    names, train = load(a.train)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]
    hist = [d2h_of([float(r[i]) for i in gi], stats, goals) for r in train]
    sc = out["scores"]
    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    out["alerts"] = alerts
    return out


def blame(a):
    names, train = load(a.train)
    tnames, test = load(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    tgi = [tnames.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]
    d2h = [d2h_of([float(r[i]) for i in gi], stats, goals) for r in train]
    order = sorted(range(len(train)), key=lambda i: (round(d2h[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    feats = []  # (name, train idx, test idx, numeric?)
    for j, n in enumerate(names):
        if n[-1] in "+-X":
            continue
        feats.append((n, j, tnames.index(n) if n in tnames else None, n[0].isupper()))

    def known(rows, j):
        return [r[j] for r in rows if j < len(r) and r[j] not in ("?", "")]

    info = {}
    for n, j, tj, isnum in feats:
        if isnum:
            allv = [float(v) for v in known(train, j)]
            gv = [float(v) for v in known(good, j)]
            pv = [float(v) for v in known(poor, j)]
            if not allv:
                info[n] = None
                continue
            st = goal_stats(allv)
            gc = nz(sum(gv) / len(gv), st) if gv else None
            pc = nz(sum(pv) / len(pv), st) if pv else None
            info[n] = (st, gc, pc)
        else:
            gk, pk = known(good, j), known(poor, j)
            gf = {c: gk.count(c) / len(gk) for c in set(gk)} if gk else {}
            pf = {c: pk.count(c) / len(pk) for c in set(pk)} if pk else {}
            info[n] = (gf, pf)

    diags = []
    for r in test:
        fs = {}
        for n, j, tj, isnum in feats:
            ev = 0.0
            v = r[tj] if tj is not None and tj < len(r) else "?"
            if v not in ("?", "") and info[n] is not None:
                if isnum:
                    st, gc, pc = info[n]
                    if gc is not None and pc is not None:
                        x = nz(float(v), st)
                        ev = max(0.0, abs(x - gc) - abs(x - pc))
                else:
                    gf, pf = info[n]
                    ev = max(0.0, pf.get(v, 0.0) - gf.get(v, 0.0))
            fs[n] = ev
        gs = {}
        for (n, h), st, i in zip(goals, stats, tgi):
            gs[n] = abs(nz(float(r[i]), st) - h)
        srt = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        diags.append({"goals": gs, "features": fs,
                      "goal_order": srt(gs), "feature_order": srt(fs)})
    return {"diagnoses": diags}


def justify(a):
    names, train = load(a.train)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]
    tr = sorted(d2h_of([float(r[i]) for i in gi], stats, goals) for r in train)
    cutoff = tr[len(tr) // 2]
    scores = remember(a)["scores"]
    diags = blame(a)["diagnoses"]
    n = len(scores)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        acc = bool(round(s, 12) <= round(cutoff, 12))
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            ad = {g: diags[lose]["goals"][g] ** 2 - diags[win]["goals"][g] ** 2
                  for g in diags[j]["goals"]}
            adv = sorted(ad, key=lambda g: (-round(ad[g], 10), g))[0]
        d = diags[j]
        weak = d["goal_order"][0]
        top = d["feature_order"][0] if d["feature_order"] else None
        if top is not None and not d["features"][top] > 1e-10:
            top = None
        t = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
             f"other score {o:.3f} (car {k}), cutoff {cutoff:.3f}; weakest goal {weak}.")
        if win is not None:
            t += f" Recommend car {win}; largest advantage in {adv}."
        else:
            t += " Scores tie."
        if top is not None:
            t += f" Top feature {top} (retrospective, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": t})
    return {"explanations": out}


def choose(a):
    names, train = load(a.train)
    _, test = load(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi = [names.index(n) for n, _ in goals]
    stats = [goal_stats([float(r[i]) for r in train]) for i in gi]
    n = len(test)
    budget = min(10, n)
    pred = guess(a)["scores"]
    ranked = sorted(range(n), key=lambda i: (pred[i], i))
    picks = ranked[:max(0, budget - 3)]          # exploit: best predicted
    rest = ranked[len(picks):]
    rng = random.Random(1)
    picks += rng.sample(rest, budget - len(picks))  # explore: random alternatives
    seen = []
    for i in picks:
        sys.stdout.write(json.dumps({"inspect": i}) + "\n")
        sys.stdout.flush()
        line = sys.stdin.readline()
        resp = json.loads(line)
        g = resp["goals"]
        seen.append((round(d2h_of([float(g[nm]) for nm, _ in goals], stats, goals), 12), i))
    seen.sort()
    sys.stdout.write(json.dumps({"selected": [i for _, i in seen[:3]]}) + "\n")
    sys.stdout.flush()
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    fns = {"remember": remember, "guess": guess, "certify": certify,
           "flow": flow, "blame": blame, "justify": justify, "choose": choose}
    if a.cmd not in fns:
        sys.exit("unknown command")
    res = fns[a.cmd](a)
    if res is not None:
        sys.stdout.write(json.dumps(res))


if __name__ == "__main__":
    main()
