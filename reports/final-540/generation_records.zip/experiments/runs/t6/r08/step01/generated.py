import sys, csv, json, argparse
from math import exp, sqrt


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd != "remember":
        sys.exit("unknown command")

    names, train = load(a.train)
    tnames, test = load(a.test)
    goals = [(n, 0 if n.endswith("-") else 1) for n in names if n[-1] in "+-"]
    gi_tr = [names.index(n) for n, _ in goals]
    gi_te = [tnames.index(n) for n, _ in goals]
    stats = []
    for i in gi_tr:
        vs = [float(r[i]) for r in train]
        n = len(vs)
        mu = sum(vs) / n
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        stats.append((mu, sd))

    def score(r):
        s = 0.0
        for (mu, sd), i, (_, h) in zip(stats, gi_te, goals):
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            s += (1 / (1 + exp(-1.702 * z)) - h) ** 2
        return sqrt(s / len(goals))

    scores = [score(r) for r in test]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
