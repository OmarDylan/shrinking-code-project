import sys, json, math

def read(p):
    with open(p, encoding="utf-8-sig") as f:
        L = [l.strip().split(",") for l in f if l.strip()]
    return [h.strip() for h in L[0]], [[c.strip() for c in r] for r in L[1:]]

def fl(s):
    try: return float(s)
    except ValueError: return None

def solve(A, b):
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for r in range(n):
            if r != i:
                f = M[r][i] / d
                if f:
                    M[r] = [a - f * c for a, c in zip(M[r], M[i])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

def ridge(X, y, lam=1.0):
    k = len(X[0])
    A = [[sum(r[i] * r[j] for r in X) + (lam if i == j and i > 0 else 0)
          for j in range(k)] for i in range(k)]
    b = [sum(r[i] * v for r, v in zip(X, y)) for i in range(k)]
    return solve(A, b)

def dot(w, x): return sum(a * b for a, b in zip(w, x))

def mean_sd(v):
    m = sum(v) / len(v)
    return m, math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1))

def same(xs, ys):
    n, m = len(xs), len(ys)
    mx, sx = mean_sd(xs); my, sy = mean_sd(ys)
    pv = ((n - 1) * sx ** 2 + (m - 1) * sy ** 2) / (n + m - 2)
    co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
    sx_, sy_ = sorted(xs), sorted(ys)
    ks = 0
    for v in set(xs) | set(ys):
        a = sum(1 for x in sx_ if x <= v) / n
        b = sum(1 for y in sy_ if y <= v) / m
        ks = max(ks, abs(a - b))
    ks /= math.sqrt(1 / n + 1 / m)
    return co <= 0.35 and cl <= 0.197 and ks <= 1.36

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]; te = a[a.index("--test") + 1]
    hn, R = read(tr); tn, T = read(te)
    ix = {h: i for i, h in enumerate(hn)}
    tx = {h: i for i, h in enumerate(tn)}
    origins = sorted({r[ix["origin"]] for r in R})
    goals = ["Lbs-", "Acc+", "Mpg+"]
    Y = [[float(r[ix[g]]) for r in R] for g in goals]
    st = [mean_sd(y) for y in Y]

    def d2h(l, ac, mp):
        s = 0
        for v, (m, sd), h in zip((l, ac, mp), st, (0, 1, 1)):
            z = max(-3, min(3, (v - m) / (sd + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
        return math.sqrt(s / 3)

    num = ["Clndrs", "Volume", "Model"]
    cm = {c: mean_sd([float(r[ix[c]]) for r in R]) for c in num}

    def feats(r, t, vol=True):
        i = tx if t else ix
        f = [1.0]
        for c in num:
            v = fl(r[i[c]]) if c in i else None
            if c == "Volume" and not vol: v = None
            if v is None: v = cm[c][0]
            f.append((v - cm[c][0]) / (cm[c][1] or 1))
        o = r[i["origin"]] if "origin" in i else None
        f += [1.0 if o == g else 0.0 for g in origins]
        return f

    # volume imputer from other features
    Xv = []
    for r in R:
        f = feats(r, False, False)
        f[2] = 0.0
        Xv.append(f)
    wv = ridge(Xv, [(float(r[ix["Volume"]]) - cm["Volume"][0]) / (cm["Volume"][1] or 1) for r in R], 1.0)

    X = [feats(r, False) for r in R]
    W = [ridge(X, y, 1.0) for y in Y]
    mpg, sc = [], []
    for r in T:
        f = feats(r, True)
        if fl(r[tx["Volume"]]) is None:
            g = f[:]; g[2] = 0.0
            f[2] = dot(wv, g)
        l, ac, mp = (dot(w, f) for w in W)
        mp = max(mp, 1.0)
        mpg.append(mp)
        sc.append(min(1.0, max(0.0, d2h(l, ac, mp))))
    hist = [d2h(*(Y[0][i], Y[1][i], Y[2][i])) for i in range(len(R))]
    al = []
    for i in range(len(sc)):
        al.append(False if i < 19 else (not same(hist, sc[i - 19:i + 1])))
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": al}))

main()
