import sys, json, math, argparse

GOALS = [5, 6, 7]
HEAVEN = {5: 0, 6: 1, 7: 1}
NUMX = [0, 1, 3]
CAT = 4


def atom(s):
    s = s.strip()
    for f in (int, float):
        try:
            return f(s)
        except ValueError:
            pass
    return s


def read(p):
    with open(p, encoding="utf-8-sig") as f:
        L = [l.strip() for l in f if l.strip()]
    return [[atom(c) for c in l.split(",")] for l in L[1:]]


def stats(rows, at):
    v = [r[at] for r in rows if r[at] != "?"]
    n = len(v)
    mu = sum(v) / n if n else 0.0
    sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
    return mu, sd


def mknorm(st):
    mu, sd = st

    def f(v):
        z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    train, test = read(a.train), read(a.test)
    gn = {g: mknorm(stats(train, g)) for g in GOALS}
    xn = {c: mknorm(stats(train, c)) for c in NUMX}

    def d2h(r):
        return math.sqrt(sum((gn[g](r[g]) - HEAVEN[g]) ** 2 for g in GOALS) / 3)

    td = [d2h(r) for r in train]
    tx = [{c: xn[c](r[c]) for c in NUMX if r[c] != "?"} for r in train]

    def dist(r1, n1, r2, n2):
        s = 0.0
        for c in NUMX:
            if c in n1 and c in n2:
                s += (n1[c] - n2[c]) ** 2
            else:
                s += 1
        s += 0 if r1[CAT] == r2[CAT] and r1[CAT] != "?" else 1
        return math.sqrt(s / 4)

    def nx(r):
        return {c: xn[c](r[c]) for c in NUMX if r[c] != "?"}

    def predict(r):
        n = nx(r)
        order = sorted(range(len(train)),
                       key=lambda i: (round(dist(r, n, train[i], tx[i]), 12), i))[:5]
        return sum(td[i] for i in order) / len(order)

    cutoff = sorted(td)[len(train) // 2]
    rk = sorted(range(len(train)), key=lambda i: (round(td[i], 12), i))
    good = rk[:max(1, len(train) // 4)]
    menu, seen = [], set()
    for i in good:
        p = (train[i][0], train[i][1])
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for idx, r in enumerate(test):
        before = predict(r)
        res = {"row": idx, "before": before, "after": before, "changes": {},
               "status": "already_good"}
        if round(before, 10) > round(cutoff, 10):
            res["status"] = "no_candidate"
            n0 = nx(r)
            best = None
            for (c, v) in menu:
                ch = (c != r[0]) + (v != r[1])
                if ch == 0:
                    continue
                e = list(r)
                e[0], e[1] = c, v
                ne = nx(e)
                after = predict(e)
                if round(before - after, 10) >= 0.05:
                    key = (ch, round(dist(r, n0, e, ne), 10), round(after, 10), (c, v))
                    if best is None or key < best[0]:
                        best = (key, after, c, v)
            if best:
                _, after, c, v = best
                chg = {}
                if c != r[0]:
                    chg["Clndrs"] = c
                if v != r[1]:
                    chg["Volume"] = v
                res.update(after=after, changes=chg, status="improved")
        out.append(res)
    sys.stdout.write(json.dumps({"repairs": out}))


if __name__ == "__main__":
    main()
