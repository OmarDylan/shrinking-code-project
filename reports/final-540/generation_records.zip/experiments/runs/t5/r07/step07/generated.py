import sys, csv, json, math

def load(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return [c.strip() for c in rows[0]], [[c.strip() for c in r] for r in rows[1:]]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    names, train = load(tr)
    tnames, test = load(te)
    goals = [n for n in names if n[-1] in "+-"]
    xs = [n for n in names if n[-1] not in "+-X"]
    stats = {}
    for g in goals:
        v = [num(r[names.index(g)]) for r in train]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1))
        stats[g] = (m, sd)

    def d2h(gv):
        t = 0
        for g in goals:
            m, sd = stats[g]
            z = max(-3, min(3, (gv[g] - m) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            h = 0 if g[-1] == "-" else 1
            t += (n - h) ** 2
        return math.sqrt(t / len(goals))

    # feature extraction
    numx = [n for n in xs if n[0].isupper()]
    symx = [n for n in xs if not n[0].isupper()]
    sc = {}
    for n in numx:
        v = [num(r[names.index(n)]) for r in train]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) or 1
        sc[n] = (m, sd)

    def feat(r, nm):
        f = []
        for n in numx:
            x = num(r[nm.index(n)]) if n in nm else None
            f.append(None if x is None else (x - sc[n][0]) / sc[n][1])
        for n in symx:
            x = r[nm.index(n)] if n in nm else "?"
            f.append(None if x == "?" else x)
        return f

    def dist(p, q):
        s = 0
        for u, v in zip(p, q):
            if u is None or v is None:
                s += 1
            elif isinstance(u, str):
                s += 0 if u == v else 1
            else:
                s += min(abs(u - v), 3) ** 2 if False else (u - v) ** 2
        return math.sqrt(s)

    pool = []
    for r in train:
        try:
            gv = {g: float(r[names.index(g)]) for g in goals}
        except ValueError:
            continue
        pool.append((feat(r, names), d2h(gv)))
    tf = [feat(r, tnames) for r in test]
    n = len(test)
    done = {}
    k = 5

    def pred(f):
        ds = sorted(((dist(f, p), y) for p, y in pool), key=lambda t: t[0])[:k]
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w)

    for _ in range(min(10, n)):
        best = min((i for i in range(n) if i not in done),
                   key=lambda i: (pred(tf[i]), i))
        print(json.dumps({"inspect": best}), flush=True)
        resp = json.loads(sys.stdin.readline())
        gv = {g: float(resp["goals"][g]) for g in goals}
        y = d2h(gv)
        done[best] = y
        pool.append((tf[best], y))
    top = sorted(done, key=lambda i: (round(done[i], 12), i))[:3]
    print(json.dumps({"selected": top}), flush=True)

main()
