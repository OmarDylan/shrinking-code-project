import sys, json, csv, math

def main():
    a = sys.argv
    train_p, test_p = a[a.index('--train') + 1], a[a.index('--test') + 1]
    with open(train_p, newline='', encoding='utf-8-sig') as f:
        tr = [r for r in csv.reader(f) if r]
    th, trows = [h.strip() for h in tr[0]], tr[1:]
    with open(test_p) as f:
        T = json.load(f)
    G = ["Lbs-", "Acc+", "Mpg+"]
    heaven = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    gi = {g: th.index(g) for g in G}
    st = {}
    for g in G:
        v = [float(r[gi[g]]) for r in trows]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0
        st[g] = (m, sd)

    def nz(x, m, sd):
        z = max(-3, min(3, (x - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(gv):
        return math.sqrt(sum((nz(gv[g], *st[g]) - heaven[g]) ** 2 for g in G) / 3)

    tdh = [d2h({g: float(r[gi[g]]) for g in G}) for r in trows]
    target = sorted(tdh)[len(trows) // 4]

    NUM = ["Clndrs", "Volume", "Model"]
    nst = {}
    for c in NUM:
        v = [float(r[th.index(c)]) for r in trows]
        m = sum(v) / len(v)
        nst[c] = (m, math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)))
    oi_tr = th.index("origin")

    def feat(vals, h):
        out = []
        for c in NUM:
            x = vals[h.index(c)]
            out.append(None if x == "?" else nz(float(x), *nst[c]))
        o = vals[h.index("origin")]
        out.append(None if o == "?" else str(o).strip())
        return out

    trf = [feat(r, th) for r in trows]

    def dist(p, q):
        s = 0
        for i in range(4):
            x, y = p[i], q[i]
            if x is None or y is None:
                s += 1
            elif i < 3:
                s += (x - y) ** 2
            else:
                s += 0 if x == y else 1
        return math.sqrt(s / 4)

    th_ = T["header"]
    rows = T["rows"]
    tf = {}

    def F(i):
        if i not in tf:
            tf[i] = feat(rows[i], th_)
        return tf[i]

    pc = {}

    def pred(i):
        if i not in pc:
            f = F(i)
            ds = sorted((round(dist(f, g), 12), j) for j, g in enumerate(trf))[:5]
            pc[i] = sum(tdh[j] for _, j in ds) / len(ds)
        return pc[i]

    def ask(e, strat, i):
        print(json.dumps({"episode": e, "strategy": strat, "inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h({g: float(resp["goals"][g]) for g in G})

    def adaptive(e, pool):
        seen = []  # (idx, observed)
        left = list(pool)
        while len(seen) < 10:
            def sc(i):
                w = res = 0
                for j, o in seen:
                    k = math.exp(-dist(F(i), F(j)) / 0.2)
                    w += k
                    res += k * (o - pred(j))
                return (pred(i) + res / (1 + w), i)
            b = min(left, key=sc)
            left.remove(b)
            seen.append((b, ask(e, "adaptive", b)))
        return [o for _, o in seen]

    def rnd(e, order):
        return [ask(e, "random", i) for i in order[:10]]

    def met(obs):
        lt = 11
        for k, o in enumerate(obs):
            if round(o, 12) <= round(target, 12):
                lt = k + 1
                break
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lt}

    results = []
    for e, ep in enumerate(T["episodes"]):
        ad = met(adaptive(e, ep["pool"]))
        rn = met(rnd(e, ep["random_order"]))
        results.append({"episode": e, "adaptive": ad, "random": rn})

    def cert(xs, ys):
        n, m = len(xs), len(ys)
        mx, my = sum(xs) / n, sum(ys) / m
        vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
        vy = sum((y - my) ** 2 for y in ys) / (m - 1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
        cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
        d = 0
        for v in set(xs) | set(ys):
            d = max(d, abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m))
        k = d / math.sqrt(1 / n + 1 / m)
        return {"cohen": co, "cliffs": cl, "ks": k, "same": bool(co <= 0.35 and cl <= 0.197 and k <= 1.36)}

    comps = {}
    for m in ["best5", "best10", "labels_to_target"]:
        comps[m] = cert([float(r["adaptive"][m]) for r in results],
                        [float(r["random"][m]) for r in results])
    print(json.dumps({"results": results, "comparisons": comps}), flush=True)

if __name__ == "__main__":
    main()
