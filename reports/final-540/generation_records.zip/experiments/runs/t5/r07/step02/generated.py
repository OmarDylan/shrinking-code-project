import sys, csv, json, math

def num(s):
    try: return float(s)
    except: return None

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(M[k][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for k in range(i + 1, n):
            f = M[k][i] / d
            for j in range(i, n + 1): M[k][j] -= f * M[i][j]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n))) / (M[i][i] or 1e-12)
    return x

class Ridge:
    def __init__(s, X, ys, lam=0.3):
        n, k = len(X), len(X[0])
        s.mu = [sum(r[j] for r in X) / n for j in range(k)]
        s.sd = [(sum((r[j] - s.mu[j]) ** 2 for r in X) / max(1, n - 1)) ** .5 or 1 for j in range(k)]
        Z = [s.z(r) for r in X]
        s.ym = [sum(y) / n for y in ys]
        A = [[sum(r[i] * r[j] for r in Z) + (lam * n / 10 if i == j else 0) for j in range(k)] for i in range(k)]
        s.w = [solve(A, [sum(r[i] * (y[t] - m) for t, r in enumerate(Z)) for i in range(k)])
               for y, m in zip(ys, s.ym)]
    def z(s, r): return [(r[j] - s.mu[j]) / s.sd[j] for j in range(len(r))]
    def pred(s, r):
        z = s.z(r)
        return [m + sum(a * b for a, b in zip(w, z)) for w, m in zip(s.w, s.ym)]

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    h, R = load(tr)
    h2, T = load(te)
    ix = {n: i for i, n in enumerate(h)}
    jx = {n: i for i, n in enumerate(h2)}
    G = ["Lbs-", "Acc+", "Mpg+"]
    R = [r for r in R if all(num(r[ix[g]]) is not None for g in G)]
    n = len(R)
    def col(rows, ids, name):
        return [num(r[ids[name]]) if name in ids and ids[name] < len(r) else None for r in rows]
    cm = {}
    for nm in ("Clndrs", "Volume", "Model"):
        v = [x for x in col(R, ix, nm) if x is not None]
        cm[nm] = sum(v) / len(v)
    orgs = sorted({r[ix["origin"]] for r in R})
    def feat(r, ids, useV):
        g = lambda nm: (lambda x: cm[nm] if x is None else x)(num(r[ids[nm]]) if nm in ids and ids[nm] < len(r) else None)
        c, m = g("Clndrs"), g("Model")
        o = r[ids["origin"]] if "origin" in ids and ids["origin"] < len(r) else ""
        f = [c, m, c * c, c * m] + [1.0 if o == k else 0.0 for k in orgs]
        if useV:
            v = max(g("Volume"), 1.0)
            f += [v, math.log(v), v * m / 100]
        return f
    Y = [[num(r[ix[g]]) for r in R] for g in G]
    st = []
    for y in Y:
        mu = sum(y) / n
        sd = (sum((v - mu) ** 2 for v in y) / max(1, n - 1)) ** .5
        st.append((mu, sd))
    def norm(v, s):
        z = max(-3, min(3, (v - s[0]) / (s[1] + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    def d2h(vs):
        hv = [0, 1, 1]
        return math.sqrt(sum((norm(v, s) - h_) ** 2 for v, s, h_ in zip(vs, st, hv)) / 3)
    D = [d2h([Y[0][i], Y[1][i], Y[2][i]]) for i in range(n)]
    models = {}
    for useV in (True, False):
        X = [feat(r, ix, useV) for r in R]
        models[useV] = Ridge(X, Y + [D])
    mpg, sc = [], []
    for r in T:
        v = num(r[jx["Volume"]]) if "Volume" in jx and jx["Volume"] < len(r) else None
        useV = v is not None
        p = models[useV].pred(feat(r, jx, useV))
        m = p[2]
        if not math.isfinite(m) or m < 1.0: m = max(1.0, m if math.isfinite(m) else st[2][0])
        d = p[3]
        d = min(1.0, max(0.0, d)) if math.isfinite(d) else 0.5
        mpg.append(m); sc.append(d)
    sys.stdout.write(json.dumps({"mpg": mpg, "scores": sc}))

if __name__ == "__main__":
    main()
