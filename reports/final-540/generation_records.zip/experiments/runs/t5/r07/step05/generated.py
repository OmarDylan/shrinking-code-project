import sys, json, math, argparse

def read(path):
    with open(path, encoding="utf-8-sig") as f:
        lines = [l.strip() for l in f if l.strip()]
    names = [s.strip() for s in lines[0].split(",")]
    rows = [[s.strip() for s in l.split(",")] for l in lines[1:]]
    return names, rows

def num(s):
    return None if s == "?" or s == "" else float(s)

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def mknorm(mu, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    names, tr = read(a.train)
    tnames, te = read(a.test)

    feats = [(i, n) for i, n in enumerate(names) if not n.endswith("X") and n[-1] not in "+-"]
    goals = [(i, n) for i, n in enumerate(names) if n[-1] in "+-"]
    tidx = {n: i for i, n in enumerate(tnames)}

    gnorm = {}
    for i, n in goals:
        mu, sd = stats([float(r[i]) for r in tr])
        gnorm[n] = mknorm(mu, sd)
    heaven = {n: 0.0 if n.endswith("-") else 1.0 for _, n in goals}

    def d2h(r, idx):
        s = 0.0
        for i, n in goals:
            s += (gnorm[n](float(r[idx[n]])) - heaven[n]) ** 2
        return math.sqrt(s / len(goals))

    trn = {n: i for i, n in enumerate(names)}
    order = sorted(range(len(tr)), key=lambda k: (round(d2h(tr[k], trn), 12), k))
    q = max(1, len(tr) // 4)
    good = [tr[k] for k in order[:q]]
    poor = [tr[k] for k in order[-q:]]

    model = {}
    for i, n in feats:
        if n[0].isupper():
            mu, sd = stats([num(r[i]) for r in tr if num(r[i]) is not None])
            nf = mknorm(mu, sd)
            def center(g, i=i, nf=nf):
                v = [num(r[i]) for r in g if num(r[i]) is not None]
                return nf(sum(v) / len(v)) if v else None
            model[n] = ("num", nf, center(good), center(poor))
        else:
            def freq(g, i=i):
                v = [r[i] for r in g if r[i] != "?"]
                c = {}
                for x in v:
                    c[x] = c.get(x, 0) + 1
                return {k: x / len(v) for k, x in c.items()}
            model[n] = ("sym", freq(good), freq(poor))

    out = []
    for r in te:
        gs = {n: abs(gnorm[n](float(r[tidx[n]])) - heaven[n]) for _, n in goals}
        fs = {}
        for i, n in feats:
            raw = r[tidx[n]] if n in tidx else "?"
            m = model[n]
            if raw == "?" or raw == "":
                fs[n] = 0.0
            elif m[0] == "num":
                gc, pc = m[2], m[3]
                if gc is None or pc is None:
                    fs[n] = 0.0
                else:
                    x = m[1](float(raw))
                    fs[n] = max(0.0, abs(x - gc) - abs(x - pc))
            else:
                fs[n] = max(0.0, m[2].get(raw, 0.0) - m[1].get(raw, 0.0))
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    sys.stdout.write(json.dumps({"diagnoses": out}))

if __name__ == "__main__":
    main()
