import sys, json, math, argparse

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        lines = [l.strip() for l in f if l.strip()]
    hdr = [s.strip() for s in lines[0].split(",")]
    rows = []
    for l in lines[1:]:
        r = []
        for s in l.split(","):
            s = s.strip()
            if s == "?":
                r.append("?")
                continue
            try:
                r.append(float(s))
            except ValueError:
                r.append(s)
        rows.append(r)
    return hdr, rows

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def mknorm(mu, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

GOALS = [5, 6, 7]
HEAVEN = {5: 0.0, 6: 1.0, 7: 1.0}
NUMF = [0, 1, 3]
CAT = 4

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    hdr, tr = load(a.train)
    _, te = load(a.test)
    gn = {c: mknorm(*stats([r[c] for r in tr if r[c] != "?"])) for c in GOALS}
    fn = {c: mknorm(*stats([r[c] for r in tr if r[c] != "?"])) for c in NUMF}

    def gaps(r):
        return {c: abs(gn[c](r[c]) - HEAVEN[c]) for c in GOALS}

    def d2h(r):
        return math.sqrt(sum(g * g for g in gaps(r).values()) / 3)

    trs = [d2h(r) for r in tr]
    tes = [d2h(r) for r in te]

    if a.cmd == "remember":
        rk = sorted(range(len(te)), key=lambda i: (tes[i], i))
        print(json.dumps({"scores": tes, "top": rk[:10], "best": rk[0],
                          "median": rk[len(te) // 2], "worst": rk[-1]}))
        return

    order = sorted(range(len(tr)), key=lambda i: (round(trs[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    cent = {}
    for c in NUMF:
        for nm, g in (("g", good), ("p", poor)):
            v = [r[c] for r in g if r[c] != "?"]
            cent[(c, nm)] = fn[c](sum(v) / len(v)) if v else None

    def freq(g, cat):
        v = [r[CAT] for r in g if r[CAT] != "?"]
        return v.count(cat) / len(v) if v else 0.0

    def diag(r):
        goals = {hdr[c]: g for c, g in gaps(r).items()}
        feats = {}
        for c in NUMF:
            x = r[c]
            gc, pc = cent[(c, "g")], cent[(c, "p")]
            if x == "?" or gc is None or pc is None:
                feats[hdr[c]] = 0.0
            else:
                nx = fn[c](x)
                feats[hdr[c]] = max(0.0, abs(nx - gc) - abs(nx - pc))
        x = r[CAT]
        feats[hdr[CAT]] = 0.0 if x == "?" else max(0.0, freq(poor, x) - freq(good, x))
        go = sorted(goals, key=lambda k: (-round(goals[k], 10), k))
        fo = sorted(feats, key=lambda k: (-round(feats[k], 10), k))
        return {"goals": goals, "features": feats, "goal_order": go, "feature_order": fo}

    ds = [diag(r) for r in te]
    if a.cmd == "blame":
        print(json.dumps({"diagnoses": ds}))
        return

    cutoff = sorted(trs)[len(trs) // 2]
    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = tes[j], tes[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            gw, gl = gaps(te[win]), gaps(te[lose])
            sc = {hdr[c]: gl[c] ** 2 - gw[c] ** 2 for c in GOALS}
            adv = sorted(sc, key=lambda g: (-round(sc[g], 10), g))[0]
        d = ds[j]
        weak = d["goal_order"][0]
        tf = d["feature_order"][0]
        if not d["features"][tf] > 1e-10:
            tf = None
        t = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
             f"other score {o:.3f}, cutoff {cutoff:.3f}; weakest goal {weak}. ")
        if win is not None:
            t += f"Recommend car {win} because of advantage in {adv}. "
        else:
            t += "The cars tie. "
        if tf:
            t += f"Top feature {tf} (retrospective, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": tf, "text": t})
    print(json.dumps({"explanations": out}))

main()
