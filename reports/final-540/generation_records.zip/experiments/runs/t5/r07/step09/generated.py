import sys, csv, json, math

NUM = ["Clndrs", "Volume", "Model"]
CAT = ["origin"]


def load(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = [r for r in csv.reader(f) if r]
    h = [s.strip() for s in rows[0]]
    ix = {n: h.index(n) for n in NUM + CAT}
    out = []
    for r in rows[1:]:
        v = []
        for n in NUM:
            s = r[ix[n]].strip()
            try:
                v.append(float(s))
            except ValueError:
                v.append(None)
        for n in CAT:
            s = r[ix[n]].strip()
            v.append(None if s == "?" or s == "" else s)
        out.append(v)
    return out


def med(xs):
    xs = sorted(xs)
    n = len(xs)
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2


def main():
    a = sys.argv
    tr = load(a[a.index("--train") + 1])
    te = load(a[a.index("--test") + 1])
    k = len(NUM)
    stats = []
    for j in range(k):
        xs = [r[j] for r in tr if r[j] is not None]
        if not xs:
            stats.append((0.0, 1.0))
            continue
        m = med(xs)
        mad = 1.4826 * med([abs(x - m) for x in xs])
        mu = sum(xs) / len(xs)
        sd = (sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1)) ** .5
        s = mad if mad > 1e-9 else sd
        stats.append((m, s if s > 1e-9 else 1.0))
    sdv = []
    for j in range(k):
        xs = [r[j] for r in tr if r[j] is not None]
        if xs:
            mu = sum(xs) / len(xs)
            s = (sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1)) ** .5
        else:
            s = 1.0
        sdv.append(s if s > 1e-9 else 1.0)

    def d(r1, r2):
        t, c = 0.0, 0
        for j in range(k):
            if r1[j] is None or r2[j] is None:
                continue
            t += ((r1[j] - r2[j]) / sdv[j]) ** 2
            c += 1
        for j in range(k, k + len(CAT)):
            if r1[j] is None or r2[j] is None:
                continue
            t += float(r1[j] != r2[j])
            c += 1
        return math.sqrt(t / c) if c else 0.0

    K = 5

    def knn(r, skip=None):
        ds = sorted(d(r, t) for i, t in enumerate(tr) if i != skip)
        ds = ds[:K]
        return sum(ds) / len(ds) if ds else 0.0

    def maxz(r):
        z = [abs(r[j] - stats[j][0]) / stats[j][1]
             for j in range(k) if r[j] is not None]
        return max(z) if z else 0.0

    trk = [knn(r, i) for i, r in enumerate(tr)]
    base = med(trk) or 1e-9

    def raw(r, kn):
        return kn / base + 0.25 * maxz(r)

    def sc(x):
        return x / (1 + x)

    trs = sorted(sc(raw(r, trk[i])) for i, r in enumerate(tr))
    th = trs[min(len(trs) - 1, int(0.95 * len(trs)))] if trs else 0.5
    th = min(1.0, max(0.0, th))
    scores = [min(1.0, max(0.0, sc(raw(r, knn(r))))) for r in te]
    print(json.dumps({"scores": scores,
                      "alerts": [s > th for s in scores],
                      "threshold": th}))


main()
