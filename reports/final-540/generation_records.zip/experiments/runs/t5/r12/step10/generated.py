import sys, json, csv, math, argparse

GOALS = ["Lbs-", "Acc+", "Mpg+"]
NUMS = ["Clndrs", "Volume", "Model"]


def fnum(v):
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def stats(vals):
    n = len(vals)
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd


def nrm(v, mu, sd):
    z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def mean(a):
    return sum(a) / len(a)


def compare(xs, ys):
    n, m = len(xs), len(ys)
    vx = stats(xs)[1] ** 2
    vy = stats(ys)[1] ** 2
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pooled) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    d = 0.0
    for v in set(xs) | set(ys):
        fx = sum(1 for a in sx if a <= v) / n
        fy = sum(1 for a in sy if a <= v) / m
        d = max(d, abs(fx - fy))
    ks = d / math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()

    with open(a.train, encoding="utf-8-sig") as f:
        rd = [r for r in csv.reader(f) if r]
    th, trows = [h.strip() for h in rd[0]], rd[1:]
    ti = {h: i for i, h in enumerate(th)}
    gst = {}
    for g in GOALS:
        gst[g] = stats([float(r[ti[g]]) for r in trows])
    nst = {c: stats([float(r[ti[c]]) for r in trows if fnum(r[ti[c]]) is not None])
           for c in NUMS}

    def d2h(goals):
        s = 0
        for g in GOALS:
            h = 0 if g.endswith("-") else 1
            s += (nrm(float(goals[g]), *gst[g]) - h) ** 2
        return math.sqrt(s / 3)

    def feat(get):
        out = []
        for c in NUMS:
            v = fnum(get(c))
            out.append(None if v is None else nrm(v, *nst[c]))
        o = get("origin")
        out.append(None if o is None or str(o).strip() == "?" else str(o).strip())
        return out

    def dist(p, q):
        s = 0
        for i in range(3):
            s += 1 if p[i] is None or q[i] is None else (p[i] - q[i]) ** 2
        if p[3] is None or q[3] is None:
            s += 1
        else:
            s += p[3] != q[3]
        return math.sqrt(s / 4)

    tfeat = [feat(lambda c, r=r: r[ti[c]]) for r in trows]
    tscore = [d2h({g: r[ti[g]] for g in GOALS}) for r in trows]
    target = sorted(tscore)[len(tscore) // 4]

    with open(a.test) as f:
        data = json.load(f)
    hi = {h: i for i, h in enumerate(data["header"])}
    rows = data["rows"]
    cache = {}

    def rfeat(i):
        if i not in cache:
            cache[i] = feat(lambda c: rows[i][hi[c]] if c in hi else None)
        return cache[i]

    def inspect(ep, strat, idx):
        print(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}))
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        return d2h(resp["goals"])

    results = []
    for e, epi in enumerate(data["episodes"]):
        pool = list(epi["pool"])
        base = {i: sorted((dist(rfeat(i), tf), j) for j, tf in enumerate(tfeat))[:5]
                for i in pool}
        seen = []  # (index, score)
        ad = []
        remaining = list(pool)
        for _ in range(10):
            def pred(i):
                c = [(d, 0, j, tscore[j]) for d, j in base[i]]
                c += [(dist(rfeat(i), rfeat(k)), 1, k, s) for k, s in seen]
                c.sort(key=lambda t: (round(t[0], 12), t[1], t[2]))
                return mean([t[3] for t in c[:5]])
            best = min(remaining, key=lambda i: (round(pred(i), 12), i))
            remaining.remove(best)
            s = inspect(e, "adaptive", best)
            seen.append((best, s))
            ad.append(s)
        rn = []
        for idx in epi["random_order"][:10]:
            rn.append(inspect(e, "random", idx))

        def summ(v):
            lt = 11
            for k, x in enumerate(v):
                if round(x, 12) <= round(target, 12):
                    lt = k + 1
                    break
            return {"best5": min(v[:5]), "best10": min(v), "labels_to_target": lt}
        results.append({"episode": e, "adaptive": summ(ad), "random": summ(rn)})

    comps = {}
    for m in ("best5", "best10", "labels_to_target"):
        comps[m] = compare([float(r["adaptive"][m]) for r in results],
                           [float(r["random"][m]) for r in results])
    print(json.dumps({"results": results, "comparisons": comps}))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
