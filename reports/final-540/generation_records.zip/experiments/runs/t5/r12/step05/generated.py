import sys, json, csv, math

def num(s):
    s = s.strip()
    if s == "?" or s == "":
        return None
    return float(s)

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def stats(vals):
    n = len(vals)
    mu = sum(vals) / n if n else 0.0
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def mknorm(mu, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    a = sys.argv
    train = a[a.index("--train") + 1]
    test = a[a.index("--test") + 1]
    hdr, tr = load(train)
    _, te = load(test)
    gi = {"-": 0.0, "+": 1.0}
    goals = [(i, h, gi[h[-1]]) for i, h in enumerate(hdr) if h[-1] in "+-"]
    feats = [(i, h) for i, h in enumerate(hdr)
             if h[-1] not in "+-X" and h[0] != " "]
    gnorm = {}
    for i, h, hv in goals:
        gnorm[i] = mknorm(*stats([float(r[i]) for r in tr]))

    def d2h(r):
        return math.sqrt(sum((gnorm[i](float(r[i])) - hv) ** 2 for i, h, hv in goals) / len(goals))

    order = sorted(range(len(tr)), key=lambda k: (round(d2h(tr[k]), 12), k))
    q = max(1, len(tr) // 4)
    good = [tr[k] for k in order[:q]]
    poor = [tr[k] for k in order[-q:]]

    info = {}
    for i, h in feats:
        if h[0].isupper():
            vals = [num(r[i]) for r in tr]
            vals = [v for v in vals if v is not None]
            nf = mknorm(*stats(vals)) if vals else None
            def center(g, i=i, nf=nf):
                vs = [num(r[i]) for r in g]
                vs = [v for v in vs if v is not None]
                return nf(sum(vs) / len(vs)) if vs else None
            info[i] = ("n", nf, center(good), center(poor))
        else:
            def freq(g, i=i):
                vs = [r[i] for r in g if r[i] != "?" and r[i] != ""]
                d = {}
                for v in vs:
                    d[v] = d.get(v, 0) + 1
                return d, len(vs)
            info[i] = ("c", freq(good), freq(poor))

    out = []
    for r in te:
        fs = {}
        for i, h in feats:
            t = info[i]
            v = r[i] if i < len(r) else "?"
            e = 0.0
            if v not in ("?", ""):
                if t[0] == "n":
                    x = num(v)
                    if x is not None and t[2] is not None and t[3] is not None:
                        nx = t[1](x)
                        e = max(0.0, abs(nx - t[2]) - abs(nx - t[3]))
                else:
                    (gd, gn), (pd, pn) = t[1], t[2]
                    pf = pd.get(v, 0) / pn if pn else 0.0
                    gf = gd.get(v, 0) / gn if gn else 0.0
                    e = max(0.0, pf - gf)
            fs[h] = e
        gs = {h: abs(gnorm[i](float(r[i])) - hv) for i, h, hv in goals}
        key = lambda d: sorted(d, key=lambda n: (-round(d[n], 10), n))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    print(json.dumps({"diagnoses": out}))

if __name__ == "__main__":
    main()
