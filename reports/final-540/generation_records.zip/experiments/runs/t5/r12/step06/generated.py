import sys, json, csv, math

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def stats(vs):
    n = len(vs)
    if n == 0:
        return 0.0, 0.0
    mu = sum(vs) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def mknorm(mu, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

GOALS = [("Lbs", 5, 0), ("Acc", 6, 1), ("Mpg", 7, 1)]
GN = ["Lbs-", "Acc+", "Mpg+"]
NUMF = [("Clndrs", 0), ("Volume", 1), ("Model", 3)]
CAT = ("origin", 4)

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    _, train = load(tr)
    _, test = load(te)

    gn = []
    for _, i, h in GOALS:
        gn.append(mknorm(*stats([float(r[i]) for r in train])))

    def gaps(r):
        return {GN[k]: abs(gn[k](float(r[GOALS[k][1]])) - GOALS[k][2]) for k in range(3)}

    def d2h(r):
        g = gaps(r)
        return math.sqrt(sum(v * v for v in g.values()) / 3)

    td = [d2h(r) for r in train]
    cutoff = sorted(td)[len(train) // 2]

    order = sorted(range(len(train)), key=lambda i: (round(td[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    fn = {}
    for name, i in NUMF:
        vs = [num(r[i]) for r in train if num(r[i]) is not None]
        nf = mknorm(*stats(vs))
        def center(g, i=i, nf=nf):
            x = [num(r[i]) for r in g if num(r[i]) is not None]
            return nf(sum(x) / len(x)) if x else None
        fn[name] = (i, nf, center(good), center(poor))
    ci = CAT[1]
    def freq(g):
        k = [r[ci] for r in g if r[ci] != "?"]
        d = {}
        for v in k:
            d[v] = d.get(v, 0) + 1
        return d, len(k)
    gf, gnn = freq(good)
    pf, pnn = freq(poor)

    def feats(r):
        out = {}
        for name, (i, nf, gc, pc) in fn.items():
            x = num(r[i])
            if x is None or gc is None or pc is None:
                out[name] = 0.0
            else:
                v = nf(x)
                out[name] = max(0.0, abs(v - gc) - abs(v - pc))
        c = r[ci]
        if c == "?":
            out[CAT[0]] = 0.0
        else:
            p = pf.get(c, 0) / pnn if pnn else 0.0
            g = gf.get(c, 0) / gnn if gnn else 0.0
            out[CAT[0]] = max(0.0, p - g)
        return out

    def srt(d):
        return sorted(d, key=lambda k: (-round(d[k], 10), k))

    n = len(test)
    sc = [d2h(r) for r in test]
    gp = [gaps(r) for r in test]
    ft = [feats(r) for r in test]
    res = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        if round(s, 12) == round(o, 12):
            w = None
        else:
            w = j if s < o else k
        adv = None
        if w is not None:
            l = k if w == j else j
            ad = {g: gp[l][g] ** 2 - gp[w][g] ** 2 for g in GN}
            adv = sorted(GN, key=lambda g: (-round(ad[g], 10), g))[0]
        weak = srt(gp[j])[0]
        fo = srt(ft[j])
        top = fo[0] if ft[j][fo[0]] > 1e-10 else None
        t = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
             f"other score {o:.3f}, cutoff {cutoff:.3f}. Weakest goal {weak}. ")
        if w is not None:
            t += f"Recommend car {w} because of {adv}. "
        else:
            t += "Result is a tie. "
        if top is not None:
            t += f"Top feature {top}. "
        t += "Retrospective, not causal."
        res.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": w,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": t})
    print(json.dumps({"explanations": res}))

if __name__ == "__main__":
    main()
