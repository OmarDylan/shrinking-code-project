import sys, csv, json, math

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        rows = [r for r in csv.reader(f) if r and any(c.strip() for c in r)]
    h = [x.strip() for x in rows[0]]
    return h, [[c.strip() for c in r] for r in rows[1:]]

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def norm(st, v):
    z = max(-3.0, min(3.0, (v - st[0]) / (st[1] + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def main():
    a = sys.argv[1:]
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, T = load(tr)
    h2, S = load(te)
    ix = {n: i for i, n in enumerate(h)}
    ix2 = {n: i for i, n in enumerate(h2)}
    goals = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
    gst = {g: stats([num(r[ix[g]]) for r in T]) for g, _ in goals}
    d2h = []
    for r in T:
        s = 0
        for g, hv in goals:
            v = num(r[ix[g]])
            s += (norm(gst[g], v) - hv) ** 2 if v is not None else 1
        d2h.append(math.sqrt(s / 3))
    nums = ["Clndrs", "Volume", "Model"]
    ist = {c: stats([num(r[ix[c]]) for r in T]) for c in nums}

    def feat(r, ixm):
        f = []
        for c in nums:
            v = num(r[ixm[c]])
            f.append(norm(ist[c], v) if v is not None else None)
        return f, r[ixm["origin"]]
    TF = [feat(r, ix) for r in T]

    def dist(A, B):
        s = 0
        for x, y in zip(A[0], B[0]):
            s += 1 if x is None or y is None else (x - y) ** 2
        s += 0 if A[1] == B[1] else 1
        return math.sqrt(s / 4)

    def pred(F):
        ds = sorted((round(dist(F, t), 12), i) for i, t in enumerate(TF))
        return sum(d2h[i] for _, i in ds[:5]) / len(ds[:5])

    n = len(T)
    cutoff = sorted(d2h)[n // 2]
    order = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = order[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (num(T[i][ix["Clndrs"]]), num(T[i][ix["Volume"]]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for k, r in enumerate(S):
        F = feat(r, ix2)
        before = pred(F)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": k, "before": before, "after": before,
                        "changes": {}, "status": "already_good"})
            continue
        oc, ov = num(r[ix2["Clndrs"]]), num(r[ix2["Volume"]])
        best = None
        for c, v in menu:
            ch = {}
            if oc != c:
                ch["Clndrs"] = c
            if ov != v:
                ch["Volume"] = v
            if not ch:
                continue
            nf = [norm(ist["Clndrs"], c), norm(ist["Volume"], v), F[0][2]]
            E = (nf, F[1])
            after = pred(E)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(F, E), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best is None:
            out.append({"row": k, "before": before, "after": before,
                        "changes": {}, "status": "no_candidate"})
        else:
            out.append({"row": k, "before": before, "after": best[1],
                        "changes": best[2], "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == "__main__":
    main()
