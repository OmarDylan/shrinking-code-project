import sys, json, csv, math, argparse

def num(s):
    s = s.strip()
    if s == "?" or s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return s

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r]
    hdr = [h.strip() for h in rows[0]]
    return hdr, [[num(c) for c in r] for r in rows[1:]]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    if a.cmd != "choose":
        return
    th, tr = read(a.train)
    eh, te = read(a.test)
    goals = [n for n in th if n[-1] in "+-"]
    feats = [n for n in th if n[-1] not in "+-X"]
    stats = {}
    for g in goals:
        i = th.index(g)
        v = [r[i] for r in tr if isinstance(r[i], float)]
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0
        stats[g] = (mu, sd)

    def d2h(gv):
        s = 0
        for g in goals:
            mu, sd = stats[g]
            z = max(-3, min(3, (gv[g] - mu) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - (1 if g[-1] == "+" else 0)) ** 2
        return math.sqrt(s / len(goals))

    fstat = {}
    for f in feats:
        i = th.index(f)
        if f[0].isupper():
            v = [r[i] for r in tr if isinstance(r[i], float)]
            mu = sum(v) / len(v)
            sd = math.sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1)) or 1
            fstat[f] = (mu, sd)
    tcols = [(f, th.index(f), eh.index(f)) for f in feats if f in eh]

    def vec(row, k):
        out = []
        for f, ti, ei in tcols:
            v = row[ti if k == 0 else ei]
            if f in fstat:
                if not isinstance(v, float):
                    out.append(None)
                else:
                    out.append(max(-3, min(3, (v - fstat[f][0]) / fstat[f][1])))
            else:
                out.append(None if v is None else v)
        return out

    def dist(p, q):
        s = 0
        for (f, _, _), x, y in zip(tcols, p, q):
            if x is None or y is None:
                s += 1 if f not in fstat else 1
            elif f in fstat:
                s += min(1, abs(x - y) / 3) ** 2 * 1
            else:
                s += 0 if x == y else 1
        return math.sqrt(s / len(tcols))

    pool = []
    for r in tr:
        try:
            gv = {g: r[th.index(g)] for g in goals}
            if all(isinstance(x, float) for x in gv.values()):
                pool.append((vec(r, 0), d2h(gv)))
        except Exception:
            pass
    tv = [vec(r, 1) for r in te]
    done = {}
    base = sum(p[1] for p in pool) / max(1, len(pool))

    def pred(v):
        ds = sorted(((dist(v, p[0]), p[1]) for p in pool), key=lambda t: t[0])[:5]
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w) if ds else base

    n = min(10, len(te))
    for step in range(n):
        best, bs = None, 1e9
        for i in range(len(te)):
            if i in done:
                continue
            s = pred(tv[i])
            if step < 3 and done:  # encourage diversity early
                s -= 0.1 * min(dist(tv[i], tv[j]) for j in done)
            if s < bs:
                best, bs = i, s
        print(json.dumps({"inspect": best}))
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        sc = d2h(resp["goals"])
        done[best] = sc
        pool.append((tv[best], sc))
    rank = sorted(done, key=lambda i: (round(done[i], 12), i))[:3]
    print(json.dumps({"selected": rank}))
    sys.stdout.flush()

main()
