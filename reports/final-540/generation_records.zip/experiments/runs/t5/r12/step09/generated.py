import sys, csv, json, math
from bisect import bisect_right

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        rows = [r for r in csv.reader(f) if r]
    return [h.strip() for h in rows[0]], [[c.strip() for c in r] for r in rows[1:]]

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    h, T = load(tr)
    h2, E = load(te)
    num = [h.index(n) for n in ("Clndrs", "Volume", "Model")]
    org = h.index("origin")
    num2 = [h2.index(h[i]) for i in num]
    org2 = h2.index("origin")

    def fl(s):
        try:
            return float(s)
        except ValueError:
            return None

    def vec(r, nm, og):
        return [fl(r[i]) for i in nm], (None if r[og] == "?" else r[og])

    TR = [vec(r, num, org) for r in T]
    TE = [vec(r, num2, org2) for r in E]
    # robust location/scale
    loc, sc = [], []
    for j in range(3):
        xs = sorted(v[0][j] for v in TR if v[0][j] is not None)
        n = len(xs)
        m = xs[n // 2] if n else 0.0
        mad = sorted(abs(x - m) for x in xs)[n // 2] * 1.4826 if n else 0
        if mad < 1e-9:
            mu = sum(xs) / n if n else 0
            mad = math.sqrt(sum((x - mu) ** 2 for x in xs) / max(1, n - 1)) if n else 0
        if mad < 1e-9:
            mad = 1.0
        loc.append(m)
        sc.append(mad)

    def z(v):
        return [None if v[0][j] is None else (v[0][j] - loc[j]) / sc[j] for j in range(3)]

    ZT = [z(v) for v in TR]
    ZE = [z(v) for v in TE]

    def d(za, oa, zb, ob):
        s = 0.0
        for x, y in zip(za, zb):
            if x is not None and y is not None:
                s += (x - y) ** 2
        if oa is not None and ob is not None and oa != ob:
            s += 4.0
        return math.sqrt(s)

    K = 5

    def raw(zv, ov, skip=None):
        ds = sorted(d(zv, ov, ZT[i], TR[i][1]) for i in range(len(TR)) if i != skip)
        k = ds[:K]
        knn = sum(k) / len(k) if k else 0.0
        mz = max([abs(x) for x in zv if x is not None] or [0.0])
        return knn + 0.5 * mz

    base = sorted(raw(ZT[i], TR[i][1], i) for i in range(len(TR)))
    n = len(base)

    def score(r):
        return min(1.0, max(0.0, bisect_right(base, r) / n))

    thr = 0.95
    sc_out = [score(raw(ZE[i], TE[i][1])) for i in range(len(TE))]
    print(json.dumps({"scores": sc_out, "alerts": [s > thr for s in sc_out], "threshold": thr}))

if __name__ == "__main__":
    main()
