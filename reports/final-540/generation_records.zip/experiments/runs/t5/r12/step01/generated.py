import sys, csv, json, argparse
from math import exp, sqrt

def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, tr = read(a.train)
    _, te = read(a.test)
    goals = [(i, n) for i, n in enumerate(names) if n[-1] in "+-"]
    stats = {}
    for i, n in goals:
        vs = [float(r[i]) for r in tr if r[i] != "?"]
        mu = sum(vs) / len(vs)
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 0.0
        stats[i] = (mu, sd)
    scores = []
    for r in te:
        tot = 0.0
        for i, n in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            nv = 1 / (1 + exp(-1.702 * z))
            h = 1.0 if n[-1] == "+" else 0.0
            tot += (nv - h) ** 2
        scores.append(sqrt(tot / len(goals)))
    order = sorted(range(len(te)), key=lambda i: (scores[i], i))
    out = {"scores": scores, "top": order[:10], "best": order[0],
           "median": order[len(te) // 2], "worst": order[-1]}
    sys.stdout.write(json.dumps(out) + "\n")

if __name__ == "__main__":
    main()
