import sys, csv, json, math

GOALS = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def read(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]

def solve(A, b):
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for j in range(i, n + 1):
            M[i][j] /= d
        for r in range(n):
            if r != i and M[r][i]:
                f = M[r][i]
                for j in range(i, n + 1):
                    M[r][j] -= f * M[i][j]
    return [M[i][n] for i in range(n)]

def ridge(X, y, lam=1.0):
    k = len(X[0])
    A = [[sum(x[i] * x[j] for x in X) + (lam if i == j and i > 0 else 0)
          for j in range(k)] for i in range(k)]
    b = [sum(x[i] * t for x, t in zip(X, y)) for i in range(k)]
    return solve(A, b)

def same(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pv) + 1e-32)
    if cohen > 0.35:
        return False
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    if abs(s) / (n * m) > 0.197:
        return False
    sx, sy = sorted(xs), sorted(ys)
    i = j = 0
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v: i += 1
        while j < m and sy[j] <= v: j += 1
        d = max(d, abs(i / n - j / m))
    return d / math.sqrt(1 / n + 1 / m) <= 1.36

def main():
    a = sys.argv
    trp, tep = a[a.index("--train") + 1], a[a.index("--test") + 1]
    h, tr = read(trp)
    _, te = read(tep)
    ix = {n: i for i, n in enumerate(h)}
    ic, iv, im, io = ix["Clndrs"], ix["Volume"], ix["Model"], ix["origin"]
    ig = [ix[g] for g, _ in [("Lbs-", 0), ("Acc+", 0), ("Mpg+", 0)]]
    tr = [r for r in tr if all(num(r[i]) is not None for i in ig)]
    origins = sorted({r[io] for r in tr if r[io] != "?"})
    def col_mean(i):
        v = [num(r[i]) for r in tr if num(r[i]) is not None]
        return sum(v) / len(v) if v else 0.0
    mc, mv, mm = col_mean(ic), col_mean(iv), col_mean(im)
    sds = {}
    for nm, i, m_ in (("c", ic, mc), ("v", iv, mv), ("m", im, mm)):
        v = [num(r[i]) for r in tr if num(r[i]) is not None]
        sds[nm] = (math.sqrt(sum((x - m_) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0)
    def feat(r, usev):
        c = num(r[ic]); c = mc if c is None else c
        m = num(r[im]); m = mm if m is None else m
        f = [1.0, (c - mc) / sds["c"], (m - mm) / sds["m"]]
        if usev:
            v = num(r[iv]); v = mv if v is None else v
            f += [(v - mv) / sds["v"]]
        f += [1.0 if r[io] == o else 0.0 for o in origins]
        return f
    ys = [[num(r[i]) for r in tr] for i in ig]
    tys = [ys[0], ys[1], [math.log(max(v, 1e-6)) for v in ys[2]]]
    W = {}
    for usev in (True, False):
        X = [feat(r, usev) for r in tr]
        W[usev] = [ridge(X, t, 1.0) for t in tys]
    stats = []
    for y in ys:
        mu = sum(y) / len(y)
        sd = math.sqrt(sum((v - mu) ** 2 for v in y) / (len(y) - 1))
        stats.append((mu, sd))
    def d2h(vals):
        s = 0
        for v, (mu, sd), (_, hv) in zip(vals, stats, GOALS):
            z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - hv) ** 2
        return math.sqrt(s / 3)
    hist = [d2h([ys[0][i], ys[1][i], ys[2][i]]) for i in range(len(tr))]
    mpg, scores, alerts = [], [], []
    for k, r in enumerate(te):
        usev = num(r[iv]) is not None
        f = feat(r, usev)
        w = W[usev]
        p = [sum(x * c for x, c in zip(f, wi)) for wi in w]
        p[2] = math.exp(max(-5, min(6, p[2])))
        p[0] = max(p[0], 1.0)
        mpg.append(p[2])
        scores.append(min(1.0, max(0.0, d2h(p))))
        if k < 19 or len(hist) < 2:
            alerts.append(False)
        else:
            alerts.append(not same(hist, scores[-20:]))
    json.dump({"mpg": mpg, "scores": scores, "alerts": alerts}, sys.stdout)

if __name__ == "__main__":
    main()
