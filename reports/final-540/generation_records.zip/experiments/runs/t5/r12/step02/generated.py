import sys, csv, json
from math import exp, log, sqrt

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def read(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    h = rows[0]
    ix = {n: i for i, n in enumerate(h)}
    out = []
    for r in rows[1:]:
        out.append({n: (r[i] if i < len(r) else "?") for n, i in ix.items()})
    return out

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(M[k][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for k in range(i + 1, n):
            f = M[k][i] / d
            if f:
                for j in range(i, n + 1):
                    M[k][j] -= f * M[i][j]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n))) / (M[i][i] or 1e-12)
    return x

def main():
    a = sys.argv
    tr = read(a[a.index("--train") + 1])
    te = read(a[a.index("--test") + 1])
    stats = {}
    for k in ("Clndrs", "Volume", "Model"):
        v = [num(r.get(k, "?")) for r in tr]
        v = [x for x in v if x is not None]
        mu = sum(v) / len(v)
        sd = sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
        stats[k] = (mu, sd)
    origins = sorted({r.get("origin", "?") for r in tr} - {"?"})

    def feats(r, usevol):
        z = {}
        for k in ("Clndrs", "Volume", "Model"):
            x = num(r.get(k, "?"))
            mu, sd = stats[k]
            z[k] = 0.0 if x is None else (x - mu) / sd
        c, v, m = z["Clndrs"], z["Volume"], z["Model"]
        f = [1.0, c, m, c * c, m * m, c * m]
        f += [1.0 if r.get("origin") == o else 0.0 for o in origins]
        if usevol:
            f += [v, v * v, v * m, v * c]
        return f

    goals = {}
    for k in ("Lbs", "Acc", "Mpg"):
        pass
    gname = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    gs = {}
    for g in gname:
        v = [num(r.get(g, "?")) for r in tr]
        v = [x for x in v if x is not None]
        mu = sum(v) / len(v)
        sd = sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1))
        gs[g] = (mu, sd)

    def nm(g, x):
        mu, sd = gs[g]
        z = max(-3, min(3, (x - mu) / (sd + 1e-32)))
        return 1 / (1 + exp(-1.702 * z))

    def d2h(r):
        vs = [num(r.get(g, "?")) for g in gname]
        if any(x is None for x in vs):
            return None
        return sqrt(sum((nm(g, x) - gname[g]) ** 2 for g, x in zip(gname, vs)) / 3)

    targets = []
    for r in tr:
        mpg = num(r.get("Mpg+", "?"))
        targets.append((mpg if mpg is not None and mpg > 0 else None, d2h(r)))

    def fit(usevol, ti):
        X, Y = [], []
        for r, t in zip(tr, targets):
            y = t[ti]
            if y is None:
                continue
            X.append(feats(r, usevol))
            Y.append(log(y) if ti == 0 else y)
        n = len(X[0])
        lam = 0.5
        A = [[sum(x[i] * x[j] for x in X) + (lam if i == j and i > 0 else 0)
              for j in range(n)] for i in range(n)]
        b = [sum(x[i] * y for x, y in zip(X, Y)) for i in range(n)]
        return solve(A, b)

    ms = {(u, t): fit(u, t) for u in (True, False) for t in (0, 1)}
    mpgs, scores = [], []
    for r in te:
        u = num(r.get("Volume", "?")) is not None
        f = feats(r, u)
        p = sum(w * x for w, x in zip(ms[(u, 0)], f))
        mpg = exp(max(min(p, 5), 0))
        s = sum(w * x for w, x in zip(ms[(u, 1)], f))
        mpgs.append(mpg)
        scores.append(max(0.0, min(1.0, s)))
    print(json.dumps({"mpg": mpgs, "scores": scores}))

main()
