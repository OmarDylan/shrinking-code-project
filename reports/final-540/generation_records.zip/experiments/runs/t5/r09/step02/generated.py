import sys, csv, json, math

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r and any(c.strip() for c in r)]
    h = [c.strip() for c in rows[0]]
    return h, [[c.strip() for c in r] for r in rows[1:]]

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for j in range(i, n + 1):
            M[i][j] /= d
        for r in range(n):
            if r != i and M[r][i]:
                f = M[r][i]
                for j in range(i, n + 1):
                    M[r][j] -= f * M[i][j]
    return [M[i][n] for i in range(n)]

def fit(X, y, lam=1.0):
    n, k = len(X), len(X[0])
    mu = [sum(r[j] for r in X) / n for j in range(k)]
    sd = [math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / n) or 1.0 for j in range(k)]
    Z = [[(r[j] - mu[j]) / sd[j] for j in range(k)] for r in X]
    ym = sum(y) / n
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0) for j in range(k)] for i in range(k)]
    b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(k)]
    w = solve(A, b)
    return lambda x: ym + sum(w[j] * (x[j] - mu[j]) / sd[j] for j in range(k))

def main():
    a = sys.argv[1:]
    if not a or a[0] != "guess":
        return
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, R = load(tr)
    _, T = load(te)
    ix = {n: i for i, n in enumerate(h)}
    ci, vi, mi, oi = ix["Clndrs"], ix["Volume"], ix["Model"], ix["origin"]
    li, ai, pi = ix["Lbs-"], ix["Acc+"], ix["Mpg+"]
    D = []
    for r in R:
        v = [num(r[i]) for i in (ci, vi, mi, li, ai, pi)]
        if None in v:
            continue
        D.append((v, r[oi]))
    origins = sorted({o for _, o in D})
    # d2h on training
    gs = []
    for k in (3, 4, 5):
        c = [v[k] for v, _ in D]
        m = sum(c) / len(c)
        s = math.sqrt(sum((x - m) ** 2 for x in c) / (len(c) - 1)) if len(c) > 1 else 0
        gs.append((m, s))
    def nm(x, m, s):
        z = max(-3, min(3, (x - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    hv = (0, 1, 1)
    def d2h(g):
        return math.sqrt(sum((nm(g[i], *gs[i]) - hv[i]) ** 2 for i in range(3)) / 3)
    ymp = [math.log(max(v[5], 1e-6)) for v, _ in D]
    yd = [d2h(v[3:6]) for v, _ in D]
    cm = sum(v[0] for v, _ in D) / len(D)
    vm = sum(v[1] for v, _ in D) / len(D)
    mm = sum(v[2] for v, _ in D) / len(D)

    def feats(c, vol, m, o, withv):
        f = [c, c * c, m] + [1.0 if o == x else 0.0 for x in origins]
        f += [m * (1.0 if o == x else 0.0) for x in origins]
        if withv:
            f += [vol, math.log(max(vol, 1.0)), vol * m / 100.0]
        return f

    models = {}
    for wv in (True, False):
        X = [feats(v[0], v[1], v[2], o, wv) for v, o in D]
        models[wv] = (fit(X, ymp, 1.0), fit(X, yd, 1.0))

    mpg, sc = [], []
    for r in T:
        c = num(r[ci]); c = cm if c is None else c
        m = num(r[mi]); m = mm if m is None else m
        vol = num(r[vi])
        wv = vol is not None
        f = feats(c, vol if wv else vm, m, r[oi], wv)
        fm, fd = models[wv]
        p = math.exp(max(-5, min(6, fm(f))))
        d = min(1.0, max(0.0, fd(f)))
        mpg.append(p if math.isfinite(p) and p > 0 else 20.0)
        sc.append(d if math.isfinite(d) else 0.5)
    sys.stdout.write(json.dumps({"mpg": mpg, "scores": sc}))

main()
