import sys, json, math, csv, bisect

def read(p):
    with open(p, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def mean(v): return sum(v) / len(v)
def sd(v):
    m = mean(v)
    return math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1))

def same(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pool = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pool) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    d = max(abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m)
            for v in set(sx) | set(sy))
    ks = d / math.sqrt(1 / n + 1 / m)
    return cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    hn, trows = read(tr)
    tn, terows = read(te)
    ix = {n: i for i, n in enumerate(hn)}
    tx = {n: i for i, n in enumerate(tn)}
    numc = ["Clndrs", "Volume", "Model"]
    goals = ["Lbs-", "Acc+", "Mpg+"]
    X = [[num(r[ix[c]]) for c in numc] + [r[ix["origin"]]] for r in trows]
    Y = [[float(r[ix[g]]) for g in goals] for r in trows]
    sds = [sd([x[j] for x in X]) or 1.0 for j in range(3)]
    gm = [mean([y[j] for y in Y]) for j in range(3)]
    gs = [sd([y[j] for y in Y]) for j in range(3)]

    def d2h(v):
        t = 0
        for j in range(3):
            z = max(-3, min(3, (v[j] - gm[j]) / (gs[j] + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            t += (nv - (0 if j == 0 else 1)) ** 2
        return math.sqrt(t / 3)

    hist = [d2h(y) for y in Y]
    K = 5
    mpg, scores, alerts = [], [], []
    for r in terows:
        q = [num(r[tx[c]]) if c in tx else None for c in numc] + [r[tx["origin"]]]
        ds = []
        for x, y in zip(X, Y):
            s, c = 0.0, 0
            for j in range(3):
                if q[j] is not None and x[j] is not None:
                    s += ((q[j] - x[j]) / sds[j]) ** 2
                    c += 1
            s += 0.0 if q[3] == x[3] else 1.0
            c += 1
            ds.append((s / c, y))
        ds.sort(key=lambda t: t[0])
        nb = ds[:K]
        w = [1 / (d + 1e-3) for d, _ in nb]
        pred = [sum(wi * y[j] for wi, (_, y) in zip(w, nb)) / sum(w) for j in range(3)]
        pred[2] = max(pred[2], 1e-6)
        mpg.append(pred[2])
        scores.append(min(1.0, max(0.0, d2h(pred))))
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not same(hist, scores[i - 19:i + 1]))
    sys.stdout.write(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))

if __name__ == "__main__":
    main()
