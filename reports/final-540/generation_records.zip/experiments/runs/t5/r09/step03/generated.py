import sys, json
from math import sqrt

def stats(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs)/n, sum(ys)/m
    vx = sum((x-mx)**2 for x in xs)/(n-1)
    vy = sum((y-my)**2 for y in ys)/(m-1)
    pool = ((n-1)*vx + (m-1)*vy)/(n+m-2)
    cohen = abs(mx-my)/(sqrt(max(pool, 0.0))+1e-32)
    sy = sorted(ys)
    j = k = 0
    tot = 0
    for x in sorted(xs):
        while j < m and sy[j] < x: j += 1
        while k < m and sy[k] <= x: k += 1
        tot += j - (m-k)
    cliffs = abs(tot)/(n*m)
    sx = sorted(xs)
    i = j = 0
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v: i += 1
        while j < m and sy[j] <= v: j += 1
        d = max(d, abs(i/n - j/m))
    ks = d/sqrt(1/n + 1/m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}

def main():
    a = sys.argv[1:]
    if not a or a[0] != "certify":
        print("usage: main.py certify --train TRAIN --test CASES_JSON", file=sys.stderr)
        sys.exit(2)
    test = a[a.index("--test")+1]
    with open(test) as f:
        cases = json.load(f)
    out = {"comparisons": [stats([float(v) for v in c["xs"]], [float(v) for v in c["ys"]]) for c in cases]}
    sys.stdout.write(json.dumps(out))

if __name__ == "__main__":
    main()
