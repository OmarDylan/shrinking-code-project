import sys, csv, json, argparse
from math import exp, sqrt

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, tr = load(a.train)
    tn, te = load(a.test)
    goals = [(i, 0 if s[-1] == "-" else 1) for i, s in enumerate(names) if s[-1] in "+-"]
    stats = {}
    for i, _ in goals:
        vs = [float(r[i]) for r in tr if r[i] != "?"]
        n = len(vs)
        mu = sum(vs) / n
        sd = sqrt(sum((v - mu) ** 2 for v in vs) / (n - 1)) if n > 1 else 0.0
        stats[i] = (mu, sd)
    scores = []
    for r in te:
        t = 0.0
        for i, h in goals:
            mu, sd = stats[i]
            z = max(-3.0, min(3.0, (float(r[i]) - mu) / (sd + 1e-32)))
            nv = 1 / (1 + exp(-1.702 * z))
            t += (nv - h) ** 2
        scores.append(sqrt(t / len(goals)))
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {"scores": scores, "top": order[:10], "best": order[0],
           "median": order[len(order) // 2], "worst": order[-1]}
    sys.stdout.write(json.dumps(out))

main()
