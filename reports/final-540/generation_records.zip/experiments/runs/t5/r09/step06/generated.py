import sys, json, argparse
from math import exp, sqrt

def read(path):
    with open(path, encoding="utf-8-sig") as f:
        lines = [l.strip() for l in f if l.strip()]
    names = [s.strip() for s in lines[0].split(",")]
    rows = [[s.strip() for s in l.split(",")] for l in lines[1:]]
    return names, rows

def num(s):
    return None if s == "?" or s == "" else float(s)

def stats(vals):
    v = [x for x in vals if x is not None]
    n = len(v)
    if n == 0:
        return 0.0, 0.0
    mu = sum(v) / n
    sd = sqrt(sum((x - mu) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def norm(st, v):
    mu, sd = st
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + exp(-1.702 * z))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    names, tr = read(a.train)
    _, te = read(a.test)
    ix = {n: i for i, n in enumerate(names)}
    goals = [n for n in names if n[-1] in "+-" and n != "HpX"]
    heaven = {g: 0.0 if g[-1] == "-" else 1.0 for g in goals}
    numf = [n for n in names if n[0].isupper() and n[-1] not in "+-X"]
    catf = [n for n in names if n[0].islower()]
    feats = [n for n in names if n in numf or n in catf]
    gst = {g: stats([num(r[ix[g]]) for r in tr]) for g in goals}
    fst = {f: stats([num(r[ix[f]]) for r in tr]) for f in numf}

    def ggaps(r):
        return {g: abs(norm(gst[g], float(r[ix[g]])) - heaven[g]) for g in goals}

    def d2h(r):
        gp = ggaps(r)
        return sqrt(sum(v * v for v in gp.values()) / len(goals))

    trs = [d2h(r) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(trs[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    cutoff = sorted(trs)[len(tr) // 2]

    centers = {}
    for f in numf:
        c = []
        for grp in (good, poor):
            v = [x for x in (num(r[ix[f]]) for r in grp) if x is not None]
            c.append(norm(fst[f], sum(v) / len(v)) if v else None)
        centers[f] = c
    freqs = {}
    for f in catf:
        fr = []
        for grp in (good, poor):
            v = [r[ix[f]] for r in grp if r[ix[f]] != "?"]
            d = {}
            for x in v:
                d[x] = d.get(x, 0) + 1
            fr.append((d, len(v)))
        freqs[f] = fr

    def evidence(r):
        ev = {}
        for f in feats:
            s = r[ix[f]]
            if s == "?" or s == "":
                ev[f] = 0.0
            elif f in numf:
                gc, pc = centers[f]
                if gc is None or pc is None:
                    ev[f] = 0.0
                else:
                    x = norm(fst[f], float(s))
                    ev[f] = max(0.0, abs(x - gc) - abs(x - pc))
            else:
                (gd, gn), (pd, pn) = freqs[f]
                gf = gd.get(s, 0) / gn if gn else 0.0
                pf = pd.get(s, 0) / pn if pn else 0.0
                ev[f] = max(0.0, pf - gf)
        return ev

    def srt(d):
        return sorted(d, key=lambda n: (-round(d[n], 10), n))

    scores = [d2h(r) for r in te]
    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        gp = ggaps(te[j])
        ev = evidence(te[j])
        gorder = srt(gp)
        forder = srt(ev)
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            gw, gl = ggaps(te[winner]), ggaps(te[loser])
            diffs = {g: gl[g] ** 2 - gw[g] ** 2 for g in goals}
            adv = srt(diffs)[0]
        weakest = gorder[0]
        top = forder[0] if ev[forder[0]] > 1e-10 else None
        text = (f"Car {j} {'accepted' if accepted else 'rejected'}: score {s:.3f}, "
                f"other score {o:.3f}, cutoff {cutoff:.3f}; weakest goal {weakest}.")
        if winner is not None:
            text += f" Recommend car {winner}; largest advantage goal {adv}."
        else:
            text += " The comparison is a tie."
        if top is not None:
            text += f" Top feature {top} (retrospective, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": accepted, "winner": winner,
                    "advantage_goal": adv, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))

main()
