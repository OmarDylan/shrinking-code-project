import sys, csv, json, math

NUM = ["Clndrs", "Volume", "Model"]
CAT = ["origin"]


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rd = list(csv.reader(f))
    hdr = [h.strip() for h in rd[0]]
    idx = {h: hdr.index(h) for h in NUM + CAT if h in hdr}
    rows = []
    for r in rd[1:]:
        if not r or not "".join(r).strip():
            continue
        row = []
        for h in NUM + CAT:
            v = r[idx[h]].strip() if h in idx and idx[h] < len(r) else "?"
            if h in NUM:
                try:
                    v = float(v)
                    if not math.isfinite(v):
                        v = None
                except ValueError:
                    v = None
            else:
                v = None if v == "?" or v == "" else v
            row.append(v)
        rows.append(row)
    return rows


def med(xs):
    xs = sorted(xs)
    n = len(xs)
    return 0.0 if not n else (xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2)


def main():
    a = sys.argv
    tr = load(a[a.index("--train") + 1])
    te = load(a[a.index("--test") + 1])
    k = len(NUM)
    st = []
    for j in range(k):
        xs = [r[j] for r in tr if r[j] is not None]
        if not xs:
            st.append((0.0, 1.0, 1.0))
            continue
        mu = sum(xs) / len(xs)
        sd = math.sqrt(sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1)) or 1.0
        m = med(xs)
        mad = 1.4826 * med([abs(x - m) for x in xs])
        st.append((m, mad if mad > 1e-9 else sd, sd))
    cats = {}
    for r in tr:
        if r[k] is not None:
            cats[r[k]] = cats.get(r[k], 0) + 1
    ntr = max(1, len(tr))

    def dist(r, s):
        t, c = 0.0, 0
        for j in range(k):
            if r[j] is not None and s[j] is not None:
                g = max(-6, min(6, (r[j] - s[j]) / st[j][2]))
                t += g * g
                c += 1
        if r[k] is not None and s[k] is not None:
            t += 0.0 if r[k] == s[k] else 1.0
            c += 1
        return math.sqrt(t / c) if c else 1.0

    def raw(r, skip=None):
        ds = sorted(dist(r, s) for i, s in enumerate(tr) if i != skip)
        kk = min(5, len(ds))
        knn = sum(ds[:kk]) / kk if kk else 0.0
        z = 0.0
        for j in range(k):
            if r[j] is not None:
                z = max(z, abs(r[j] - st[j][0]) / st[j][1])
        if r[k] is not None:
            f = cats.get(r[k], 0) / ntr
            if f < 0.01:
                z = max(z, 3.0)
        return knn + 0.1 * min(z, 20.0)

    trs = [raw(r, i) for i, r in enumerate(tr)]
    srt = sorted(trs)
    q = srt[min(len(srt) - 1, int(0.95 * len(srt)))] if srt else 1.0
    q = max(q, 1e-9)

    def mp(s):
        return s / (s + q)

    thr = mp(q)
    scores = [mp(raw(r)) for r in te]
    scores = [min(1.0, max(0.0, s)) for s in scores]
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores],
                      "threshold": thr}))


if __name__ == "__main__":
    main()
