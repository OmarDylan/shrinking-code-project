import sys, csv, json, math

def norm(m, s, v):
    z = max(-3, min(3, (v - m) / (s + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def load(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]

def num(v):
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    hdr, train = load(tr)
    _, test = load(te)
    idx = {h: i for i, h in enumerate(hdr)}
    goals = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    nfeat = ["Clndrs", "Volume", "Model"]
    cfeat = ["origin"]

    gs = {g: stats([num(r[idx[g]]) for r in train if num(r[idx[g]]) is not None]) for g in goals}
    fs = {f: stats([num(r[idx[f]]) for r in train if num(r[idx[f]]) is not None]) for f in nfeat}

    scored = []
    for i, r in enumerate(train):
        vs = [num(r[idx[g]]) for g in goals]
        if any(v is None for v in vs):
            continue
        d = math.sqrt(sum((norm(*gs[g], v) - goals[g]) ** 2 for g, v in zip(goals, vs)) / 3)
        scored.append((round(d, 12), i))
    scored.sort()
    order = [i for _, i in scored]
    q = max(1, len(order) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]] if order else []

    centers = {}
    for f in nfeat:
        c = []
        for grp in (good, poor):
            vals = [num(r[idx[f]]) for r in grp if num(r[idx[f]]) is not None]
            c.append(norm(*fs[f], sum(vals) / len(vals)) if vals else None)
        centers[f] = c
    freqs = {}
    for f in cfeat:
        fr = []
        for grp in (good, poor):
            vals = [r[idx[f]] for r in grp if r[idx[f]] not in ("?", "")]
            cnt = {}
            for v in vals:
                cnt[v] = cnt.get(v, 0) + 1
            fr.append((cnt, len(vals)))
        freqs[f] = fr

    out = []
    for r in test:
        gd = {}
        for g, h in goals.items():
            v = num(r[idx[g]])
            gd[g] = 0.0 if v is None else abs(norm(*gs[g], v) - h)
        fd = {}
        for f in nfeat:
            v = num(r[idx[f]])
            gc, pc = centers[f]
            if v is None or gc is None or pc is None:
                fd[f] = 0.0
            else:
                x = norm(*fs[f], v)
                fd[f] = max(0.0, abs(x - gc) - abs(x - pc))
        for f in cfeat:
            v = r[idx[f]]
            if v in ("?", ""):
                fd[f] = 0.0
            else:
                (gc, gn), (pc, pn) = freqs[f]
                gf = gc.get(v, 0) / gn if gn else 0.0
                pf = pc.get(v, 0) / pn if pn else 0.0
                fd[f] = max(0.0, pf - gf)
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gd, "features": fd,
                    "goal_order": key(gd), "feature_order": key(fd)})
    print(json.dumps({"diagnoses": out}))

main()
