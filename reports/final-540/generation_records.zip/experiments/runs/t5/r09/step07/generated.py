import csv, sys, json, math, argparse

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}


def read(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    th, tr = read(a.train)
    eh, te = read(a.test)
    ti = {n: i for i, n in enumerate(th)}
    ei = {n: i for i, n in enumerate(eh)}

    # goal stats on training data
    st = {}
    for g in GOALS:
        vs = [num(r[ti[g]]) for r in tr]
        vs = [v for v in vs if v is not None]
        mu = sum(vs) / len(vs)
        sd = math.sqrt(sum((v - mu) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 0
        st[g] = (mu, sd)

    def d2h(gs):
        s = 0
        for g in GOALS:
            mu, sd = st[g]
            z = max(-3, min(3, (gs[g] - mu) / (sd + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - HEAVEN[g]) ** 2
        return math.sqrt(s / 3)

    nums = ["Clndrs", "Volume", "Model"]
    cat = "origin"
    xs = {}
    for n in nums:
        vs = [num(r[ti[n]]) for r in tr]
        vs = [v for v in vs if v is not None]
        mu = sum(vs) / len(vs)
        sd = math.sqrt(sum((v - mu) ** 2 for v in vs) / max(1, len(vs) - 1)) or 1
        xs[n] = (mu, sd)

    def feat(r, idx):
        out = []
        for n in nums:
            v = num(r[idx[n]]) if n in idx and idx[n] < len(r) else None
            out.append(None if v is None else (v - xs[n][0]) / xs[n][1])
        c = r[idx[cat]] if cat in idx and idx[cat] < len(r) else "?"
        out.append(None if c == "?" else c)
        return out

    def dist(p, q):
        s = 0
        for u, v in zip(p, q):
            if u is None or v is None:
                s += 0.5
            elif isinstance(u, str):
                s += 0 if u == v else 1
            else:
                s += min(abs(u - v), 3) ** 2 if False else (u - v) ** 2
        return math.sqrt(s / len(p))

    model = []
    for r in tr:
        gs = {g: num(r[ti[g]]) for g in GOALS}
        if any(v is None for v in gs.values()):
            continue
        model.append((feat(r, ti), d2h(gs)))

    tf = [feat(r, ei) for r in te]
    n = len(te)
    seen = {}

    def predict(x, k=5):
        ds = sorted(((dist(x, m[0]), m[1]) for m in model), key=lambda t: t[0])[:k]
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w)

    for _ in range(min(10, n)):
        best, bs = None, 1e30
        for i in range(n):
            if i in seen:
                continue
            s = predict(tf[i])
            if seen:
                s -= 0.05 * min(dist(tf[i], tf[j]) for j in seen)
            if s < bs or (s == bs and (best is None or i < best)):
                best, bs = i, s
        print(json.dumps({"inspect": best}))
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        gs = {g: float(resp["goals"][g]) for g in GOALS}
        seen[best] = d2h(gs)
        model.append((tf[best], seen[best]))
        # observed rows weigh more by duplicating
        model.append((tf[best], seen[best]))

    ranked = sorted(seen, key=lambda i: (round(seen[i], 12), i))[:3]
    print(json.dumps({"selected": ranked}))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
