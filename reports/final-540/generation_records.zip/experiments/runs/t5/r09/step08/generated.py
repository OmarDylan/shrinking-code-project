import sys, csv, json, math

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r]
    return [h.strip() for h in rows[0]], [[c.strip() for c in r] for r in rows[1:]]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def stats(vals):
    n = len(vals)
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def norm(st, v):
    mu, sd = st
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def main():
    a = sys.argv[1:]
    if not a or a[0] != "fix":
        sys.exit(1)
    tr_p = a[a.index("--train") + 1]
    te_p = a[a.index("--test") + 1]
    hn, tr = load(tr_p)
    hm, te = load(te_p)
    ix = {n: i for i, n in enumerate(hn)}
    jx = {n: i for i, n in enumerate(hm)}
    goals = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
    gst = [stats([num(r[ix[g]]) for r in tr]) for g, _ in goals]
    d2h = []
    for r in tr:
        s = 0.0
        for (g, h), st in zip(goals, gst):
            s += (norm(st, num(r[ix[g]])) - h) ** 2
        d2h.append(math.sqrt(s / 3))
    nums = ["Clndrs", "Volume", "Model"]
    nst = {c: stats([num(r[ix[c]]) for r in tr if num(r[ix[c]]) is not None]) for c in nums}
    # training feature vectors: (norm clndrs, norm volume, norm model, origin)
    def feat(row, idx):
        out = []
        for c in nums:
            v = num(row[idx[c]]) if c in idx else None
            out.append(None if v is None else norm(nst[c], v))
        out.append(row[idx["origin"]])
        return out
    trf = [feat(r, ix) for r in tr]
    n = len(tr)

    def d(f1, f2):
        s = 0.0
        for k in range(3):
            if f1[k] is None or f2[k] is None:
                g = 1.0
            else:
                g = f1[k] - f2[k]
            s += g * g
        s += 0.0 if f1[3] == f2[3] else 1.0
        return math.sqrt(s / 4)

    def predict(f):
        ds = sorted((round(d(f, t), 12), i) for i, t in enumerate(trf))
        return sum(d2h[i] for _, i in ds[:5]) / len(ds[:5])

    cutoff = sorted(d2h)[n // 2]
    order = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = order[:max(1, n // 4)]
    menu, seen = [], set()
    for i in good:
        p = (num(tr[i][ix["Clndrs"]]), num(tr[i][ix["Volume"]]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    reps = []
    for idx, row in enumerate(te):
        f = feat(row, jx)
        before = predict(f)
        if round(before, 10) <= round(cutoff, 10):
            reps.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        oc = num(row[jx["Clndrs"]])
        ov = num(row[jx["Volume"]])
        best = None
        for nc, nv in menu:
            ch = {}
            if oc != nc:
                ch["Clndrs"] = nc
            if ov != nv:
                ch["Volume"] = nv
            if not ch:
                continue
            g = list(f)
            g[0] = norm(nst["Clndrs"], nc)
            g[1] = norm(nst["Volume"], nv)
            after = predict(g)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(d(f, g), 10), round(after, 10), (nc, nv))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best is None:
            reps.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            reps.append({"row": idx, "before": before, "after": best[1], "changes": best[2], "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": reps}))

main()
