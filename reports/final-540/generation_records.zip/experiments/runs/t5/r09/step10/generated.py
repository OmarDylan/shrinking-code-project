import sys, json, math

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    G = ["Lbs-", "Acc+", "Mpg+"]
    H = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    with open(tr, encoding="utf-8-sig") as f:
        L = [l.strip().split(",") for l in f if l.strip()]
    hd = [h.strip() for h in L[0]]
    ix = {h: i for i, h in enumerate(hd)}
    rows = [[c.strip() for c in r] for r in L[1:]]
    rows = [r for r in rows if all(r[ix[g]] != "?" for g in G)]
    st = {}
    for g in G:
        v = [float(r[ix[g]]) for r in rows]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1))
        st[g] = (m, sd)

    def nm(g, v):
        m, sd = st[g]
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(gs):
        return math.sqrt(sum((nm(g, gs[g]) - H[g]) ** 2 for g in G) / 3)

    td = [d2h({g: float(r[ix[g]]) for g in G}) for r in rows]
    target = sorted(td)[len(td) // 4]
    NF = ["Clndrs", "Volume", "Model"]
    fs = {}
    for c in NF:
        v = [float(r[ix[c]]) for r in rows if r[ix[c]] != "?"]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1))
        fs[c] = (m, sd)

    def feat(get):
        o = []
        for c in NF:
            x = get(c)
            if x == "?" or x is None or x == "":
                o.append(None)
            else:
                m, sd = fs[c]
                z = max(-3, min(3, (float(x) - m) / (sd + 1e-32)))
                o.append(1 / (1 + math.exp(-1.702 * z)))
        o.append(get("origin"))
        return o

    def dist(p, q):
        s = 0
        for i in range(3):
            s += 1 if p[i] is None or q[i] is None else (p[i] - q[i]) ** 2
        s += 0 if p[3] == q[3] else 1
        return math.sqrt(s / 4)

    TF = [feat(lambda c, r=r: r[ix[c]]) for r in rows]
    D = json.load(open(te))
    th = {h: i for i, h in enumerate(D["header"])}
    R = D["rows"]

    def tf(i):
        return feat(lambda c: R[i][th[c]])

    def stats(xs, ys):
        n, m = len(xs), len(ys)
        mx, my = sum(xs) / n, sum(ys) / m
        vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
        vy = sum((y - my) ** 2 for y in ys) / (m - 1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
        cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
        k = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
                for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
        return {"cohen": co, "cliffs": cl, "ks": k,
                "same": bool(co <= 0.35 and cl <= 0.197 and k <= 1.36)}

    def inspect(e, s, i):
        print(json.dumps({"episode": e, "strategy": s, "inspect": i}), flush=True)
        r = json.loads(sys.stdin.readline())
        return d2h(r["goals"])

    def ltt(ds):
        for k, d in enumerate(ds):
            if round(d, 12) <= round(target, 12):
                return k + 1
        return 11

    res = []
    for e, ep in enumerate(D["episodes"]):
        pool = ep["pool"]
        F = {i: tf(i) for i in pool}
        base = {}
        for i in pool:
            ds = sorted(range(len(TF)), key=lambda j: (round(dist(F[i], TF[j]), 12), j))[:5]
            base[i] = sum(td[j] for j in ds) / len(ds)
        obs = []
        left = list(pool)
        while len(obs) < 10:
            def sc(i):
                if len(obs) < 3:
                    return base[i]
                sw = sr = 0
                for j, d in obs:
                    w = math.exp(-6 * dist(F[i], F[j]))
                    sw += w
                    sr += w * (d - base[j])
                return base[i] + sr / (sw + 1)
            c = min(left, key=lambda i: (sc(i), i))
            left.remove(c)
            obs.append((c, inspect(e, "adaptive", c)))
        ad = [d for _, d in obs]
        rd = [inspect(e, "random", i) for i in ep["random_order"][:10]]
        res.append((ad, rd))
    out = []
    for e, (ad, rd) in enumerate(res):
        out.append({"episode": e,
                    "adaptive": {"best5": min(ad[:5]), "best10": min(ad), "labels_to_target": ltt(ad)},
                    "random": {"best5": min(rd[:5]), "best10": min(rd), "labels_to_target": ltt(rd)}})
    cmp = {}
    for m in ["best5", "best10", "labels_to_target"]:
        cmp[m] = stats([float(o["adaptive"][m]) for o in out],
                       [float(o["random"][m]) for o in out])
    print(json.dumps({"results": out, "comparisons": cmp}), flush=True)

main()
