import sys, json, math, argparse
from bisect import bisect_right

def rd(path):
    rows = []
    with open(path, encoding="utf-8-sig") as f:
        for line in f:
            if line.strip():
                rows.append([s.strip() for s in line.strip().split(",")])
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        pv = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                k = M[r][c] / pv
                if k:
                    for j in range(c, n + 1):
                        M[r][j] -= k * M[c][j]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

def ridge(X, y, lam=1e-3):
    d = len(X[0])
    mu = [sum(r[j] for r in X) / len(X) for j in range(d)]
    sd = [(sum((r[j] - mu[j]) ** 2 for r in X) / len(X)) ** .5 or 1 for j in range(d)]
    Z = [[(r[j] - mu[j]) / sd[j] for j in range(d)] for r in X]
    ym = sum(y) / len(y)
    A = [[sum(z[i] * z[j] for z in Z) + (lam * len(X) if i == j else 0)
          for j in range(d)] for i in range(d)]
    b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(d)]
    w = solve(A, b)
    return lambda x: ym + sum(w[j] * (x[j] - mu[j]) / sd[j] for j in range(d))

def stats(v):
    m = sum(v) / len(v)
    s = (sum((x - m) ** 2 for x in v) / (len(v) - 1)) ** .5 if len(v) > 1 else 0
    return m, s

def same(xs, ys):
    n, m = len(xs), len(ys)
    mx, vx = stats(xs)
    my, vy = stats(ys)
    pool = ((n - 1) * vx ** 2 + (m - 1) * vy ** 2) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pool) + 1e-32)
    if cohen > 0.35:
        return False
    sx, sy = sorted(xs), sorted(ys)
    g = 0
    for x in xs:
        g += bisect_right(sy, x - 1e-300) * 0
    gt = lt = 0
    for x in xs:
        lo = sum(1 for y in ys if y < x)
        hi = sum(1 for y in ys if y <= x)
        gt += lo
        lt += m - hi
    if abs(gt - lt) / (n * m) > 0.197:
        return False
    d = max(abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m) for v in set(xs) | set(ys))
    return d / math.sqrt(1 / n + 1 / m) <= 1.36

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    th, tr = rd(a.train)
    eh, te = rd(a.test)
    ix = {n: i for i, n in enumerate(th)}
    ex = {n: i for i, n in enumerate(eh)}
    G = ["Lbs-", "Acc+", "Mpg+"]
    tr = [r for r in tr if all(num(r[ix[g]]) is not None for g in G)]
    ys = [[float(r[ix[g]]) for r in tr] for g in G]
    st = [stats(v) for v in ys]
    heaven = [0, 1, 1]

    def d2h(vals):
        t = 0
        for v, (m, s), h in zip(vals, st, heaven):
            z = max(-3, min(3, (v - m) / (s + 1e-32)))
            t += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
        return math.sqrt(t / 3)

    hist = [d2h([ys[k][i] for k in range(3)]) for i in range(len(tr))]
    origins = sorted({r[ix["origin"]] for r in tr if r[ix["origin"]] != "?"})
    def col(rows, idx, name):
        return [num(r[idx[name]]) for r in rows]
    means = {}
    for nme in ["Clndrs", "Volume", "Model"]:
        v = [x for x in col(tr, ix, nme) if x is not None]
        means[nme] = sum(v) / len(v)
    mode = max(origins, key=lambda o: sum(r[ix["origin"]] == o for r in tr))

    def feat(r, idx, vol):
        f = []
        for nme in ["Clndrs", "Model"] + (["Volume"] if vol else []):
            v = num(r[idx[nme]]) if idx[nme] < len(r) else None
            f.append(means[nme] if v is None else v)
        o = r[idx["origin"]] if idx["origin"] < len(r) else "?"
        if o == "?":
            o = mode
        f += [1.0 if o == k else 0.0 for k in origins[1:]]
        return f

    models = {}
    for vol in (True, False):
        X = [feat(r, ix, vol) for r in tr]
        models[vol] = [ridge(X, y) for y in ys]

    mpg, sc = [], []
    for r in te:
        v = num(r[ex["Volume"]]) if "Volume" in ex else None
        vol = v is not None
        f = feat(r, ex, vol)
        lbs, acc, mp = [m(f) for m in models[vol]]
        mp = max(mp, 1.0)
        lbs = max(lbs, 1.0)
        acc = max(acc, 1.0)
        mpg.append(mp)
        sc.append(min(1.0, max(0.0, d2h([lbs, acc, mp]))))
    al = []
    for i in range(len(sc)):
        al.append(False if i < 19 else not same(hist, sc[i - 19:i + 1]))
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": al}))

main()
