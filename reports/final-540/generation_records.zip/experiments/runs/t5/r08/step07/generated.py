import sys, json, math, argparse

def read(path):
    with open(path, encoding="utf-8-sig") as f:
        lines = [l.rstrip("\r\n").split(",") for l in f if l.strip()]
    return [h.strip() for h in lines[0]], [[c.strip() for c in r] for r in lines[1:]]

def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    hn, tr = read(a.train)
    ht, te = read(a.test)
    gi = {g: hn.index(g) for g in ("Lbs-", "Acc+", "Mpg+")}
    heaven = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    # goal stats
    st = {}
    for g, i in gi.items():
        v = [num(r[i]) for r in tr if i < len(r) and num(r[i]) is not None]
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0
        st[g] = (mu, sd)

    def d2h(vals):
        s = 0
        for g in gi:
            mu, sd = st[g]
            z = max(-3, min(3, (vals[g] - mu) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - heaven[g]) ** 2
        return math.sqrt(s / 3)

    numc = ["Clndrs", "Volume", "Model"]
    catc = ["origin"]
    ni = [hn.index(c) for c in numc]
    ci = [hn.index(c) for c in catc]
    nti = [ht.index(c) for c in numc]
    cti = [ht.index(c) for c in catc]
    ns = []
    for i in ni:
        v = [num(r[i]) for r in tr if num(r[i]) is not None]
        mu = sum(v) / len(v)
        sd = math.sqrt(sum((x - mu) ** 2 for x in v) / max(1, len(v) - 1)) or 1
        ns.append((mu, sd))

    def feat(r, nidx, cidx):
        f = []
        for (mu, sd), i in zip(ns, nidx):
            x = num(r[i]) if i < len(r) else None
            f.append(None if x is None else (x - mu) / sd)
        for i in cidx:
            x = r[i] if i < len(r) else "?"
            f.append(None if x in ("?", "") else x)
        return f

    def dist(p, q):
        s = 0
        for x, y in zip(p, q):
            if x is None or y is None:
                s += 1
            elif isinstance(x, str):
                s += x != y
            else:
                s += min(abs(x - y), 3) ** 2
        return math.sqrt(s / len(p))

    trf = []
    for r in tr:
        vals = {g: num(r[i]) for g, i in gi.items()}
        if any(v is None for v in vals.values()):
            continue
        trf.append((feat(r, ni, ci), d2h(vals)))
    tef = [feat(r, nti, cti) for r in te]

    def pred(f, k=5):
        ds = sorted((dist(f, p), y) for p, y in trf)[:k]
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w)

    base = [pred(f) for f in tef]
    seen = {}
    n = len(te)
    for _ in range(min(10, n)):
        best, bs = None, None
        for j in range(n):
            if j in seen:
                continue
            adj, ws = 0, 0
            for i, y in seen.items():
                w = 1 / (dist(tef[j], tef[i]) + 0.05) ** 2
                adj += w * (y - base[i])
                ws += w
            sc = base[j] + (adj / (ws + 5) if seen else 0)
            if bs is None or sc < bs:
                best, bs = j, sc
        print(json.dumps({"inspect": best}))
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        seen[best] = d2h(resp["goals"])
    order = sorted(seen, key=lambda i: (round(seen[i], 12), i))[:3]
    print(json.dumps({"selected": order}))
    sys.stdout.flush()

main()
