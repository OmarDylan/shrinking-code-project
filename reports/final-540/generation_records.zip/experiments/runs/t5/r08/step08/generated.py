import sys, json, csv
from math import exp, sqrt

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        r = [[c.strip() for c in l] for l in csv.reader(f) if l]
    return r[0], r[1:]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def stats(v):
    m = sum(v) / len(v)
    sd = sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
    return m, sd

def norm(st, v):
    m, sd = st
    z = max(-3, min(3, (v - m) / (sd + 1e-32)))
    return 1 / (1 + exp(-1.702 * z))

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    h, T = load(tr)
    h2, S = load(te)
    ix = {n: i for i, n in enumerate(h)}
    ix2 = {n: i for i, n in enumerate(h2)}
    goals = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
    gst = {g: stats([num(r[ix[g]]) for r in T]) for g, _ in goals}
    d2h = []
    for r in T:
        s = sum((norm(gst[g], num(r[ix[g]])) - hv) ** 2 for g, hv in goals)
        d2h.append(sqrt(s / 3))
    nums = ["Clndrs", "Volume", "Model"]
    nst = {c: stats([num(r[ix[c]]) for r in T if num(r[ix[c]]) is not None]) for c in nums}

    def mk(row, idx):
        v = []
        for c in nums:
            x = num(row[idx[c]]) if c in idx else None
            v.append(None if x is None else norm(nst[c], x))
        v.append(row[idx["origin"]] if "origin" in idx else "?")
        return v

    def gap(x, y, k):
        if k == 3:
            return 0.0 if x == y else 1.0
        if x is None or y is None:
            return 1.0
        return x - y

    def dist(a_, b_):
        return sqrt(sum(gap(a_[k], b_[k], k) ** 2 for k in range(4)) / 4)

    TX = [mk(r, ix) for r in T]
    n = len(T)

    def pred(x):
        o = sorted(range(n), key=lambda i: (round(dist(x, TX[i]), 12), i))[:5]
        return sum(d2h[i] for i in o) / len(o)

    cutoff = sorted(d2h)[n // 2]
    rk = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = rk[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (num(T[i][ix["Clndrs"]]), num(T[i][ix["Volume"]]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    def out(v):
        return int(v) if float(v).is_integer() else v

    res = []
    for ri, row in enumerate(S):
        x = mk(row, ix2)
        c0 = num(row[ix2["Clndrs"]])
        v0 = num(row[ix2["Volume"]])
        b = pred(x)
        if round(b, 10) <= round(cutoff, 10):
            res.append({"row": ri, "before": b, "after": b, "changes": {}, "status": "already_good"})
            continue
        best = None
        for nc, nv in menu:
            ch = {}
            if c0 != nc:
                ch["Clndrs"] = out(nc)
            if v0 != nv:
                ch["Volume"] = out(nv)
            if not ch:
                continue
            y = list(x)
            y[0] = norm(nst["Clndrs"], nc)
            y[1] = norm(nst["Volume"], nv)
            af = pred(y)
            if round(b - af, 10) >= 0.05:
                key = (len(ch), round(dist(x, y), 10), round(af, 10), (nc, nv))
                if best is None or key < best[0]:
                    best = (key, af, ch)
        if best:
            res.append({"row": ri, "before": b, "after": best[1], "changes": best[2], "status": "improved"})
        else:
            res.append({"row": ri, "before": b, "after": b, "changes": {}, "status": "no_candidate"})
    sys.stdout.write(json.dumps({"repairs": res}))

if __name__ == "__main__":
    main()
