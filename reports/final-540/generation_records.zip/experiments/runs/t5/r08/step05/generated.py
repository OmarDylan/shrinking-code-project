import sys, csv, json, math

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    if s == "?" or s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def mk_norm(mu, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    a = sys.argv[1:]
    train_p = a[a.index("--train") + 1]
    test_p = a[a.index("--test") + 1]
    hdr, tr = load(train_p)
    h2, te = load(test_p)
    feats, goals = [], []
    for i, n in enumerate(hdr):
        if n.endswith("X"):
            continue
        if n[-1] in "+-":
            goals.append((i, n, 0.0 if n[-1] == "-" else 1.0))
        else:
            feats.append((i, n, n[0].isupper()))
    gn = {}
    for i, n, h in goals:
        gn[i] = mk_norm(*stats([float(r[i]) for r in tr]))
    def d2h(r):
        return math.sqrt(sum((gn[i](float(r[i])) - h) ** 2 for i, n, h in goals) / len(goals))
    ds = [round(d2h(r), 12) for r in tr]
    order = sorted(range(len(tr)), key=lambda k: (ds[k], k))
    q = max(1, len(tr) // 4)
    good = [tr[k] for k in order[:q]]
    poor = [tr[k] for k in order[-q:]]
    fn = {}
    for i, n, isnum in feats:
        if isnum:
            nf = mk_norm(*stats([v for v in (num(r[i]) for r in tr) if v is not None]))
            def center(g, i=i, nf=nf):
                vs = [v for v in (num(r[i]) for r in g) if v is not None]
                return nf(sum(vs) / len(vs)) if vs else None
            fn[i] = (nf, center(good), center(poor))
        else:
            def freq(g, i=i):
                vs = [r[i] for r in g if r[i] != "?" and r[i] != ""]
                c = {}
                for v in vs:
                    c[v] = c.get(v, 0) + 1
                return c, len(vs)
            fn[i] = (freq(good), freq(poor))
    out = []
    for r in te:
        gs = {n: abs(gn[i](float(r[i])) - h) for i, n, h in goals}
        fs = {}
        for i, n, isnum in feats:
            ev = 0.0
            if isnum:
                x = num(r[i])
                nf, gc, pc = fn[i]
                if x is not None and gc is not None and pc is not None:
                    nx = nf(x)
                    ev = max(0.0, abs(nx - gc) - abs(nx - pc))
            else:
                if r[i] not in ("?", ""):
                    (gc, gt), (pc, pt) = fn[i]
                    pf = pc.get(r[i], 0) / pt if pt else 0.0
                    gf = gc.get(r[i], 0) / gt if gt else 0.0
                    ev = max(0.0, pf - gf)
            fs[n] = ev
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    sys.stdout.write(json.dumps({"diagnoses": out}))

if __name__ == "__main__":
    main()
