import sys, json, csv, math, argparse

G = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
NUMF = ["Clndrs", "Volume", "Model"]


def num(v):
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def stats(vals):
    n = len(vals)
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd


def norm(v, mu, sd):
    z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def mean(x):
    return sum(x) / len(x)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    vx = sum((x - mean(xs)) ** 2 for x in xs) / (n - 1)
    vy = sum((y - mean(ys)) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    c = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    s = sum((x > y) - (x < y) for x in xs for y in ys)
    cl = abs(s) / (n * m)
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m))
    k = d / math.sqrt(1 / n + 1 / m)
    return {"cohen": c, "cliffs": cl, "ks": k,
            "same": bool(c <= 0.35 and cl <= 0.197 and k <= 1.36)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()

    with open(a.train, encoding="utf-8-sig") as f:
        tr = [r for r in csv.reader(f) if r and any(c.strip() for c in r)]
    th = [h.strip() for h in tr[0]]
    trows = [[c.strip() for c in r] for r in tr[1:]]
    gi = [th.index(g) for g, _ in G]
    gst = [stats([float(r[i]) for r in trows]) for i in gi]

    def d2h(vals):
        s = 0
        for (g, h), v, (mu, sd) in zip(G, vals, gst):
            s += (norm(v, mu, sd) - h) ** 2
        return math.sqrt(s / 3)

    tscore = [d2h([float(r[i]) for i in gi]) for r in trows]
    target = sorted(tscore)[len(trows) // 4]

    fi = [th.index(n) for n in NUMF]
    oi = th.index("origin")
    fst = [stats([float(r[i]) for r in trows]) for i in fi]

    def vec(row, h):
        out = []
        for i, (mu, sd) in zip([h.index(n) for n in NUMF], fst):
            v = num(row[i])
            out.append(None if v is None or row[i] == "?" else norm(v, mu, sd))
        o = row[h.index("origin")]
        out.append(None if str(o).strip() == "?" else str(o).strip())
        return out

    def dist(p, q):
        s = 0
        for x, y in zip(p, q):
            if x is None or y is None:
                s += 1
            elif isinstance(x, str) or isinstance(y, str):
                s += x != y
            else:
                s += (x - y) ** 2
        return math.sqrt(s / len(p))

    tv = [vec(r, th) for r in trows]

    with open(a.test, encoding="utf-8-sig") as f:
        data = json.load(f)
    h = data["header"]
    rows = data["rows"]
    cache = {}

    def fv(i):
        if i not in cache:
            cache[i] = vec(rows[i], h)
        return cache[i]

    base = {}

    def knn(i):
        if i not in base:
            v = fv(i)
            ds = sorted((round(dist(v, t), 12), j) for j, t in enumerate(tv))[:5]
            base[i] = mean([tscore[j] for _, j in ds])
        return base[i]

    def inspect(ep, strat, idx):
        print(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}))
        sys.stdout.flush()
        r = json.loads(sys.stdin.readline())
        g = r["goals"]
        return d2h([float(g[n]) for n, _ in G])

    def adaptive(ep, pool):
        obs = []  # (idx, observed, residual)
        left = list(pool)
        for _ in range(10):
            def est(i):
                w = [(math.exp(-(dist(fv(i), fv(j)) / 0.3) ** 2), r) for j, _, r in obs]
                sw = sum(x for x, _ in w)
                corr = sum(x * r for x, r in w) / (sw + 1) if obs else 0
                return knn(i) + corr
            i = min(left, key=lambda k: (est(k), k))
            left.remove(i)
            y = inspect(ep, "adaptive", i)
            obs.append((i, y, y - knn(i)))
        return [y for _, y, _ in obs]

    def summ(ys):
        t = round(target, 12)
        lab = next((k + 1 for k, y in enumerate(ys) if round(y, 12) <= t), 11)
        return {"best5": min(ys[:5]), "best10": min(ys), "labels_to_target": lab}

    results = []
    for e, ep in enumerate(data["episodes"]):
        ad = summ(adaptive(e, ep["pool"]))
        rd = summ([inspect(e, "random", i) for i in ep["random_order"][:10]])
        results.append({"episode": e, "adaptive": ad, "random": rd})

    comp = {}
    for m in ["best5", "best10", "labels_to_target"]:
        comp[m] = certify([float(r["adaptive"][m]) for r in results],
                          [float(r["random"][m]) for r in results])
    print(json.dumps({"results": results, "comparisons": comp}))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
