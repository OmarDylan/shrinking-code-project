import sys, json, csv, bisect, math

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r and any(c.strip() for c in r)]
    h = [c.strip() for c in rows[0]]
    ix = {n: h.index(n) for n in NUM + [CAT]}
    out = []
    for r in rows[1:]:
        r = [c.strip() for c in r]
        v = []
        for n in NUM:
            try:
                x = float(r[ix[n]])
                v.append(x if math.isfinite(x) else None)
            except (ValueError, IndexError):
                v.append(None)
        c = r[ix[CAT]] if ix[CAT] < len(r) else "?"
        v.append(None if c == "?" or c == "" else c)
        out.append(v)
    return out

def med(xs):
    xs = sorted(xs)
    n = len(xs)
    if not n:
        return 0.0
    return xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2

def fit(train):
    st = []
    for j in range(3):
        xs = [r[j] for r in train if r[j] is not None]
        m = med(xs)
        s = 1.4826 * med([abs(x - m) for x in xs])
        if s < 1e-9:
            mu = sum(xs) / max(1, len(xs))
            s = (sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1)) ** .5 if len(xs) > 1 else 0
        if s < 1e-9:
            s = 1.0
        st.append((m, s))
    return st

def dist(a, b, st):
    t, n = 0.0, 0
    for j in range(3):
        if a[j] is not None and b[j] is not None:
            t += ((a[j] - b[j]) / st[j][1]) ** 2
            n += 1
    if a[3] is not None and b[3] is not None:
        t += 1.0 * (a[3] != b[3]) * 4
        n += 1
    return math.sqrt(t / n) if n else 0.0

def raw(r, train, st, skip=None, k=5):
    ds = sorted(dist(r, t, st) for i, t in enumerate(train) if i != skip)
    kn = sum(ds[:k]) / max(1, len(ds[:k]))
    zs = [abs(r[j] - st[j][0]) / st[j][1] for j in range(3) if r[j] is not None]
    mz = max(zs) if zs else 0.0
    return kn + 0.5 * mz

def main():
    a = sys.argv[1:]
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    train, test = load(tr), load(te)
    st = fit(train)
    ref = sorted(raw(r, train, st, skip=i) for i, r in enumerate(train))
    n = len(ref)
    scores = []
    for r in test:
        s = raw(r, train, st)
        p = bisect.bisect_right(ref, s) / n if n else 0.0
        scores.append(min(1.0, max(0.0, p)))
    thr = 0.95
    print(json.dumps({"scores": scores,
                      "alerts": [s > thr for s in scores],
                      "threshold": thr}))

if __name__ == "__main__":
    main()
