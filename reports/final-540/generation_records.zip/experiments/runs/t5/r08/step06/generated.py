import sys, csv, json, math

def load(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = [r for r in csv.reader(f) if r]
    return [c.strip() for c in rows[0]], rows[1:]

def main():
    a = sys.argv
    tr, te = a[a.index("--train") + 1], a[a.index("--test") + 1]
    names, trr = load(tr)
    _, ter = load(te)
    ix = {n: i for i, n in enumerate(names)}
    goals = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    nums = ["Clndrs", "Volume", "Model"]
    feats = nums + ["origin"]

    def val(r, n):
        s = r[ix[n]].strip()
        if s == "?" or s == "":
            return None
        return s if n == "origin" else float(s)

    st = {}
    for n in list(goals) + nums:
        v = [x for x in (val(r, n) for r in trr) if x is not None]
        m = sum(v) / len(v) if v else 0.0
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st[n] = (m, sd)

    def norm(n, v):
        m, sd = st[n]
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def gaps(r):
        return {g: abs(norm(g, val(r, g)) - h) for g, h in goals.items()}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    trs = [d2h(r) for r in trr]
    order = sorted(range(len(trr)), key=lambda i: (round(trs[i], 12), i))
    q = max(1, len(trr) // 4)
    good = [trr[i] for i in order[:q]]
    poor = [trr[i] for i in order[-q:]]
    cutoff = sorted(trs)[len(trs) // 2]

    centers = {}
    for n in nums:
        cs = []
        for grp in (good, poor):
            v = [x for x in (val(r, n) for r in grp) if x is not None]
            cs.append(norm(n, sum(v) / len(v)) if v else None)
        centers[n] = cs

    def freq(grp, c):
        v = [x for x in (val(r, "origin") for r in grp) if x is not None]
        return v.count(c) / len(v) if v else 0.0

    def evid(r):
        e = {}
        for n in nums:
            x = val(r, n)
            gc, pc = centers[n]
            if x is None or gc is None or pc is None:
                e[n] = 0.0
            else:
                nx = norm(n, x)
                e[n] = max(0.0, abs(nx - gc) - abs(nx - pc))
        c = val(r, "origin")
        e["origin"] = 0.0 if c is None else max(0.0, freq(poor, c) - freq(good, c))
        return e

    def srt(d):
        return sorted(d, key=lambda k: (-round(d[k], 10), k))

    scores = [d2h(r) for r in ter]
    gp = [gaps(r) for r in ter]
    n = len(ter)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lo = k if win == j else j
            d = {g: gp[lo][g] ** 2 - gp[win][g] ** 2 for g in goals}
            adv = srt(d)[0]
        go = srt(gp[j])
        weak = go[0]
        ev = evid(ter[j])
        fo = srt(ev)
        top = fo[0] if ev[fo[0]] > 1e-10 else None
        t = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
             f"other score {o:.3f}, cutoff {cutoff:.3f}; weakest goal {weak}. ")
        if win is not None:
            t += f"Recommend car {win} over car {k if win == j else j}; largest advantage in {adv}. "
        else:
            t += "Scores tie. "
        if top:
            t += f"Top feature {top} (retrospective association, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": t})
    sys.stdout.write(json.dumps({"explanations": out}))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "justify":
        main()
