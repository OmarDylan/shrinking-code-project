import sys, json, csv, math

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    def rd(p):
        with open(p, encoding='utf-8-sig', newline='') as f:
            r = [x for x in csv.reader(f) if x]
        return [h.strip() for h in r[0]], [[c.strip() for c in x] for x in r[1:]]
    hn, trr = rd(tr)
    hn2, ter = rd(te)
    ix = {n: i for i, n in enumerate(hn)}
    ix2 = {n: i for i, n in enumerate(hn2)}
    goals = [('Lbs-', 0), ('Acc+', 1), ('Mpg+', 1)]

    def num(s):
        try:
            return float(s)
        except Exception:
            return None
    G = []
    for r in trr:
        try:
            G.append([float(r[ix[g]]) for g, _ in goals])
        except Exception:
            G.append(None)
    st = []
    for k in range(3):
        v = [g[k] for g in G if g]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1))
        st.append((m, sd))

    def d2h(g):
        s = 0
        for k, (_, h) in enumerate(goals):
            z = max(-3, min(3, (g[k] - st[k][0]) / (st[k][1] + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
        return math.sqrt(s / 3)
    nf = ['Clndrs', 'Volume', 'Model']
    stx = {}
    for n in nf:
        v = [num(r[ix[n]]) for r in trr]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        stx[n] = (m, math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) + 1e-32)

    def feat(r, ixm):
        f = []
        for n in nf:
            x = num(r[ixm[n]])
            f.append(None if x is None else (x - stx[n][0]) / stx[n][1])
        f.append(r[ixm['origin']])
        return f

    def dist(p, q):
        s = 0
        for u, v in zip(p, q):
            if u is None or v is None or u == '?' or v == '?':
                s += 1
            elif isinstance(u, str):
                s += u != v
            else:
                s += min(abs(u - v) / 2, 1) ** 2 * 1
        return math.sqrt(s / len(p))
    TF = [(feat(r, ix), d2h(g)) for r, g in zip(trr, G) if g]
    XF = [feat(r, ix2) for r in ter]
    pred = []
    for f in XF:
        d = sorted((dist(f, t), y) for t, y in TF)[:7]
        w = [1 / (x + 0.05) for x, _ in d]
        pred.append(sum(wi * y for wi, (_, y) in zip(w, d)) / sum(w))
    n = len(ter)
    obs = {}
    budget = min(10, n)
    while len(obs) < budget:
        best, bs = None, 1e9
        for i in range(n):
            if i in obs:
                continue
            s = pred[i]
            if obs:
                num_, den = 0, 1e-9
                for j, y in obs.items():
                    w = math.exp(-4 * dist(XF[i], XF[j]))
                    num_ += w * (y - pred[j])
                    den += w
                s += num_ / (den + 0.5)
            if s < bs:
                best, bs = i, s
        print(json.dumps({"inspect": best}), flush=True)
        resp = json.loads(sys.stdin.readline())
        g = resp["goals"]
        obs[best] = d2h([g[k] for k, _ in goals])
    top = sorted(obs, key=lambda i: (round(obs[i], 12), i))[:3]
    print(json.dumps({"selected": top}), flush=True)

main()
