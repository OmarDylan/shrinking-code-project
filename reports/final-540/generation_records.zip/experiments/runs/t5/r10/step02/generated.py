import sys, json, math

def read(p):
    with open(p, encoding="utf-8-sig") as f:
        L = [[c.strip() for c in l.split(",")] for l in f if l.strip()]
    return L[0], L[1:]

def num(s):
    try:
        return float(s)
    except ValueError:
        return None

def solve(A, b):
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for r in range(n):
            if r != i:
                k = M[r][i] / d
                if k:
                    M[r] = [a - k * c for a, c in zip(M[r], M[i])]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

class Ridge:
    def __init__(self, X, y, lam=1.0):
        n, m = len(X), len(X[0])
        self.mu = [sum(r[j] for r in X) / n for j in range(m)]
        self.sd = [(sum((r[j] - self.mu[j]) ** 2 for r in X) / n) ** .5 or 1 for j in range(m)]
        Z = [self.t(r) for r in X]
        self.ym = sum(y) / n
        A = [[sum(z[i] * z[j] for z in Z) + (lam * n / 50 if i == j else 0) for j in range(m)] for i in range(m)]
        b = [sum(z[i] * (v - self.ym) for z, v in zip(Z, y)) for i in range(m)]
        self.w = solve(A, b)
    def t(self, r):
        return [(v - m) / s for v, m, s in zip(r, self.mu, self.sd)]
    def __call__(self, r):
        return self.ym + sum(w * z for w, z in zip(self.w, self.t(r)))

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, rows = read(tr)
    th, trows = read(te)
    ix = {n: i for i, n in enumerate(h)}
    tx = {n: i for i, n in enumerate(th)}
    def get(r, ixm, n):
        i = ixm.get(n)
        return num(r[i]) if i is not None and i < len(r) else None
    # training data
    D = []
    for r in rows:
        g = [get(r, ix, k) for k in ("Lbs-", "Acc+", "Mpg+")]
        if None in g:
            continue
        D.append((r, g))
    stats = []
    for j in range(3):
        v = [g[j] for _, g in D]
        m = sum(v) / len(v)
        s = (sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) ** .5
        stats.append((m, s))
    hv = [0, 1, 1]
    def d2h(g):
        t = 0
        for j in range(3):
            z = max(-3, min(3, (g[j] - stats[j][0]) / (stats[j][1] + 1e-32)))
            t += (1 / (1 + math.exp(-1.702 * z)) - hv[j]) ** 2
        return math.sqrt(t / 3)
    origins = sorted({r[ix["origin"]] for r, _ in D if "origin" in ix})
    def avg(n):
        v = [x for x in (get(r, ix, n) for r, _ in D) if x is not None]
        return sum(v) / len(v) if v else 0
    dm = {n: avg(n) for n in ("Clndrs", "Volume", "Model")}
    def feat(r, ixm, usevol):
        f = []
        c = get(r, ixm, "Clndrs"); c = dm["Clndrs"] if c is None else c
        m = get(r, ixm, "Model"); m = dm["Model"] if m is None else m
        f += [c, m, c * m / 10]
        o = r[ixm["origin"]] if "origin" in ixm and ixm["origin"] < len(r) else "?"
        f += [1.0 if o == k else 0.0 for k in origins]
        if usevol:
            v = get(r, ixm, "Volume"); v = dm["Volume"] if v is None else v
            f += [v, math.log(v + 1), v * v / 1000, v * m / 100]
        return f
    models = {}
    for uv in (True, False):
        X = [feat(r, ix, uv) for r, _ in D]
        ym = [math.log(max(g[2], 1e-3)) for _, g in D]
        yd = [d2h(g) for _, g in D]
        models[uv] = (Ridge(X, ym), Ridge(X, yd))
    mpgm = sum(g[2] for _, g in D) / len(D)
    dmean = sum(d2h(g) for _, g in D) / len(D)
    mp, sc = [], []
    for r in trows:
        v = get(r, tx, "Volume")
        uv = v is not None
        x = feat(r, tx, uv)
        try:
            p = math.exp(models[uv][0](x))
            d = models[uv][1](x)
        except Exception:
            p, d = mpgm, dmean
        if not math.isfinite(p) or p <= 0:
            p = mpgm
        if not math.isfinite(d):
            d = dmean
        mp.append(p)
        sc.append(min(1.0, max(0.0, d)))
    print(json.dumps({"mpg": mp, "scores": sc}))

main()
