import sys, json, csv, math, argparse

GOALS = ["Lbs-", "Acc+", "Mpg+"]
NUMX = ["Clndrs", "Volume", "Model"]


def load_train(path):
    with open(path, encoding="utf-8-sig") as f:
        rd = [r for r in csv.reader(f) if r]
    return [c.strip() for c in rd[0]], [[c.strip() for c in r] for r in rd[1:]]


def fnum(v):
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def msd(xs):
    n = len(xs)
    m = sum(xs) / n
    return m, math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1)) if n > 1 else 0.0


def mean(xs):
    return sum(xs) / len(xs)


def cohen(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = mean(xs), mean(ys)
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    p = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    return abs(mx - my) / (math.sqrt(p) + 1e-32)


def cliffs(xs, ys):
    s = sum((x > y) - (x < y) for x in xs for y in ys)
    return abs(s) / (len(xs) * len(ys))


def ks(xs, ys):
    n, m = len(xs), len(ys)
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m))
    return d / math.sqrt(1 / n + 1 / m)


def compare(xs, ys):
    c, l, k = cohen(xs, ys), cliffs(xs, ys), ks(xs, ys)
    return {"cohen": c, "cliffs": l, "ks": k,
            "same": bool(c <= 0.35 and l <= 0.197 and k <= 1.36)}


def race(train_path, test_path):
    th, trows = load_train(train_path)
    ti = {h: i for i, h in enumerate(th)}
    gst = {}
    for g in GOALS:
        gst[g] = msd([float(r[ti[g]]) for r in trows])

    def d2h(goals):
        s = 0.0
        for g in GOALS:
            mu, sd = gst[g]
            z = max(-3, min(3, (float(goals[g]) - mu) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            h = 0 if g == "Lbs-" else 1
            s += (nv - h) ** 2
        return math.sqrt(s / 3)

    tscore = [d2h({g: r[ti[g]] for g in GOALS}) for r in trows]
    target = sorted(tscore)[len(trows) // 4]
    xst = {c: msd([float(r[ti[c]]) for r in trows]) for c in NUMX}

    def feat(get):
        out = []
        for c in NUMX:
            v = fnum(get(c))
            if v is None:
                out.append(None)
            else:
                mu, sd = xst[c]
                z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
                out.append(1 / (1 + math.exp(-1.702 * z)))
        o = get("origin")
        out.append(None if o is None or str(o).strip() == "?" else str(o).strip())
        return out

    def dist(a, b):
        s = 0.0
        for i in range(4):
            x, y = a[i], b[i]
            if x is None or y is None:
                g = 1
            elif i < 3:
                g = x - y
            else:
                g = 0 if x == y else 1
            s += g * g
        return math.sqrt(s / 4)

    tf = [feat(lambda c, r=r: r[ti[c]]) for r in trows]

    with open(test_path) as f:
        data = json.load(f)
    hd = data["header"]
    hi = {h: i for i, h in enumerate(hd)}
    rows = data["rows"]
    cache = {}

    def F(i):
        if i not in cache:
            cache[i] = feat(lambda c: rows[i][hi[c]])
        return cache[i]

    prior = {}

    def P(i):
        if i not in prior:
            ds = sorted((dist(F(i), t), j) for j, t in enumerate(tf))[:5]
            prior[i] = mean([tscore[j] for _, j in ds])
        return prior[i]

    def ask(e, strat, i):
        print(json.dumps({"episode": e, "strategy": strat, "inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h(resp["goals"])

    def adaptive(e, pool):
        seen = []  # (idx, d2h)
        left = list(pool)
        while len(seen) < 10:
            def sc(i):
                p = P(i)
                if len(seen) < 3:
                    return p
                nb = sorted((dist(F(i), F(j)), y) for j, y in seen)[:2]
                return 0.5 * p + 0.5 * mean([y for _, y in nb])
            i = min(left, key=lambda i: (sc(i), i))
            left.remove(i)
            seen.append((i, ask(e, "adaptive", i)))
        return [y for _, y in seen]

    def summ(ys):
        lt = 11
        for k, y in enumerate(ys):
            if round(y, 12) <= round(target, 12):
                lt = k + 1
                break
        return {"best5": min(ys[:5]), "best10": min(ys), "labels_to_target": lt}

    results = []
    for e, ep in enumerate(data["episodes"]):
        a = summ(adaptive(e, ep["pool"]))
        r = summ([ask(e, "random", i) for i in ep["random_order"][:10]])
        results.append({"episode": e, "adaptive": a, "random": r})
    comps = {}
    for m in ["best5", "best10", "labels_to_target"]:
        comps[m] = compare([float(x["adaptive"][m]) for x in results],
                           [float(x["random"][m]) for x in results])
    print(json.dumps({"results": results, "comparisons": comps}), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    if a.cmd == "race":
        race(a.train, a.test)


if __name__ == "__main__":
    main()
