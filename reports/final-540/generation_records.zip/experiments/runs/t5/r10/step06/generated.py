import sys, json, csv, math

def load(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]

def num(v):
    return None if v == "?" or v == "" else float(v)

def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    mu = sum(vals) / n
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def norm(st, v):
    mu, sd = st
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    hd, train = load(tr)
    _, test = load(te)
    idx = {h: i for i, h in enumerate(hd)}
    goals = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    gnames = list(goals)
    feats = ["Clndrs", "Volume", "Model", "origin"]
    gst = {g: stats([num(r[idx[g]]) for r in train]) for g in goals}
    fst = {f: stats([num(r[idx[f]]) for r in train]) for f in feats[:3]}

    def gaps(r):
        return {g: norm(gst[g], num(r[idx[g]])) - goals[g] for g in goals}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    td = [d2h(r) for r in train]
    cutoff = sorted(td)[len(train) // 2]
    order = sorted(range(len(train)), key=lambda i: (round(td[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for f in feats[:3]:
        c = []
        for grp in (good, poor):
            vs = [num(r[idx[f]]) for r in grp]
            vs = [v for v in vs if v is not None]
            c.append(norm(fst[f], sum(vs) / len(vs)) if vs else None)
        centers[f] = c

    def freq(grp, v):
        k = [r[idx["origin"]] for r in grp if r[idx["origin"]] != "?"]
        return k.count(v) / len(k) if k else 0.0

    def evidence(r):
        ev = {}
        for f in feats[:3]:
            v = num(r[idx[f]])
            gc, pc = centers[f]
            if v is None or gc is None or pc is None:
                ev[f] = 0.0
            else:
                x = norm(fst[f], v)
                ev[f] = max(0.0, abs(x - gc) - abs(x - pc))
        v = r[idx["origin"]]
        ev["origin"] = 0.0 if v == "?" else max(0.0, freq(poor, v) - freq(good, v))
        return ev

    out = []
    n = len(test)
    for j in range(n):
        k = (j + 1) % n
        gj, gk = gaps(test[j]), gaps(test[k])
        s = math.sqrt(sum(x * x for x in gj.values()) / 3)
        o = math.sqrt(sum(x * x for x in gk.values()) / 3)
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
            lg, wg = (gk, gj) if win == j else (gj, gk)
            adv = {g: lg[g] ** 2 - wg[g] ** 2 for g in gnames}
            adv_goal = sorted(gnames, key=lambda g: (-round(adv[g], 10), g))[0]
        gorder = sorted(gnames, key=lambda g: (-round(abs(gj[g]), 10), g))
        ev = evidence(test[j])
        forder = sorted(feats, key=lambda f: (-round(ev[f], 10), f))
        weakest = gorder[0]
        top = forder[0] if ev[forder[0]] > 1e-10 else None
        text = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f} vs "
                f"cutoff {cutoff:.3f}; other car {k} score {o:.3f}; "
                f"weakest goal {weakest}. ")
        if win is not None:
            text += f"Recommend car {win} because of advantage in {adv_goal}. "
        else:
            text += "Scores tie. "
        if top is not None:
            text += f"Top feature {top} (retrospective, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv_goal, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "justify":
        main()
    else:
        print("usage: main.py justify --train TRAIN --test TEST", file=sys.stderr)
        sys.exit(1)
