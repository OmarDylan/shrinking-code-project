import sys, json, csv, math


def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]


def main():
    a = sys.argv[1:]
    if not a or a[0] != "remember":
        sys.exit("usage: main.py remember --train TRAIN --test TEST")
    train = test = None
    i = 1
    while i < len(a):
        if a[i] == "--train":
            train = a[i + 1]; i += 2
        elif a[i] == "--test":
            test = a[i + 1]; i += 2
        else:
            i += 1
    hn, tr = load(train)
    hn2, te = load(test)
    goals = [(n, 0.0 if n.endswith("-") else 1.0) for n in hn if n.endswith("-") or n.endswith("+")]
    stats = []
    for name, h in goals:
        at = hn.index(name)
        vals = [float(r[at]) for r in tr]
        n = len(vals)
        mu = sum(vals) / n
        sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats.append((hn2.index(name), mu, sd, h))

    def score(r):
        s = 0.0
        for at, mu, sd, h in stats:
            z = max(-3.0, min(3.0, (float(r[at]) - mu) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        return math.sqrt(s / len(stats))

    scores = [score(r) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    print(json.dumps({
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }))


main()
