import sys, json, csv, argparse
from math import sqrt

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"
K = 5

def load(path):
    with open(path, encoding="utf-8-sig") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    h = rows[0]
    ix = [h.index(n) for n in NUM] + [h.index(CAT)]
    out = []
    for r in rows[1:]:
        v = []
        for j, i in enumerate(ix):
            s = r[i] if i < len(r) else "?"
            if s == "?" or s == "":
                v.append(None)
            elif j < 3:
                try: v.append(float(s))
                except ValueError: v.append(None)
            else:
                v.append(s)
        out.append(v)
    return out

def quant(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    tr, te = load(a.train), load(a.test)

    med, sc = [], []
    for j in range(3):
        xs = [r[j] for r in tr if r[j] is not None] or [0.0]
        m = quant(xs, 0.5)
        s = (quant(xs, 0.75) - quant(xs, 0.25)) / 1.349
        if s < 1e-9:
            mu = sum(xs) / len(xs)
            s = sqrt(sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1))
        med.append(m); sc.append(s if s > 1e-9 else 1.0)

    def dist(p, q):
        t = n = 0
        for j in range(3):
            if p[j] is not None and q[j] is not None:
                t += ((p[j] - q[j]) / sc[j]) ** 2; n += 1
        if p[3] is not None and q[3] is not None:
            t += (p[3] != q[3]) * 1.0; n += 1
        return sqrt(t / n) if n else 0.0

    def raw(p, skip=None):
        ds = sorted(dist(p, q) for i, q in enumerate(tr) if i != skip)
        k = ds[:K]
        knn = sum(k) / len(k) if k else 0.0
        zs = [abs(p[j] - med[j]) / sc[j] for j in range(3) if p[j] is not None]
        return knn + 0.3 * (max(zs) if zs else 0.0)

    base = sorted(raw(p, i) for i, p in enumerate(tr))
    n = len(base)

    def cdf(x):
        lo, hi = 0, n
        while lo < hi:
            m = (lo + hi) // 2
            if base[m] <= x: lo = m + 1
            else: hi = m
        return lo / n if n else 0.0

    thr = 0.95
    scores = [min(1.0, max(0.0, cdf(raw(p)))) for p in te]
    print(json.dumps({"scores": scores,
                      "alerts": [s > thr for s in scores],
                      "threshold": thr}))

if __name__ == "__main__":
    main()
