import sys, csv, json, math

def load(p):
    with open(p, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r and any(c.strip() for c in r)]
    return rows[0], rows[1:]

def num(s):
    return None if s == "?" else float(s)

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, trr = load(tr)
    h2, ter = load(te)
    ix = {n: i for i, n in enumerate(h)}
    goals = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
    nums = ["Clndrs", "Volume", "Model"]
    cat = "origin"

    def stats(vals):
        n = len(vals)
        mu = sum(vals) / n if n else 0.0
        sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return mu, sd

    def nm(st, v):
        z = max(-3.0, min(3.0, (v - st[0]) / (st[1] + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    gst = {g: stats([float(r[ix[g]]) for r in trr]) for g in goals}
    nst = {}
    for f in nums:
        nst[f] = stats([float(r[ix[f]]) for r in trr if r[ix[f]] != "?"])

    def d2h(r, idx):
        return math.sqrt(sum((nm(gst[g], float(r[idx[g]])) - goals[g]) ** 2 for g in goals) / 3)

    ds = [(round(d2h(r, ix), 12), i) for i, r in enumerate(trr)]
    ds.sort()
    q = max(1, len(trr) // 4)
    good = [trr[i] for _, i in ds[:q]]
    poor = [trr[i] for _, i in ds[-q:]]

    centers = {}
    for f in nums:
        c = []
        for grp in (good, poor):
            v = [float(r[ix[f]]) for r in grp if r[ix[f]] != "?"]
            c.append(nm(nst[f], sum(v) / len(v)) if v else None)
        centers[f] = c

    def freq(grp):
        v = [r[ix[cat]] for r in grp if r[ix[cat]] != "?"]
        d = {}
        for x in v:
            d[x] = d.get(x, 0) + 1
        return d, len(v)

    gf, gn = freq(good)
    pf, pn = freq(poor)

    out = []
    for r in ter:
        feats = {}
        for f in nums:
            s = r[ix[f]]
            gc, pc = centers[f]
            if s == "?" or gc is None or pc is None:
                feats[f] = 0.0
            else:
                x = nm(nst[f], float(s))
                feats[f] = max(0.0, abs(x - gc) - abs(x - pc))
        s = r[ix[cat]]
        if s == "?":
            feats[cat] = 0.0
        else:
            pv = pf.get(s, 0) / pn if pn else 0.0
            gv = gf.get(s, 0) / gn if gn else 0.0
            feats[cat] = max(0.0, pv - gv)
        gl = {g: abs(nm(gst[g], float(r[ix[g]])) - goals[g]) for g in goals}
        order = lambda d: [k for k, _ in sorted(d.items(), key=lambda kv: (-round(kv[1], 10), kv[0]))]
        out.append({"goals": gl, "features": feats,
                    "goal_order": order(gl), "feature_order": order(feats)})
    print(json.dumps({"diagnoses": out}))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "blame":
        main()
