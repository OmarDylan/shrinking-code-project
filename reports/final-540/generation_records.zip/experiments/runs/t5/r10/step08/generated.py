import sys, csv, json, math

def load(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        rows = [[c.strip() for c in r] for r in csv.reader(f) if r]
    return rows[0], rows[1:]

def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    mu = sum(vals) / n if n else 0.0
    sd = math.sqrt(sum((v - mu) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return mu, sd

def nrm(v, st):
    mu, sd = st
    z = max(-3.0, min(3.0, (v - mu) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def main():
    a = sys.argv[1:]
    if not a or a[0] != "fix":
        sys.exit(1)
    tr_p = a[a.index("--train") + 1]
    te_p = a[a.index("--test") + 1]
    th, tr = load(tr_p)
    eh, te = load(te_p)
    ti = {h: i for i, h in enumerate(th)}
    ei = {h: i for i, h in enumerate(eh)}
    goals = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
    gst = {g: stats([num(r[ti[g]]) for r in tr]) for g, _ in goals}
    d2h = []
    for r in tr:
        s = 0.0
        for g, h in goals:
            s += (nrm(num(r[ti[g]]), gst[g]) - h) ** 2
        d2h.append(math.sqrt(s / 3))
    nums = ["Clndrs", "Volume", "Model"]
    ist = {c: stats([num(r[ti[c]]) for r in tr]) for c in nums}

    def feat(h, r):
        f = {}
        for c in nums:
            v = num(r[h[c]])
            f[c] = None if v is None else v
        f["origin"] = r[h["origin"]]
        return f

    trf = [feat(ti, r) for r in tr]
    tn = [{c: (None if f[c] is None else nrm(f[c], ist[c])) for c in nums} | {"origin": f["origin"]}
          for f in trf]

    def tonorm(f):
        return {c: (None if f[c] is None else nrm(f[c], ist[c])) for c in nums} | {"origin": f["origin"]}

    def dist(x, y):
        s = 0.0
        for c in nums:
            if x[c] is None or y[c] is None:
                g = 1.0
            else:
                g = x[c] - y[c]
            s += g * g
        s += 0.0 if x["origin"] == y["origin"] else 1.0
        return math.sqrt(s / 4)

    def predict(xn):
        ds = sorted((round(dist(xn, t), 12), i) for i, t in enumerate(tn))
        k = ds[:5]
        return sum(d2h[i] for _, i in k) / len(k)

    n = len(tr)
    cutoff = sorted(d2h)[n // 2]
    rk = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = rk[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (trf[i]["Clndrs"], trf[i]["Volume"])
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for idx, r in enumerate(te):
        f = feat(ei, r)
        xn = tonorm(f)
        before = predict(xn)
        res = {"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"}
        if round(before, 10) <= round(cutoff, 10):
            out.append(res)
            continue
        best = None
        for (c, v) in menu:
            ch = {}
            if f["Clndrs"] != c:
                ch["Clndrs"] = c
            if f["Volume"] != v:
                ch["Volume"] = v
            if not ch:
                continue
            g = dict(f)
            g["Clndrs"], g["Volume"] = c, v
            gn = tonorm(g)
            after = predict(gn)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(xn, gn), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best is None:
            res["status"] = "no_candidate"
        else:
            res["status"] = "improved"
            res["after"] = best[1]
            res["changes"] = best[2]
        out.append(res)
    sys.stdout.write(json.dumps({"repairs": out}))

main()
