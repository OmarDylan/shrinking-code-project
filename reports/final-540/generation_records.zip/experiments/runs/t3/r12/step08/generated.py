import csv, sys, json, math

def read(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def fnum(s):
    try:
        if s is None or s.strip() == '?':
            return None
        return float(s)
    except ValueError:
        return None

def norm_fn(vals):
    n = len(vals)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    a = sys.argv
    train = a[a.index('--train') + 1]
    test = a[a.index('--test') + 1]
    tr = read(train)
    te = read(test)
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    heaven = {'Lbs-': 0, 'Acc+': 1, 'Mpg+': 1}
    gn = {g: norm_fn([float(r[g]) for r in tr]) for g in goals}
    d2h = []
    for r in tr:
        s = sum((gn[g](float(r[g])) - heaven[g]) ** 2 for g in goals)
        d2h.append(math.sqrt(s / 3))
    nums = ['Clndrs', 'Volume', 'Model']
    nn = {c: norm_fn([float(r[c]) for r in tr]) for c in nums}

    def prep(r, c=None, v=None):
        x = {}
        for k in nums:
            x[k] = fnum(r.get(k))
        x['origin'] = r.get('origin')
        return x

    trx = [prep(r) for r in tr]
    trn = [{**{k: nn[k](x[k]) for k in nums}, 'origin': x['origin']} for x in trx]

    def normrow(x):
        return {**{k: (nn[k](x[k]) if x[k] is not None else None) for k in nums}, 'origin': x['origin']}

    def dist(p, q):
        s = 0.0
        for k in nums:
            if p[k] is None or q[k] is None:
                s += 1.0
            else:
                s += (p[k] - q[k]) ** 2
        s += 0.0 if p['origin'] == q['origin'] else 1.0
        return math.sqrt(s / 4)

    def predict(nx):
        ds = sorted(range(len(trn)), key=lambda i: (round(dist(nx, trn[i]), 12), i))
        top = ds[:5]
        return sum(d2h[i] for i in top) / len(top)

    cutoff = sorted(d2h)[len(tr) // 2]
    rank = sorted(range(len(tr)), key=lambda i: (round(d2h[i], 12), i))
    good = rank[:max(1, len(tr) // 4)]
    menu = []
    seen = set()
    for i in good:
        pr = (trx[i]['Clndrs'], trx[i]['Volume'])
        if pr not in seen:
            seen.add(pr)
            menu.append(pr)
            if len(menu) == 12:
                break

    out = []
    for idx, r in enumerate(te):
        x = prep(r)
        nx = normrow(x)
        before = predict(nx)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for (c, v) in menu:
            ch = {}
            if x['Clndrs'] != c:
                ch['Clndrs'] = c
            if x['Volume'] != v:
                ch['Volume'] = v
            if not ch:
                continue
            ex = dict(x)
            ex['Clndrs'] = c
            ex['Volume'] = v
            ne = normrow(ex)
            after = predict(ne)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(nx, ne), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, ch, after)
        if best is None:
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            out.append({"row": idx, "before": before, "after": best[2], "changes": best[1], "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'fix':
        main()
