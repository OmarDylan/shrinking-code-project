import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor

G = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}


def num(v):
    try:
        return float(v)
    except Exception:
        return float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    with open(a.train, newline="") as f:
        rd = list(csv.reader(f))
    th, trows = rd[0], rd[1:]
    ti = {c: i for i, c in enumerate(th)}
    st = {}
    for g in G:
        v = np.array([num(r[ti[g]]) for r in trows])
        st[g] = (v.mean(), v.std(ddof=1))

    def d2h(goals):
        s = 0.0
        for g, h in G.items():
            m, sd = st[g]
            z = max(-3, min(3, (goals[g] - m) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - h) ** 2
        return math.sqrt(s / 3)

    tr_d = [d2h({g: num(r[ti[g]]) for g in G}) for r in trows]
    target = sorted(tr_d)[len(trows) // 4]

    with open(a.test) as f:
        data = json.load(f)
    hd = data["header"]
    hi = {c: i for i, c in enumerate(hd)}
    rows = data["rows"]
    numc = ["Clndrs", "Volume", "Model"]
    cats = sorted({r[ti["origin"]] for r in trows} | {str(r[hi["origin"]]) for r in rows})
    trn = np.array([[num(r[ti[c]]) for c in numc] for r in trows])
    med = np.nanmedian(trn, axis=0)

    def feat(nums, o):
        x = [med[i] if math.isnan(v) else v for i, v in enumerate(nums)]
        return x + [1.0 if o == c else 0.0 for c in cats]

    Xtr = np.array([feat(trn[i], trows[i][ti["origin"]]) for i in range(len(trows))])
    ytr = np.array(tr_d)
    Xall = np.array([feat([num(r[hi[c]]) for c in numc], str(r[hi["origin"]])) for r in rows])

    def fit(X, y, w=None):
        m = RandomForestRegressor(n_estimators=60, min_samples_leaf=2, random_state=0, n_jobs=1)
        m.fit(X, y, sample_weight=w)
        return m

    base = fit(Xtr, ytr)

    def inspect(ep, strat, idx):
        sys.stdout.write(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}) + "\n")
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        return d2h(resp["goals"])

    def labels(ds):
        for i, d in enumerate(ds):
            if round(d, 12) <= round(target, 12):
                return i + 1
        return 11

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        obs = {}
        order = []
        for step in range(10):
            rem = [p for p in pool if p not in obs]
            if step < 3:
                m = base
            else:
                ks = list(obs)
                X = np.vstack([Xtr, Xall[ks]])
                y = np.concatenate([ytr, [obs[k] for k in ks]])
                w = np.concatenate([np.ones(len(ytr)), np.full(len(ks), 5.0)])
                m = fit(X, y, w)
            p = m.predict(Xall[rem])
            j = min(range(len(rem)), key=lambda i: (p[i], rem[i]))
            c = rem[j]
            obs[c] = inspect(e, "adaptive", c)
            order.append(obs[c])
        ad = order
        rd_ = [inspect(e, "random", i) for i in ep["random_order"][:10]]
        results.append({
            "episode": e,
            "adaptive": {"best5": min(ad[:5]), "best10": min(ad), "labels_to_target": labels(ad)},
            "random": {"best5": min(rd_[:5]), "best10": min(rd_), "labels_to_target": labels(rd_)},
        })

    def cert(xs, ys):
        n, m = len(xs), len(ys)
        mx, my = sum(xs) / n, sum(ys) / m
        vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
        vy = sum((y - my) ** 2 for y in ys) / (m - 1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
        cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
        ks = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
                 for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
        return {"cohen": co, "cliffs": cl, "ks": ks,
                "same": bool(co <= 0.35 and cl <= 0.197 and ks <= 1.36)}

    comps = {k: cert([float(r["adaptive"][k]) for r in results],
                     [float(r["random"][k]) for r in results])
             for k in ("best5", "best10", "labels_to_target")}
    print(json.dumps({"results": results, "comparisons": comps}))
    sys.stdout.flush()


main()
