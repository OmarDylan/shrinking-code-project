import sys, csv, json, argparse
import numpy as np

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    X = np.array([[float(r[c]) if r.get(c, "?").strip() not in ("?", "") else np.nan
                   for c in NUM] for r in rows], dtype=float).reshape(len(rows), len(NUM))
    O = [(r.get(CAT) or "?").strip() for r in rows]
    return X, O


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    Xtr, Otr = load(a.train)
    Xte, Ote = load(a.test)

    med = np.nanmedian(Xtr, axis=0)
    med = np.where(np.isnan(med), 0.0, med)
    mad = np.nanmedian(np.abs(Xtr - med), axis=0) * 1.4826
    sd = np.nanstd(Xtr, axis=0)
    scale = np.where(mad > 1e-9, mad, np.where(sd > 1e-9, sd, 1.0))
    # blend with sd so heavily discrete columns don't over-flag
    scale = np.maximum(scale, 0.3 * np.where(sd > 1e-9, sd, 1.0))

    def fill(X):
        X = X.copy()
        idx = np.where(np.isnan(X))
        X[idx] = med[idx[1]]
        return X

    Ztr = fill(Xtr)
    mu = Ztr.mean(0)
    cov = np.cov(Ztr, rowvar=False) + 1e-6 * np.eye(len(NUM))
    ic = np.linalg.pinv(cov)

    known = [o for o in Otr if o != "?"]
    n = max(len(known), 1)
    freq = {}
    for o in known:
        freq[o] = freq.get(o, 0) + 1

    def raw(X, O):
        miss = np.isnan(X)
        Z = fill(X)
        rz = np.abs((Z - med) / scale)
        rz[miss] = 0
        d = Z - mu
        m = np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", d, ic, d), 0))
        s = np.maximum(rz.max(1), m * 0.8)
        for i, o in enumerate(O):
            if o != "?":
                f = freq.get(o, 0) / n
                if f < 0.03:
                    s[i] += 2.0
        return s

    def sq(r):
        return 1 - np.exp(-r / 4.0)

    rtr = raw(Xtr, Otr)
    thr = float(np.quantile(sq(rtr), 0.98)) if len(rtr) else 0.5
    thr = min(max(thr, 0.0), 1.0)
    sc = np.clip(sq(raw(Xte, Ote)), 0, 1)
    out = {"scores": [float(x) for x in sc],
           "alerts": [bool(x > thr) for x in sc],
           "threshold": thr}
    sys.stdout.write(json.dumps(out))


main()
