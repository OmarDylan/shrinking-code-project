import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor


def read(p):
    with open(p, newline="") as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [[c.strip() for c in row] for row in r[1:] if row]


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def col(h, rows, name):
    if name not in h:
        return [None] * len(rows)
    i = h.index(name)
    return [row[i] if i < len(row) else "?" for row in rows]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    th, tr = read(a.train)
    eh, te = read(a.test)

    def raw(h, rows):
        return {n: col(h, rows, n) for n in ["Clndrs", "Volume", "Model", "origin"]}

    R, E = raw(th, tr), raw(eh, te)
    cats = sorted({v for v in R["origin"] if v and v != "?"})
    nums = ["Clndrs", "Volume", "Model"]
    med = {}
    for n in nums:
        vals = [num(v) for v in R[n] if v is not None and num(v) is not None]
        med[n] = float(np.median(vals)) if vals else 0.0

    def feats(D, n):
        X = []
        miss = []
        for i in range(n):
            f = []
            for k in nums:
                v = num(D[k][i]) if D[k][i] is not None else None
                if k == "Volume":
                    miss.append(v is None)
                f.append(med[k] if v is None else v)
            o = D["origin"][i]
            f += [1.0 if o == c else 0.0 for c in cats]
            X.append(f)
        return np.array(X), np.array(miss)

    Xtr, _ = feats(R, len(tr))
    Xte, vmiss = feats(E, len(te))

    G = {g: [num(v) if v is not None else None for v in col(th, tr, g)] for g in ["Lbs-", "Acc+", "Mpg+"]}
    heaven = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
    stats = {}
    for g, v in G.items():
        vv = np.array([x for x in v if x is not None])
        stats[g] = (vv.mean(), vv.std(ddof=1) if len(vv) > 1 else 0.0)
    d2h = []
    for i in range(len(tr)):
        s = 0.0
        ok = True
        for g in G:
            v = G[g][i]
            if v is None:
                ok = False
                break
            m, sd = stats[g]
            z = max(-3, min(3, (v - m) / (sd + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - heaven[g]) ** 2
        d2h.append(math.sqrt(s / 3) if ok else None)

    mpg = G["Mpg+"]
    vol_idx = nums.index("Volume")
    keep_nov = [j for j in range(Xtr.shape[1]) if j != vol_idx]

    def fit_pred(y, lo, hi, positive=False):
        idx = [i for i, v in enumerate(y) if v is not None]
        yy = np.array([y[i] for i in idx])
        out = np.zeros(len(te))
        for use_vol in (True, False):
            cols = list(range(Xtr.shape[1])) if use_vol else keep_nov
            sel = np.where(~vmiss)[0] if use_vol else np.where(vmiss)[0]
            if len(sel) == 0:
                continue
            Xa = Xtr[np.ix_(idx, cols)]
            ps = []
            for m in (RandomForestRegressor(300, min_samples_leaf=2, random_state=0),
                      GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05,
                                                subsample=0.8, random_state=0)):
                m.fit(Xa, yy)
                ps.append(m.predict(Xte[np.ix_(sel, cols)]))
            out[sel] = np.mean(ps, axis=0)
        return np.clip(out, lo, hi)

    pm = fit_pred(mpg, 1.0, 1e3)
    ps = fit_pred(d2h, 0.0, 1.0)
    print(json.dumps({"mpg": [float(x) for x in pm], "scores": [float(x) for x in ps]}))


main()
