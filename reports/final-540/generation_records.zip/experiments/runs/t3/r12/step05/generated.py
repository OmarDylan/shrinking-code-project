import csv, sys, math, json

FEATS = ["Clndrs", "Volume", "Model", "origin"]
GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    v = (v or "").strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def mknorm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f


def main():
    a = sys.argv
    train = read(a[a.index("--train") + 1])
    test = read(a[a.index("--test") + 1])

    gn = {}
    for g in GOALS:
        gn[g] = mknorm(*stats([float(r[g]) for r in train]))

    def d2h(r):
        return math.sqrt(sum((gn[g](float(r[g])) - h) ** 2 for g, h in GOALS.items()) / 3)

    order = sorted(range(len(train)), key=lambda i: (round(d2h(train[i]), 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    fn = {}
    centers = {}
    freqs = {}
    for f in FEATS:
        if f == "origin":
            def fr(rows):
                vals = [r[f].strip() for r in rows if r[f].strip() not in ("?", "")]
                d = {}
                for v in vals:
                    d[v] = d.get(v, 0) + 1
                n = len(vals)
                return {k: c / n for k, c in d.items()} if n else {}
            freqs[f] = (fr(good), fr(poor))
        else:
            col = [x for x in (num(r[f]) for r in train) if x is not None]
            fn[f] = mknorm(*stats(col))

            def cen(rows):
                v = [x for x in (num(r[f]) for r in rows) if x is not None]
                return fn[f](sum(v) / len(v)) if v else None
            centers[f] = (cen(good), cen(poor))

    out = []
    for r in test:
        goals = {g: abs(gn[g](float(r[g])) - h) for g, h in GOALS.items()}
        feats = {}
        for f in FEATS:
            if f == "origin":
                c = r[f].strip()
                if c in ("?", ""):
                    e = 0.0
                else:
                    gf, pf = freqs[f]
                    e = max(0.0, pf.get(c, 0.0) - gf.get(c, 0.0))
            else:
                x = num(r[f])
                gc, pc = centers[f]
                if x is None or gc is None or pc is None:
                    e = 0.0
                else:
                    nx = fn[f](x)
                    e = max(0.0, abs(nx - gc) - abs(nx - pc))
            feats[f] = e
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": goals, "features": feats,
                    "goal_order": key(goals), "feature_order": key(feats)})
    sys.stdout.write(json.dumps({"diagnoses": out}))


main()
