import sys, json, csv, math, bisect
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

GOALS = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]


def read(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    h = [c.strip() for c in rows[0]]
    return h, [r for r in rows[1:] if r]


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None


def d2h_from(vals, stats):
    t = 0.0
    for (m, sd), (v, (_, h)) in zip(stats, zip(vals, GOALS)):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        n = 1 / (1 + math.exp(-1.702 * z))
        t += (n - h) ** 2
    return math.sqrt(t / 3)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pv) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    return cohen, cliffs, ks, (cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    th, trows = read(tr)
    eh, erows = read(te)
    ti = {c: i for i, c in enumerate(th)}
    ei = {c: i for i, c in enumerate(eh)}

    def col(rows, idx, name):
        return [num(r[idx[name]]) if name in idx and idx[name] < len(r) else None for r in rows]

    def cat(rows, idx):
        return [r[idx["origin"]].strip() if "origin" in idx and idx["origin"] < len(r) else "?" for r in rows]

    cyl_t, vol_t, mod_t = (col(trows, ti, c) for c in ("Clndrs", "Volume", "Model"))
    cyl_e, vol_e, mod_e = (col(erows, ei, c) for c in ("Clndrs", "Volume", "Model"))
    ori_t, ori_e = cat(trows, ti), cat(erows, ei)
    cats = sorted(set(ori_t))

    def med(v):
        v = [x for x in v if x is not None]
        return float(np.median(v)) if v else 0.0

    mc, mv, mm = med(cyl_t), med(vol_t), med(mod_t)

    def feats(cy, vo, mo, orr, use_vol):
        X = []
        for i in range(len(cy)):
            f = [cy[i] if cy[i] is not None else mc]
            if use_vol:
                f.append(vo[i] if vo[i] is not None else mv)
            f.append(mo[i] if mo[i] is not None else mm)
            f += [1.0 if orr[i] == c else 0.0 for c in cats]
            X.append(f)
        return np.array(X, float)

    Y = [col(trows, ti, g) for g, _ in GOALS]
    Y = np.array(Y, float).T
    stats = []
    for j in range(3):
        c = Y[:, j]
        m = c.mean()
        sd = c.std(ddof=1) if len(c) > 1 else 0.0
        stats.append((m, sd))

    hist = [d2h_from(Y[i], stats) for i in range(len(Y))]

    preds = {}
    for uv in (True, False):
        Xt = feats(cyl_t, vol_t, mod_t, ori_t, uv)
        Xe = feats(cyl_e, vol_e, mod_e, ori_e, uv)
        P = []
        for j in range(3):
            mdl = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05,
                                            subsample=0.8, random_state=0)
            mdl.fit(Xt, Y[:, j])
            P.append(mdl.predict(Xe))
        preds[uv] = np.array(P).T

    mpg, scores = [], []
    for i in range(len(erows)):
        p = preds[vol_e[i] is not None][i]
        mp = max(float(p[2]), 1e-3)
        mpg.append(mp)
        s = d2h_from([p[0], p[1], mp], stats)
        scores.append(min(1.0, max(0.0, s)))

    alerts = []
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, scores[i - 19:i + 1])[3])

    sys.stdout.write(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))


if __name__ == "__main__":
    main()
