import csv, sys, json, math, argparse
import numpy as np

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def fnum(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    train, test = read(a.train), read(a.test)

    stats = {}
    for g in GOALS:
        v = np.array([x for x in (fnum(r.get(g)) for r in train) if x is not None])
        sd = v.std(ddof=1) if len(v) > 1 else 0.0
        stats[g] = (v.mean(), sd)

    def norm(g, v):
        m, sd = stats[g]
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(d):
        return math.sqrt(sum((norm(g, d[g]) - HEAVEN[g]) ** 2 for g in GOALS) / 3)

    # features
    cats = sorted({r.get("origin", "?") for r in train + test if r.get("origin", "?") != "?"})
    med = {}
    for c in NUM:
        v = [x for x in (fnum(r.get(c)) for r in train) if x is not None]
        med[c] = float(np.median(v)) if v else 0.0

    def feat(r):
        f = []
        for c in NUM:
            x = fnum(r.get(c))
            f.append(med[c] if x is None else x)
        o = r.get("origin", "?")
        f += [1.0 if o == c else 0.0 for c in cats]
        return f

    Xtr, ytr = [], []
    for r in train:
        vals = [fnum(r.get(g)) for g in GOALS]
        if any(v is None for v in vals):
            continue
        Xtr.append(feat(r))
        ytr.append(d2h(dict(zip(GOALS, vals))))
    Xte = np.array([feat(r) for r in test])
    n = len(test)
    try:
        from sklearn.ensemble import RandomForestRegressor
        m = RandomForestRegressor(n_estimators=200, random_state=0, min_samples_leaf=2)
        m.fit(np.array(Xtr), np.array(ytr))
        pred = m.predict(Xte)
    except Exception as e:
        print(e, file=sys.stderr)
        pred = np.full(n, float(np.mean(ytr)) if ytr else 0.5)

    order = sorted(range(n), key=lambda i: (round(float(pred[i]), 12), i))
    picks = order[:min(10, n)]

    obs = {}
    for i in picks:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        obs[i] = d2h(resp["goals"])

    ranked = sorted(obs, key=lambda i: (round(obs[i], 12), i))
    print(json.dumps({"selected": ranked[:3]}), flush=True)


main()
