import csv, sys, json, math, argparse

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMS = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def read(path):
    with open(path, newline="") as f:
        return [{k.strip(): (v.strip() if v is not None else "?") for k, v in r.items()}
                for r in csv.DictReader(f)]


def num(v):
    if v is None or v == "?" or v == "":
        return None
    try:
        x = float(v)
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1))


def make_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    train, test = read(a.train), read(a.test)

    norms = {}
    for c in list(GOALS) + NUMS:
        norms[c] = make_norm(*stats([x for x in (num(r.get(c)) for r in train) if x is not None]))

    def gaps(r):
        return {g: abs(norms[g](num(r[g])) - h) for g, h in GOALS.items()}

    def d2h(r):
        return math.sqrt(sum(v * v for v in gaps(r).values()) / 3)

    tr_scores = [d2h(r) for r in train]
    cutoff = sorted(tr_scores)[len(train) // 2]
    order = sorted(range(len(train)), key=lambda i: (round(tr_scores[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            vals = [x for x in (num(r.get(c)) for r in grp) if x is not None]
            if vals:
                cs.append(norms[c](sum(vals) / len(vals)))
            else:
                cs.append(None)
        centers[c] = cs

    def freq(grp, cat):
        known = [r.get(CAT) for r in grp if r.get(CAT, "?") not in ("?", "")]
        return known.count(cat) / len(known) if known else 0.0

    def features(r):
        ev = {}
        for c in NUMS:
            x = num(r.get(c))
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                ev[c] = 0.0
            else:
                nx = norms[c](x)
                ev[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cat = r.get(CAT, "?")
        if cat in ("?", ""):
            ev[CAT] = 0.0
        else:
            ev[CAT] = max(0.0, freq(poor, cat) - freq(good, cat))
        return ev

    def rank(d):
        return [k for k, _ in sorted(d.items(), key=lambda kv: (-round(kv[1], 10), kv[0]))]

    n = len(test)
    scores = [d2h(r) for r in test]
    allgaps = [gaps(r) for r in test]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        acc = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: allgaps[loser][g] ** 2 - allgaps[winner][g] ** 2 for g in GOALS}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        go = rank(allgaps[j])
        weakest = go[0]
        fe = features(test[j])
        fo = rank(fe)
        top = fo[0] if fe[fo[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other car %d score %.3f, cutoff %.3f. Weakest goal: %s." % (
            j, "accepted" if acc else "rejected", s, k, o, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d, mainly for %s advantage." % (winner, adv_goal)
        else:
            text += " The comparison is a tie."
        if top is not None:
            text += " Top feature: %s (retrospective association, not causal)." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o, "cutoff": cutoff,
                    "accepted": acc, "winner": winner, "advantage_goal": adv_goal,
                    "weakest_goal": weakest, "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


main()
