import csv, sys, json, math, argparse
import numpy as np

def norm(v, m, s):
    z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
    return 1.0 / (1.0 + math.exp(-1.702 * z))

def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else "?") for k, v in row.items()} for row in r]

def num(x):
    try:
        return float(x)
    except Exception:
        return None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr = read(a.train)
    te = read(a.test)
    n = len(tr)
    goals = ["Lbs-", "Acc+", "Mpg+"]
    heaven = [0, 1, 1]
    gst = {}
    for g in goals:
        v = np.array([float(r[g]) for r in tr])
        gst[g] = (v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0)
    d2h = np.zeros(n)
    for i, r in enumerate(tr):
        s = 0.0
        for g, h in zip(goals, heaven):
            s += (norm(float(r[g]), *gst[g]) - h) ** 2
        d2h[i] = math.sqrt(s / 3)
    feats = ["Clndrs", "Volume", "Model"]
    fst = {}
    for c in feats:
        v = np.array([float(r[c]) for r in tr])
        fst[c] = (v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0)
    X = np.array([[norm(float(r[c]), *fst[c]) for c in feats] for r in tr])
    O = [r["origin"] for r in tr]
    Oa = np.array(O)
    idx = np.arange(n)

    def pred(x, o):
        d = ((X - x) ** 2).sum(axis=1) + (Oa != o).astype(float)
        d = np.sqrt(d / 4)
        order = np.lexsort((idx, np.round(d, 12)))[:5]
        return float(d2h[order].mean())

    def dist(x, y, o1, o2):
        return math.sqrt((sum((p - q) ** 2 for p, q in zip(x, y)) + (0 if o1 == o2 else 1)) / 4)

    cutoff = float(np.sort(d2h)[n // 2])
    rk = np.lexsort((idx, np.round(d2h, 12)))
    q = max(1, n // 4)
    menu = []
    seen = set()
    for i in rk[:q]:
        p = (float(tr[i]["Clndrs"]), float(tr[i]["Volume"]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for ri, r in enumerate(te):
        raw = []
        nx = []
        for c in feats:
            v = num(r.get(c, "?"))
            raw.append(v)
            nx.append(norm(v, *fst[c]) if v is not None else 0.5)
        o = r.get("origin", "?")
        before = pred(np.array(nx), o)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": ri, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for (cl, vo) in menu:
            ch = 0
            if raw[0] is None or cl != raw[0]:
                ch += 1
            if raw[1] is None or vo != raw[1]:
                ch += 1
            if ch == 0:
                continue
            ex = list(nx)
            ex[0] = norm(cl, *fst["Clndrs"])
            ex[1] = norm(vo, *fst["Volume"])
            after = pred(np.array(ex), o)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(nx, ex, o, o), 10), round(after, 10), (cl, vo))
                if best is None or key < best[0]:
                    best = (key, after, cl, vo)
        if best is None:
            out.append({"row": ri, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            _, after, cl, vo = best
            changes = {}
            if raw[0] is None or cl != raw[0]:
                changes["Clndrs"] = cl
            if raw[1] is None or vo != raw[1]:
                changes["Volume"] = vo
            out.append({"row": ri, "before": before, "after": after, "changes": changes, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == "__main__":
    main()
