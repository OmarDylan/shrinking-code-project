import csv, sys, json, math

def read(p):
    with open(p, newline='') as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return h, rows

def stats(v):
    n = len(v)
    m = sum(v) / n if n else 0.0
    sd = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
    return m, sd

def mk(m, sd):
    def norm(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return norm

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, R = read(tr)
    _, T = read(te)
    goals = [(i, n) for i, n in enumerate(h) if n[-1] in '+-']
    feats = [(i, n) for i, n in enumerate(h) if n[-1] not in '+-X']
    gn = {}
    heaven = {}
    for i, n in goals:
        gn[n] = mk(*stats([float(r[i]) for r in R]))
        heaven[n] = 1.0 if n.endswith('+') else 0.0

    def d2h(r):
        return math.sqrt(sum((gn[n](float(r[i])) - heaven[n]) ** 2 for i, n in goals) / len(goals))

    order = sorted(range(len(R)), key=lambda k: (round(d2h(R[k]), 12), k))
    q = max(1, len(R) // 4)
    good = [R[k] for k in order[:q]]
    poor = [R[k] for k in order[-q:]]

    info = {}
    for i, n in feats:
        if n[0].isupper():
            vals = [float(r[i]) for r in R if r[i] != '?']
            norm = mk(*stats(vals))
            c = []
            for g in (good, poor):
                gv = [float(r[i]) for r in g if r[i] != '?']
                c.append(norm(sum(gv) / len(gv)) if gv else None)
            info[n] = ('num', i, norm, c[0], c[1])
        else:
            fr = []
            for g in (good, poor):
                kn = [r[i] for r in g if r[i] != '?']
                d = {}
                for x in kn:
                    d[x] = d.get(x, 0) + 1
                fr.append((d, len(kn)))
            info[n] = ('cat', i, fr)

    out = []
    for r in T:
        gs = {n: abs(gn[n](float(r[i])) - heaven[n]) for i, n in goals}
        fs = {}
        for i, n in feats:
            t = info[n]
            if r[i] == '?':
                fs[n] = 0.0
            elif t[0] == 'num':
                _, _, norm, gc, pc = t
                if gc is None or pc is None:
                    fs[n] = 0.0
                else:
                    x = norm(float(r[i]))
                    fs[n] = max(0.0, abs(x - gc) - abs(x - pc))
            else:
                (gd, gk), (pd, pk) = t[2]
                gf = gd.get(r[i], 0) / gk if gk else 0.0
                pf = pd.get(r[i], 0) / pk if pk else 0.0
                fs[n] = max(0.0, pf - gf)
        key = lambda d: sorted(d, key=lambda n: (-round(d[n], 10), n))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    print(json.dumps({"diagnoses": out}))

main()
