import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor


def read(p):
    with open(p, newline="") as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [[c.strip() for c in row] for row in r[1:] if row]


def num(v):
    try:
        return float(v) if v != "?" else float("nan")
    except ValueError:
        return float("nan")


def certify(xs, ys):
    xs = np.asarray(xs, float); ys = np.asarray(ys, float)
    n, m = len(xs), len(ys)
    vx, vy = xs.var(ddof=1), ys.var(ddof=1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(xs.mean() - ys.mean()) / (math.sqrt(pv) + 1e-32)
    cliffs = abs(np.sign(xs[:, None] - ys[None, :]).sum()) / (n * m)
    sx, sy = np.sort(xs), np.sort(ys)
    vals = np.union1d(xs, ys)
    cx = np.searchsorted(sx, vals, side="right") / n
    cy = np.searchsorted(sy, vals, side="right") / m
    ks = np.max(np.abs(cx - cy)) / math.sqrt(1 / n + 1 / m)
    return bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, R = read(tr)
    th, T = read(te)
    ix = {k: i for i, k in enumerate(h)}
    tx = {k: i for i, k in enumerate(th)}
    cats = sorted({r[ix["origin"]] for r in R})

    def feats(row, idx, vol):
        f = [num(row[idx["Clndrs"]]), num(row[idx["Model"]])]
        if vol:
            f.append(num(row[idx["Volume"]]))
        o = row[idx["origin"]]
        f += [1.0 if o == c else 0.0 for c in cats]
        return f

    G = np.array([[num(r[ix["Lbs-"]]), num(r[ix["Acc+"]]), num(r[ix["Mpg+"]])] for r in R])
    mu = G.mean(0)
    sd = G.std(0, ddof=1)

    def d2h(g):
        g = np.atleast_2d(g)
        z = np.clip((g - mu) / (sd + 1e-32), -3, 3)
        nv = 1 / (1 + np.exp(-1.702 * z))
        hv = np.array([0, 1, 1])
        return np.sqrt(((nv - hv) ** 2).sum(1) / 3)

    hist = d2h(G)
    y_mpg = G[:, 2]
    models = {}
    for vol in (True, False):
        X = np.array([feats(r, ix, vol) for r in R], float)
        X = np.nan_to_num(X)
        m1 = RandomForestRegressor(200, random_state=0, min_samples_leaf=2).fit(X, y_mpg)
        m2 = RandomForestRegressor(200, random_state=0, min_samples_leaf=2).fit(X, hist)
        models[vol] = (m1, m2)

    mpg, sc = [], []
    for row in T:
        v = num(row[tx["Volume"]]) if "Volume" in tx else float("nan")
        vol = not math.isnan(v)
        x = np.nan_to_num(np.array([feats(row, tx, vol)], float))
        m1, m2 = models[vol]
        mpg.append(float(max(m1.predict(x)[0], 1e-3)))
        sc.append(float(min(1.0, max(0.0, m2.predict(x)[0]))))

    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, sc[i - 19:i + 1]))
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": alerts}))


if __name__ == "__main__":
    main()
