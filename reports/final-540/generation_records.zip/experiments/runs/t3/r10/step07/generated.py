import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor

G = ["Lbs-", "Acc+", "Mpg+"]
H = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def main():
    a = sys.argv
    tr = read(a[a.index("--train") + 1])
    te = read(a[a.index("--test") + 1])

    st = {}
    for g in G:
        v = [num(r.get(g)) for r in tr]
        v = np.array([x for x in v if x is not None])
        sd = v.std(ddof=1) if len(v) > 1 else 0.0
        st[g] = (v.mean(), sd)

    def norm(g, v):
        m, sd = st[g]
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(gl):
        return math.sqrt(sum((norm(g, gl[g]) - H[g]) ** 2 for g in G) / 3)

    nums = ["Clndrs", "Volume", "Model"]
    meds = {}
    for c in nums:
        v = [num(r.get(c)) for r in tr]
        v = [x for x in v if x is not None]
        meds[c] = float(np.median(v)) if v else 0.0
    cats = sorted({r.get("origin", "?") for r in tr})

    def feat(r):
        f = []
        for c in nums:
            x = num(r.get(c))
            f.append(meds[c] if x is None else x)
        o = r.get("origin", "?")
        f += [1.0 if o == k else 0.0 for k in cats]
        return f

    X, y = [], []
    for r in tr:
        gl = {g: num(r.get(g)) for g in G}
        if any(v is None for v in gl.values()):
            continue
        X.append(feat(r))
        y.append(d2h(gl))
    Xt = np.array([feat(r) for r in te])
    n = len(te)
    k = min(10, n)
    mu = np.zeros(n)
    sd = np.zeros(n)
    if X:
        rf = RandomForestRegressor(n_estimators=200, random_state=0, min_samples_leaf=2)
        rf.fit(np.array(X), np.array(y))
        P = np.array([t.predict(Xt) for t in rf.estimators_])
        mu, sd = P.mean(0), P.std(0)

    order = sorted(range(n), key=lambda i: (mu[i], i))
    chosen = order[: min(7, k)]
    rest = sorted((i for i in range(n) if i not in chosen), key=lambda i: (mu[i] - sd[i], i))
    chosen += rest[: k - len(chosen)]

    res = {}
    for i in chosen:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        d = json.loads(line)
        res[i] = d2h({g: float(d["goals"][g]) for g in G})

    top = sorted(res, key=lambda i: (round(res[i], 12), i))[:3]
    print(json.dumps({"selected": top}), flush=True)


main()
