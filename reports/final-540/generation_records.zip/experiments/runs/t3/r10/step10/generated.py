import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]


def fnum(v):
    try:
        return float(v)
    except Exception:
        return None


def main():
    a = sys.argv
    train_path = a[a.index("--train") + 1]
    test_path = a[a.index("--test") + 1]
    with open(train_path, newline="") as f:
        rd = list(csv.reader(f))
    th, trows = rd[0], [r for r in rd[1:] if r]
    ti = {c: i for i, c in enumerate(th)}
    st = {}
    for g in GOALS:
        v = np.array([float(r[ti[g]]) for r in trows])
        st[g] = (v.mean(), v.std(ddof=1))

    def norm(g, v):
        m, s = st[g]
        z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(gv):
        return math.sqrt(sum((norm(g, gv[g]) - HEAVEN[g]) ** 2 for g in GOALS) / 3)

    tr_d = [d2h({g: float(r[ti[g]]) for g in GOALS}) for r in trows]
    target = sorted(tr_d)[len(trows) // 4]

    cats = sorted({r[ti["origin"]] for r in trows})
    med = {c: float(np.median([float(r[ti[c]]) for r in trows])) for c in NUM}

    def feat(get):
        x = []
        for c in NUM:
            v = fnum(get(c))
            if v is None or not math.isfinite(v):
                v = med[c]
            x.append(v)
        o = get("origin")
        x += [1.0 if o == k else 0.0 for k in cats]
        return x

    X = [feat(lambda c, r=r: r[ti[c]]) for r in trows]
    model = RandomForestRegressor(n_estimators=200, random_state=0, n_jobs=1)
    model.fit(np.array(X), np.array(tr_d))

    with open(test_path) as f:
        data = json.load(f)
    hi = {c: i for i, c in enumerate(data["header"])}
    rows = data["rows"]
    F = np.array([feat(lambda c, r=r: r[hi[c]]) for r in rows])
    pred = model.predict(F)

    def inspect(ep, strat, idx):
        print(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h({g: float(resp["goals"][g]) for g in GOALS})

    def metrics(obs):
        lt = 11
        for i, v in enumerate(obs):
            if round(v, 12) <= round(target, 12):
                lt = i + 1
                break
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lt}

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        order = sorted(pool, key=lambda i: (pred[i], i))[:10]
        ad = [inspect(e, "adaptive", i) for i in order]
        rnd = []
        for i in ep["random_order"][:10]:
            rnd.append(inspect(e, "random", i))
        results.append({"episode": e, "adaptive": metrics(ad), "random": metrics(rnd)})

    def certify(xs, ys):
        n, m = len(xs), len(ys)
        mx, my = sum(xs) / n, sum(ys) / m
        vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
        vy = sum((y - my) ** 2 for y in ys) / (m - 1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        cohen = abs(mx - my) / (math.sqrt(pv) + 1e-32)
        s = sum((x > y) - (x < y) for x in xs for y in ys)
        cl = abs(s) / (n * m)
        ks = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
                 for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
        return {"cohen": cohen, "cliffs": cl, "ks": ks,
                "same": bool(cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)}

    comp = {}
    for k in ["best5", "best10", "labels_to_target"]:
        comp[k] = certify([r["adaptive"][k] for r in results],
                          [r["random"][k] for r in results])
    print(json.dumps({"results": results, "comparisons": comp}), flush=True)


if __name__ == "__main__":
    main()
