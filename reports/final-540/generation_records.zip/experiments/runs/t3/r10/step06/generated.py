import csv, sys, json, math, argparse

GOALS = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]
NUMS = ["Clndrs", "Volume", "Model"]
FEATS = ["Clndrs", "Volume", "Model", "origin"]


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    v = (v or "").strip()
    if v == "" or v == "?":
        return None
    return float(v)


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    m = sum(vals) / n if n else 0.0
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def mk_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr, te = read(a.train), read(a.test)

    gn = {}
    for g, _ in GOALS:
        gn[g] = mk_norm(*stats([num(r[g]) for r in tr]))
    nn = {c: mk_norm(*stats([num(r[c]) for r in tr])) for c in NUMS}

    def gaps(r):
        return {g: abs(gn[g](num(r[g])) - h) for g, h in GOALS}

    def d2h(r):
        gp = gaps(r)
        return math.sqrt(sum(x * x for x in gp.values()) / 3)

    trd = [d2h(r) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(trd[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    cutoff = sorted(trd)[len(tr) // 2]

    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            vs = [num(r[c]) for r in grp]
            vs = [v for v in vs if v is not None]
            cs.append(nn[c](sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freq(grp, cat):
        known = [r["origin"].strip() for r in grp if r["origin"].strip() not in ("", "?")]
        return known.count(cat) / len(known) if known else 0.0

    def evidence(r):
        ev = {}
        for c in NUMS:
            x = num(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                ev[c] = 0.0
            else:
                nx = nn[c](x)
                ev[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        o = r["origin"].strip()
        if o in ("", "?"):
            ev["origin"] = 0.0
        else:
            ev["origin"] = max(0.0, freq(poor, o) - freq(good, o))
        return ev

    def srt(d):
        return [k for k in sorted(d, key=lambda k: (-round(d[k], 10), k))]

    n = len(te)
    sc = [d2h(r) for r in te]
    gp = [gaps(r) for r in te]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
            lose = k if win == j else j
            adv = {g: gp[lose][g] ** 2 - gp[win][g] ** 2 for g, _ in GOALS}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        weakest = srt(gp[j])[0]
        ev = evidence(te[j])
        fo = srt(ev)
        top = fo[0] if ev[fo[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f (car %d), cutoff %.3f; weakest goal %s." % (
            j, "accepted" if acc else "rejected", s, o, k, cutoff, weakest)
        if win is not None:
            text += " Recommend car %d; largest advantage goal %s." % (win, adv_goal)
        else:
            text += " Scores tie."
        if top is not None:
            text += " Top feature %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o, "cutoff": cutoff,
                    "accepted": acc, "winner": win, "advantage_goal": adv_goal,
                    "weakest_goal": weakest, "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


main()
