import sys, csv, json, bisect
import numpy as np

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    X = []
    for r in rows:
        v = []
        for c in NUM:
            try:
                v.append(float(r[c]))
            except (ValueError, TypeError, KeyError):
                v.append(np.nan)
        X.append(v)
    o = [(r.get(CAT) or "?").strip() for r in rows]
    return np.array(X, float).reshape(len(rows), len(NUM)), o


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    Xt, ot = load(tr)
    Xs, os_ = load(te)

    med = np.nanmedian(Xt, axis=0)
    med = np.where(np.isnan(med), 0.0, med)
    mad = np.nanmedian(np.abs(Xt - med), axis=0) * 1.4826
    sd = np.nanstd(Xt, axis=0)
    sc = np.where(mad > 1e-12, mad, np.where(sd > 1e-12, sd, 1.0))

    def fill(X):
        X = X.copy()
        idx = np.where(np.isnan(X))
        X[idx] = med[idx[1]]
        return X

    Xt = fill(Xt)
    Xs = fill(Xs)
    mu = Xt.mean(0)
    cov = np.cov(Xt.T) + 1e-6 * np.eye(len(NUM))
    ci = np.linalg.pinv(cov)

    freq = {}
    for c in ot:
        freq[c] = freq.get(c, 0) + 1
    n = max(len(ot), 1)

    def raw(X, o):
        z = np.abs((X - med) / sc).max(1)
        d = X - mu
        m = np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", d, ci, d), 0)) / np.sqrt(len(NUM))
        cat = np.array([-np.log((freq.get(c, 0) + 0.5) / (n + 0.5)) for c in o])
        cat = np.maximum(cat - np.log(n / (n * 1.0)) - 2.0, 0) if False else np.maximum(cat - 3.0, 0)
        return np.maximum(z, m * 1.5) + cat

    rt = np.sort(raw(Xt, ot))
    rs = raw(Xs, os_)
    N = len(rt)

    def ecdf(v):
        return bisect.bisect_right(rt.tolist(), v) / N if N else 0.0

    rtl = rt.tolist()
    scores = [min(1.0, max(0.0, bisect.bisect_right(rtl, float(v)) / max(N, 1))) for v in rs]
    thr = 0.97
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))


if __name__ == "__main__":
    main()
