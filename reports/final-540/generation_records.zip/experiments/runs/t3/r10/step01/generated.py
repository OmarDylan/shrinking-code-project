import sys, csv, json, math, argparse


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train", required=True)
    p.add_argument("--test", required=True)
    a = p.parse_args()
    goals = ["Lbs-", "Acc+", "Mpg+"]
    heaven = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
    train = read(a.train)
    test = read(a.test)
    stats = {}
    for g in goals:
        v = [float(r[g]) for r in train]
        n = len(v)
        m = sum(v) / n
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)

    def norm(g, x):
        m, sd = stats[g]
        z = max(-3.0, min(3.0, (x - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    scores = []
    for r in test:
        s = sum((norm(g, float(r[g])) - heaven[g]) ** 2 for g in goals)
        scores.append(math.sqrt(s / 3))
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(scores) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(out))


main()
