import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import RidgeCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

def read(p):
    with open(p, newline="") as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return h, rows

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    ht, rt = read(tr)
    hs, rs = read(te)
    def col(h, rows, name):
        if name not in h:
            return [float("nan") if name != "origin" else "?"] * len(rows)
        i = h.index(name)
        vals = [r[i] if i < len(r) else "?" for r in rows]
        return vals if name == "origin" else [num(v) for v in vals]
    nums = ["Clndrs", "Volume", "Model"]
    Ntr = np.array([col(ht, rt, n) for n in nums], float).T
    Nte = np.array([col(hs, rs, n) for n in nums], float).T
    ot, os_ = col(ht, rt, "origin"), col(hs, rs, "origin")
    cats = sorted(set(ot) - {"?"})
    med = np.nanmedian(Ntr, axis=0)
    med = np.where(np.isfinite(med), med, 0)
    def oh(o):
        return np.array([[1.0 if x == c else 0.0 for c in cats] for x in o]).reshape(len(o), len(cats))
    def build(N, o, use_vol):
        N = np.where(np.isnan(N), med, N)
        idx = [0, 1, 2] if use_vol else [0, 2]
        return np.hstack([N[:, idx], oh(o)])
    G = np.array([col(ht, rt, n) for n in ["Lbs-", "Acc+", "Mpg+"]], float).T
    ok = np.all(np.isfinite(G), axis=1)
    mu = G[ok].mean(0)
    sd = G[ok].std(0, ddof=1)
    heaven = np.array([0.0, 1.0, 1.0])
    def d2h(V):
        z = np.clip((V - mu) / (sd + 1e-32), -3, 3)
        n = 1 / (1 + np.exp(-1.702 * z))
        return np.sqrt(((n - heaven) ** 2).sum(1) / 3)
    Y = np.hstack([G, d2h(G)[:, None]])
    volmiss = np.isnan(Nte[:, 1])
    preds = np.zeros((len(rs), 4))
    for use_vol in (True, False):
        m = ~volmiss if use_vol else volmiss
        if not m.any():
            continue
        Xtr = build(Ntr, ot, use_vol)[ok]
        Xte = build(Nte[m], [os_[i] for i in np.where(m)[0]], use_vol)
        for j in range(4):
            rf = RandomForestRegressor(200, min_samples_leaf=2, random_state=0).fit(Xtr, Y[ok, j])
            rg = make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 2, 9))).fit(Xtr, Y[ok, j])
            preds[m, j] = 0.6 * rf.predict(Xte) + 0.4 * rg.predict(Xte)
    mpg = np.maximum(preds[:, 2], 1.0)
    comp = d2h(np.column_stack([preds[:, 0], preds[:, 1], mpg]))
    sc = np.clip(0.5 * comp + 0.5 * preds[:, 3], 0, 1)
    print(json.dumps({"mpg": [float(x) for x in mpg], "scores": [float(x) for x in sc]}))

main()
