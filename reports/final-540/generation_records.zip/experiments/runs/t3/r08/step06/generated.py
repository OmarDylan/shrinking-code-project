import sys, csv, math, json

GOALS = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]
NUMS = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def fnum(v):
    try:
        v = (v or "").strip()
        if v == "?" or v == "":
            return None
        return float(v)
    except ValueError:
        return None


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def mknorm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))
    return f


def main():
    a = sys.argv[1:]
    if not a or a[0] != "justify":
        sys.exit(1)
    train = read(a[a.index("--train") + 1])
    test = read(a[a.index("--test") + 1])

    gn = {}
    for g, _ in GOALS:
        gn[g] = mknorm(*stats([fnum(r[g]) for r in train]))
    nn = {c: mknorm(*stats([fnum(r[c]) for r in train])) for c in NUMS}

    def gaps(r):
        return {g: abs(gn[g](fnum(r[g])) - h) for g, h in GOALS}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    tr_scores = [d2h(r) for r in train]
    cutoff = sorted(tr_scores)[len(train) // 2]

    order = sorted(range(len(train)), key=lambda i: (round(tr_scores[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            vs = [fnum(r[c]) for r in grp]
            vs = [v for v in vs if v is not None]
            cs.append(nn[c](sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freq(grp, cat):
        known = [r[CAT].strip() for r in grp if r[CAT].strip() not in ("?", "")]
        return known.count(cat) / len(known) if known else 0.0

    def evidence(r):
        ev = {}
        for c in NUMS:
            x = fnum(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                ev[c] = 0.0
            else:
                nx = nn[c](x)
                ev[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cat = r[CAT].strip()
        if cat in ("?", ""):
            ev[CAT] = 0.0
        else:
            ev[CAT] = max(0.0, freq(poor, cat) - freq(good, cat))
        return ev

    sc = [d2h(r) for r in test]
    gp = [gaps(r) for r in test]
    n = len(test)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        gorder = sorted(gp[j], key=lambda g: (-round(gp[j][g], 10), g))
        ev = evidence(test[j])
        forder = sorted(ev, key=lambda f: (-round(ev[f], 10), f))
        weakest = gorder[0]
        top = forder[0] if ev[forder[0]] > 1e-10 else None
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: gp[loser][g] ** 2 - gp[winner][g] ** 2 for g, _ in GOALS}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        text = "Car %d %s: score %.3f, other score %.3f (car %d), cutoff %.3f. Weakest goal: %s." % (
            j, "accepted" if accepted else "rejected", s, o, k, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; largest advantage in %s." % (winner, adv_goal)
        else:
            text += " The comparison is a tie."
        if top is not None:
            text += " Top feature: %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": accepted, "winner": winner,
                    "advantage_goal": adv_goal, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


main()
