import sys, csv, json, math
import numpy as np
from sklearn.ensemble import IsolationForest

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    X = np.array([[float(r[c]) if r[c].strip() not in ("?", "") else np.nan for c in NUM] for r in rows]).reshape(len(rows), 3)
    o = [r[CAT].strip() for r in rows]
    return X, o


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    Xt, ot = load(tr)
    Xs, os_ = load(te)
    med = np.nanmedian(Xt, axis=0)
    med = np.where(np.isnan(med), 0, med)
    mad = np.nanmedian(np.abs(Xt - med), axis=0) * 1.4826
    sd = np.nanstd(Xt, axis=0)
    sc = np.where(mad > 1e-12, mad, np.where(sd > 1e-12, sd, 1.0))
    cats = sorted(set(ot))
    cnt = {c: ot.count(c) for c in cats}
    n = len(ot)
    k = len(cats)

    def prob(c):
        return (cnt.get(c, 0) + 0.5) / (n + 0.5 * (k + 1))

    def zmax(X, o):
        z = np.abs(np.nan_to_num((X - med) / sc, nan=0.0)).max(axis=1)
        zc = np.array([max(0.0, math.log(1 / prob(c)) - 2) * 1.5 for c in o])
        return np.maximum(z, zc)

    def enc(X, o):
        Xi = np.where(np.isnan(X), med, X)
        oh = np.array([[1.0 if c == v else 0.0 for v in cats] for c in o]).reshape(len(o), k)
        return np.hstack([Xi, oh])

    iso = IsolationForest(n_estimators=200, random_state=0).fit(enc(Xt, ot))
    zt = np.sort(zmax(Xt, ot))
    it = np.sort(-iso.score_samples(enc(Xt, ot)))

    def score(X, o):
        z = zmax(X, o)
        i = -iso.score_samples(enc(X, o))
        e1 = np.searchsorted(zt, z, side="right") / len(zt)
        e2 = np.searchsorted(it, i, side="right") / len(it)
        s = 0.5 * (e1 + e2)
        # boost extreme z beyond training range
        s = np.clip(s + 0.05 * np.tanh(np.maximum(z - zt[-1], 0)), 0, 1)
        return s

    st = score(Xt, ot)
    thr = float(np.clip(np.quantile(st, 0.95), 0, 1))
    ss = score(Xs, os_)
    out = {"scores": [float(x) for x in ss], "alerts": [bool(x > thr) for x in ss], "threshold": thr}
    print(json.dumps(out))


if __name__ == "__main__":
    main()
