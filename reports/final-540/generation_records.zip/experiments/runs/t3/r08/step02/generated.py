import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor


def read(path):
    with open(path, newline="") as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    rows = [[c.strip() for c in row] for row in r[1:] if row]
    return h, rows


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def col(h, rows, name):
    if name not in h:
        return None
    i = h.index(name)
    return [row[i] if i < len(row) else "?" for row in rows]


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h1, r1 = read(tr)
    h2, r2 = read(te)

    def feats(h, rows):
        n = len(rows)
        out = {}
        for k in ("Clndrs", "Volume", "Model"):
            c = col(h, rows, k)
            out[k] = np.array([num(x) for x in c]) if c else np.full(n, np.nan)
        c = col(h, rows, "origin")
        out["origin"] = c if c else ["?"] * n
        return out

    goals = {}
    for g in ("Lbs-", "Acc+", "Mpg+"):
        goals[g] = np.array([num(x) for x in col(h1, r1, g)])
    ok = np.all([np.isfinite(v) for v in goals.values()], axis=0)
    F1 = feats(h1, r1)
    F2 = feats(h2, r2)
    F1 = {k: (np.array(v)[ok] if k != "origin" else [x for x, o in zip(v, ok) if o]) for k, v in F1.items()}
    goals = {k: v[ok] for k, v in goals.items()}

    cats = sorted(set(F1["origin"]) - {"?"})
    med = {k: (np.nanmedian(F1[k]) if np.isfinite(F1[k]).any() else 0.0) for k in ("Clndrs", "Volume", "Model")}

    def mat(F, vol):
        cols = []
        for k in ("Clndrs", "Model") + (("Volume",) if vol else ()):
            x = F[k].copy()
            x[~np.isfinite(x)] = med[k]
            cols.append(x)
        for c in cats:
            cols.append(np.array([1.0 if o == c else 0.0 for o in F["origin"]]))
        return np.column_stack(cols)

    # training d2h
    zs = []
    hv = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
    stats = {}
    for g, v in goals.items():
        m = v.mean()
        sd = v.std(ddof=1) if len(v) > 1 else 0.0
        stats[g] = (m, sd)

    def d2h_from(vals):
        s = 0.0
        for g in ("Lbs-", "Acc+", "Mpg+"):
            m, sd = stats[g]
            z = min(3.0, max(-3.0, (vals[g] - m) / (sd + 1e-32)))
            nv = 1 / (1 + np.exp(-1.702 * z))
            s = s + (nv - hv[g]) ** 2
        return np.sqrt(s / 3)

    dtrain = d2h_from(goals)
    targets = {"mpg": goals["Mpg+"], "lbs": goals["Lbs-"], "acc": goals["Acc+"], "d2h": dtrain}

    n = len(r2)
    pred = {k: np.zeros(n) for k in targets}
    vol_missing = ~np.isfinite(F2["Volume"])
    for vol in (True, False):
        idx = np.where(~vol_missing if vol else vol_missing)[0]
        if len(idx) == 0:
            continue
        X = mat(F1, vol)
        Xt = mat({k: (v[idx] if k != "origin" else [v[i] for i in idx]) for k, v in F2.items()}, vol)
        for k, y in targets.items():
            rf = RandomForestRegressor(200, min_samples_leaf=2, random_state=0).fit(X, y)
            gb = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05,
                                           subsample=0.8, random_state=0).fit(X, y)
            pred[k][idx] = 0.5 * rf.predict(Xt) + 0.5 * gb.predict(Xt)

    comp = d2h_from({"Lbs-": pred["lbs"], "Acc+": pred["acc"], "Mpg+": pred["mpg"]})
    sc = np.clip(0.5 * pred["d2h"] + 0.5 * comp, 0, 1)
    mpg = np.maximum(pred["mpg"], 1e-3)
    json.dump({"mpg": [float(x) for x in mpg], "scores": [float(x) for x in sc]}, sys.stdout)


main()
