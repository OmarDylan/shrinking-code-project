import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMS = ["Clndrs", "Volume", "Model"]


def isnum(v):
    try:
        float(v)
        return True
    except Exception:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    if a.cmd != "race":
        sys.exit(1)

    with open(a.train, newline="") as f:
        rd = list(csv.reader(f))
    th = [h.strip() for h in rd[0]]
    trows = [r for r in rd[1:] if r]
    ti = {h: i for i, h in enumerate(th)}

    stats = {}
    for g in GOALS:
        v = np.array([float(r[ti[g]]) for r in trows])
        stats[g] = (v.mean(), v.std(ddof=1))

    def norm(g, v):
        m, s = stats[g]
        z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(gd):
        return math.sqrt(sum((norm(g, gd[g]) - HEAVEN[g]) ** 2 for g in GOALS) / 3)

    tr_d = np.array([d2h({g: float(r[ti[g]]) for g in GOALS}) for r in trows])
    target = sorted(tr_d)[len(trows) // 4]

    # features
    nstat = {}
    for c in NUMS:
        v = np.array([float(r[ti[c]]) for r in trows if isnum(r[ti[c]])])
        nstat[c] = (v.mean(), v.std(ddof=1) + 1e-9)
    cats = sorted({r[ti["origin"]].strip() for r in trows})

    def feat(get):
        out = []
        for c in NUMS:
            x = get(c)
            out.append(0.0 if x is None else (x - nstat[c][0]) / nstat[c][1])
        o = get("origin")
        out += [1.0 if o == k else 0.0 for k in cats]
        return out

    def tget(r):
        def g(c):
            v = r[ti[c]].strip()
            if c == "origin":
                return v
            return float(v) if isnum(v) else None
        return g

    X = np.array([feat(tget(r)) for r in trows])
    model = RandomForestRegressor(n_estimators=200, min_samples_leaf=2, random_state=0, n_jobs=1)
    model.fit(X, tr_d)

    with open(a.test) as f:
        data = json.load(f)
    hd = [h.strip() for h in data["header"]]
    hi = {h: i for i, h in enumerate(hd)}
    rows = data["rows"]

    def sget(r):
        def g(c):
            v = r[hi[c]]
            if c == "origin":
                return str(v).strip()
            if isinstance(v, (int, float)):
                return float(v)
            v = str(v).strip()
            return float(v) if isnum(v) else None
        return g

    XT = np.array([feat(sget(r)) for r in rows])
    pred = model.predict(XT)

    def ask(ep, strat, idx):
        sys.stdout.write(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}) + "\n")
        sys.stdout.flush()
        line = sys.stdin.readline()
        resp = json.loads(line)
        return d2h({g: float(resp["goals"][g]) for g in GOALS})

    def metrics(obs):
        lab = 11
        for i, v in enumerate(obs):
            if round(v, 12) <= round(target, 12):
                lab = i + 1
                break
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lab}

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        # adaptive
        obs_idx, obs_val = [], []
        remaining = list(pool)
        for _ in range(10):
            best, bs = None, None
            for j in remaining:
                adj = 0.0
                if obs_idx:
                    d2 = ((XT[obs_idx] - XT[j]) ** 2).sum(axis=1)
                    w = np.exp(-d2 / 1.0)
                    res = np.array(obs_val) - pred[obs_idx]
                    adj = float((w * res).sum() / (w.sum() + 1.0))
                s = pred[j] + adj
                if bs is None or s < bs or (s == bs and j < best):
                    best, bs = j, s
            remaining.remove(best)
            v = ask(e, "adaptive", best)
            obs_idx.append(best)
            obs_val.append(v)
        ad = metrics(obs_val)
        rv = []
        for j in ep["random_order"][:10]:
            rv.append(ask(e, "random", j))
        results.append({"episode": e, "adaptive": ad, "random": metrics(rv)})

    def cert(xs, ys):
        n, m = len(xs), len(ys)
        xa, ya = np.array(xs, float), np.array(ys, float)
        vx, vy = xa.var(ddof=1), ya.var(ddof=1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        cohen = abs(xa.mean() - ya.mean()) / (math.sqrt(pv) + 1e-32)
        s = sum((x > y) - (x < y) for x in xs for y in ys)
        cl = abs(s) / (n * m)
        ks = 0.0
        for v in set(xs) | set(ys):
            d = abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
            ks = max(ks, d)
        ks /= math.sqrt(1 / n + 1 / m)
        return {"cohen": float(cohen), "cliffs": float(cl), "ks": float(ks),
                "same": bool(cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)}

    comps = {}
    for k in ["best5", "best10", "labels_to_target"]:
        comps[k] = cert([r["adaptive"][k] for r in results], [r["random"][k] for r in results])
    sys.stdout.write(json.dumps({"results": results, "comparisons": comps}) + "\n")
    sys.stdout.flush()


main()
