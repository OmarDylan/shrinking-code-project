import sys, json, math, argparse
from bisect import bisect_right


def stats(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(max(pv, 0.0)) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    d = 0.0
    for v in set(sx) | set(sy):
        d = max(d, abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    return cohen, cliffs, ks


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train")
    p.add_argument("--test")
    a = p.parse_args()
    with open(a.test) as f:
        cases = json.load(f)
    out = []
    for c in cases:
        co, cl, ks = stats([float(v) for v in c["xs"]], [float(v) for v in c["ys"]])
        out.append({"cohen": co, "cliffs": cl, "ks": ks,
                    "same": bool(co <= 0.35 and cl <= 0.197 and ks <= 1.36)})
    json.dump({"comparisons": out}, sys.stdout)


if __name__ == "__main__":
    main()
