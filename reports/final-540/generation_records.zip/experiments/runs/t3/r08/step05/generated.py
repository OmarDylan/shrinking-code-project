import csv, sys, json, math

def read(p):
    with open(p, newline='') as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return h, rows

def stats(v):
    n = len(v)
    if n == 0:
        return 0.0, 0.0
    m = sum(v) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
    return m, sd

def mk(m, sd):
    def norm(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return norm

def num(s):
    return None if s == '?' or s == '' else float(s)

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, T = read(tr)
    _, S = read(te)
    ix = {n: i for i, n in enumerate(h)}
    goals = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    gn = {}
    for g in goals:
        gn[g] = mk(*stats([float(r[ix[g]]) for r in T]))
    nums = ['Clndrs', 'Volume', 'Model']
    nn = {}
    for c in nums:
        nn[c] = mk(*stats([x for x in (num(r[ix[c]]) for r in T) if x is not None]))

    def d2h(r):
        return math.sqrt(sum((gn[g](float(r[ix[g]])) - hv) ** 2 for g, hv in goals.items()) / 3)

    order = sorted(range(len(T)), key=lambda i: (round(d2h(T[i]), 12), i))
    q = max(1, len(T) // 4)
    good = [T[i] for i in order[:q]]
    poor = [T[i] for i in order[-q:]]

    centers = {}
    for c in nums:
        cs = []
        for grp in (good, poor):
            v = [x for x in (num(r[ix[c]]) for r in grp) if x is not None]
            if v:
                cs.append(nn[c](sum(v) / len(v)))
            else:
                cs.append(None)
        centers[c] = cs

    def freq(grp):
        v = [r[ix['origin']] for r in grp if r[ix['origin']] != '?' and r[ix['origin']] != '']
        d = {}
        for x in v:
            d[x] = d.get(x, 0) + 1
        return d, len(v)
    gf, gc = freq(good)
    pf, pc = freq(poor)

    out = []
    for r in S:
        gs = {g: abs(gn[g](float(r[ix[g]])) - hv) for g, hv in goals.items()}
        fs = {}
        for c in nums:
            x = num(r[ix[c]])
            gcn, pcn = centers[c]
            if x is None or gcn is None or pcn is None:
                fs[c] = 0.0
            else:
                z = nn[c](x)
                fs[c] = max(0.0, abs(z - gcn) - abs(z - pcn))
        o = r[ix['origin']]
        if o == '?' or o == '':
            fs['origin'] = 0.0
        else:
            pfr = pf.get(o, 0) / pc if pc else 0.0
            gfr = gf.get(o, 0) / gc if gc else 0.0
            fs['origin'] = max(0.0, pfr - gfr)
        srt = lambda d: [k for k in sorted(d, key=lambda k: (-round(d[k], 10), k))]
        out.append({"goals": gs, "features": fs, "goal_order": srt(gs), "feature_order": srt(fs)})
    print(json.dumps({"diagnoses": out}))

main()
