import csv, sys, json, math, argparse
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

NUM = ["Clndrs", "Volume", "Model"]
GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = [0, 1, 1]


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def fnum(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def sd_(x):
    return float(np.std(x, ddof=1)) if len(x) > 1 else 0.0


def d2h(vals, stats):
    t = 0.0
    for v, (m, s), h in zip(vals, stats, HEAVEN):
        z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
        n = 1 / (1 + math.exp(-1.702 * z))
        t += (n - h) ** 2
    return math.sqrt(t / 3)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    xa, ya = np.array(xs, float), np.array(ys, float)
    vx, vy = xa.var(ddof=1), ya.var(ddof=1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(xa.mean() - ya.mean()) / (math.sqrt(pv) + 1e-32)
    cl = abs(float(np.sign(xa[:, None] - ya[None, :]).sum())) / (n * m)
    xs_s, ys_s = np.sort(xa), np.sort(ya)
    vals = np.unique(np.concatenate([xa, ya]))
    fx = np.searchsorted(xs_s, vals, side="right") / n
    fy = np.searchsorted(ys_s, vals, side="right") / m
    ks = float(np.max(np.abs(fx - fy))) / math.sqrt(1 / n + 1 / m)
    return cohen, cl, ks, bool(cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr, te = read(a.train), read(a.test)
    cats = sorted({r["origin"] for r in tr})

    def feats(r, cols):
        f = [fnum(r[c]) for c in cols]
        f += [1.0 if r["origin"] == c else 0.0 for c in cats]
        return f

    Y = np.array([[fnum(r[g]) for g in GOALS] for r in tr])
    stats = [(Y[:, i].mean(), sd_(Y[:, i])) for i in range(3)]
    hist = [d2h(y, stats) for y in Y]
    cache = {}

    def models(cols):
        k = tuple(cols)
        if k not in cache:
            X = np.array([feats(r, cols) for r in tr])
            ms = []
            for i in range(3):
                m = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05,
                                              subsample=0.8, random_state=0)
                m.fit(X, Y[:, i])
                ms.append(m)
            cache[k] = ms
        return cache[k]

    mpg, scores = [], []
    for r in te:
        cols = [c for c in NUM if not math.isnan(fnum(r.get(c, "?")))]
        ms = models(cols)
        x = np.array([feats(r, cols)])
        p = [float(m.predict(x)[0]) for m in ms]
        mp = p[2]
        if not math.isfinite(mp) or mp <= 0:
            mp = max(1e-3, stats[2][0])
        p[2] = mp
        mpg.append(mp)
        scores.append(min(1.0, max(0.0, d2h(p, stats))))

    alerts = []
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, scores[i - 19:i + 1])[3])
    sys.stdout.write(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))


main()
