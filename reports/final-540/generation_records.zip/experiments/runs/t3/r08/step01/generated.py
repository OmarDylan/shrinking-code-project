import sys, csv, json, math

def load(path):
    with open(path, newline="") as f:
        rows = list(csv.reader(f))
    header = [h.strip() for h in rows[0]]
    return header, [[c.strip() for c in r] for r in rows[1:] if r]

def main():
    a = sys.argv
    if len(a) < 2 or a[1] != "remember":
        sys.exit(1)
    train = a[a.index("--train") + 1]
    test = a[a.index("--test") + 1]
    hd, tr = load(train)
    hd2, te = load(test)
    goals = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
    ti = [hd.index(g) for g, _ in goals]
    ei = [hd2.index(g) for g, _ in goals]

    stats = []
    for k in ti:
        vals = [float(r[k]) for r in tr if r[k] != "?"]
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats.append((m, sd))

    scores = []
    for r in te:
        s = 0.0
        for (m, sd), k, (_, h) in zip(stats, ei, goals):
            z = max(-3.0, min(3.0, (float(r[k]) - m) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        scores.append(math.sqrt(s / 3))

    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(scores) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(out))

main()
