import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor

G = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
NUM = ["Clndrs", "Volume", "Model"]


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def main():
    a = sys.argv
    train = a[a.index("--train") + 1]
    test = a[a.index("--test") + 1]
    tr, te = read(train), read(test)

    tr = [r for r in tr if all(num(r.get(g)) is not None for g in G)]
    stats = {}
    for g in G:
        v = np.array([float(r[g]) for r in tr])
        stats[g] = (v.mean(), v.std(ddof=1) if len(v) > 1 else 0.0)

    def d2h(gl):
        s = 0.0
        for g, h in G.items():
            m, sd = stats[g]
            z = max(-3, min(3, (gl[g] - m) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - h) ** 2
        return math.sqrt(s / 3)

    ytr = np.array([d2h({g: float(r[g]) for g in G}) for r in tr])

    cats = sorted({r.get("origin", "?") for r in tr})
    med = {}
    for c in NUM:
        v = [num(r.get(c)) for r in tr]
        v = [x for x in v if x is not None]
        med[c] = float(np.median(v)) if v else 0.0

    def feat(r):
        f = []
        for c in NUM:
            x = num(r.get(c))
            f.append(med[c] if x is None else x)
        o = r.get("origin", "?")
        f += [1.0 if o == k else 0.0 for k in cats]
        return f

    X = np.array([feat(r) for r in tr])
    Xt = np.array([feat(r) for r in te])
    n = len(te)
    k = min(10, n)
    rf = RandomForestRegressor(n_estimators=200, random_state=0, min_samples_leaf=2)
    rf.fit(X, ytr)
    pred = rf.predict(Xt)
    tp = np.array([t.predict(Xt) for t in rf.estimators_])
    sd = tp.std(axis=0)

    order = sorted(range(n), key=lambda i: (pred[i], i))
    chosen = order[: min(k, 8)]
    # exploration: uncertain candidates among next best by optimistic bound
    rest = [i for i in order if i not in chosen]
    rest.sort(key=lambda i: (pred[i] - sd[i], i))
    for i in rest:
        if len(chosen) >= k:
            break
        chosen.append(i)

    obs = {}
    for i in chosen:
        print(json.dumps({"inspect": int(i)}), flush=True)
        line = sys.stdin.readline()
        resp = json.loads(line)
        obs[i] = d2h({g: float(resp["goals"][g]) for g in G})

    ranked = sorted(obs, key=lambda i: (round(obs[i], 12), i))[:3]
    print(json.dumps({"selected": [int(i) for i in ranked]}), flush=True)


main()
