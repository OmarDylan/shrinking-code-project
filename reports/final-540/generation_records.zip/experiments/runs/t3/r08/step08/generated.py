import csv, sys, json, math

def read(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def main():
    a = sys.argv
    tr = read(a[a.index('--train') + 1])
    te = read(a[a.index('--test') + 1])
    sig = lambda z: 1 / (1 + math.exp(-1.702 * max(-3, min(3, z))))
    def stats(vals):
        m = sum(vals) / len(vals)
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1)) if len(vals) > 1 else 0
        return m, sd
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    heaven = {'Lbs-': 0, 'Acc+': 1, 'Mpg+': 1}
    gs = {g: stats([float(r[g]) for r in tr]) for g in goals}
    d2h = []
    for r in tr:
        s = 0
        for g in goals:
            m, sd = gs[g]
            s += (sig((float(r[g]) - m) / (sd + 1e-32)) - heaven[g]) ** 2
        d2h.append(math.sqrt(s / 3))
    num = ['Clndrs', 'Volume', 'Model']
    ns = {c: stats([float(r[c]) for r in tr]) for c in num}
    def enc(vals, origin):
        return ([sig((vals[i] - ns[c][0]) / (ns[c][1] + 1e-32)) for i, c in enumerate(num)], origin)
    trx = [enc([float(r[c]) for c in num], r['origin']) for r in tr]
    def dist(x, y):
        s = sum((p - q) ** 2 for p, q in zip(x[0], y[0])) + (0 if x[1] == y[1] else 1)
        return math.sqrt(s / 4)
    def pred(x):
        order = sorted(range(len(trx)), key=lambda i: (round(dist(x, trx[i]), 12), i))[:5]
        return sum(d2h[i] for i in order) / len(order)
    n = len(tr)
    cutoff = sorted(d2h)[n // 2]
    good = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))[:max(1, n // 4)]
    menu, seen = [], set()
    for i in good:
        p = (float(tr[i]['Clndrs']), float(tr[i]['Volume']))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break
    out = []
    for idx, r in enumerate(te):
        vals = [float(r[c]) for c in num]
        x = enc(vals, r['origin'])
        before = pred(x)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for (c, v) in menu:
            ch = {}
            if c != vals[0]:
                ch['Clndrs'] = c
            if v != vals[1]:
                ch['Volume'] = v
            if not ch:
                continue
            nv = [c, v, vals[2]]
            y = enc(nv, r['origin'])
            after = pred(y)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(x, y), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best:
            out.append({"row": idx, "before": before, "after": best[1], "changes": best[2], "status": "improved"})
        else:
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == '__main__':
    main()
