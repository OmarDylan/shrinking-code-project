import sys, csv, json
import numpy as np

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    X = np.array([[float(r[c]) if r.get(c, "?").strip() not in ("?", "") else np.nan
                   for c in NUM] for r in rows], dtype=float).reshape(len(rows), len(NUM))
    o = [(r.get(CAT) or "?").strip() for r in rows]
    return X, o


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    Xt, ot = load(tr)
    Xs, os_ = load(te)

    med = np.nanmedian(Xt, axis=0)
    med = np.where(np.isnan(med), 0.0, med)
    mad = np.nanmedian(np.abs(Xt - med), axis=0) * 1.4826
    sd = np.nanstd(Xt, axis=0)
    scale = np.maximum(np.maximum(mad, 0.5 * sd), 1e-9)

    full = Xt[~np.isnan(Xt).any(axis=1)]
    if len(full) < 3:
        full = np.where(np.isnan(Xt), med, Xt)
    mu = full.mean(axis=0)
    cov = np.cov(full, rowvar=False) + 1e-6 * np.eye(len(NUM))
    cats = set(c for c in ot if c != "?")

    def raw(x, o):
        obs = ~np.isnan(x)
        r = 0.0
        if obs.any():
            r = float(np.max(np.abs(x[obs] - med[obs]) / scale[obs]))
            idx = np.where(obs)[0]
            S = cov[np.ix_(idx, idx)]
            d = x[idx] - mu[idx]
            m2 = float(d @ np.linalg.pinv(S) @ d)
            r = max(r, np.sqrt(max(m2, 0.0)))
        if o != "?" and o not in cats and cats:
            r = max(r, 4.0)
        return r

    def squash(r):
        return float(1.0 - np.exp(-r / 4.0))

    train_scores = np.array([squash(raw(Xt[i], ot[i])) for i in range(len(Xt))])
    thr = float(np.quantile(train_scores, 0.98)) if len(train_scores) else 0.5
    thr = min(max(thr, 0.0), 1.0)
    scores = [min(max(squash(raw(Xs[i], os_[i])), 0.0), 1.0) for i in range(len(Xs))]
    alerts = [bool(s > thr) for s in scores]
    print(json.dumps({"scores": scores, "alerts": alerts, "threshold": thr}))


if __name__ == "__main__":
    main()
