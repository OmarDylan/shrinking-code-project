import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        hdr = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return hdr, rows


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h1, R1 = read(tr)
    h2, R2 = read(te)
    ix1 = {h: i for i, h in enumerate(h1)}
    ix2 = {h: i for i, h in enumerate(h2)}

    def col(R, ix, name):
        return [row[ix[name]] for row in R]

    origins = sorted(set(col(R1, ix1, "origin")))

    def feats(R, ix):
        X = []
        for row in R:
            f = [num(row[ix["Clndrs"]]), num(row[ix["Volume"]]), num(row[ix["Model"]])]
            o = row[ix["origin"]]
            f += [1.0 if o == k else 0.0 for k in origins]
            X.append(f)
        return np.array(X, float)

    Xtr = feats(R1, ix1)
    Xte = feats(R2, ix2)
    med = np.nanmedian(Xtr, axis=0)
    med = np.where(np.isnan(med), 0, med)
    for X in (Xtr, Xte):
        m = np.isnan(X)
        X[m] = np.take(med, np.where(m)[1])

    goals = ["Lbs-", "Acc+", "Mpg+"]
    Y = np.array([[num(row[ix1[g]]) for g in goals] for row in R1], float)
    mean = Y.mean(0)
    sd = Y.std(0, ddof=1)
    heaven = np.array([0.0, 1.0, 1.0])

    def d2h(V):
        V = np.asarray(V, float)
        z = np.clip((V - mean) / (sd + 1e-32), -3, 3)
        n = 1 / (1 + np.exp(-1.702 * z))
        return np.sqrt(((n - heaven) ** 2).sum(1) / 3)

    hist = d2h(Y)

    # models: with Volume, and without Volume
    keep_all = list(range(Xtr.shape[1]))
    keep_nov = [i for i in keep_all if i != 1]
    P = np.zeros((len(Xte), 3))
    vol_missing = np.array([
        math.isnan(num(row[ix2["Volume"]])) if "Volume" in ix2 else True for row in R2
    ])
    for j in range(3):
        for cols, mask in ((keep_all, ~vol_missing), (keep_nov, vol_missing)):
            if not mask.any():
                continue
            m = RandomForestRegressor(n_estimators=200, min_samples_leaf=2,
                                      random_state=0, n_jobs=1)
            m.fit(Xtr[:, cols], Y[:, j])
            P[mask, j] = m.predict(Xte[mask][:, cols])
    P[:, 2] = np.maximum(P[:, 2], 1e-3)
    scores = np.clip(d2h(P), 0.0, 1.0)
    mpg = P[:, 2]

    def same(xs, ys):
        xs = np.asarray(xs, float)
        ys = np.asarray(ys, float)
        n, m = len(xs), len(ys)
        vx, vy = xs.var(ddof=1), ys.var(ddof=1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        cohen = abs(xs.mean() - ys.mean()) / (math.sqrt(max(pv, 0)) + 1e-32)
        sx, sy = np.sort(xs), np.sort(ys)
        gt = np.searchsorted(sy, xs, side="left")  # y < x
        le = np.searchsorted(sy, xs, side="right")  # y <= x
        cl = abs(int(gt.sum()) - int((m - le).sum())) / (n * m)
        u = np.unique(np.concatenate([sx, sy]))
        fx = np.searchsorted(sx, u, side="right") / n
        fy = np.searchsorted(sy, u, side="right") / m
        ks = np.abs(fx - fy).max() / math.sqrt(1 / n + 1 / m)
        return cohen <= 0.35 and cl <= 0.197 and ks <= 1.36

    alerts = []
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not same(hist, scores[i - 19:i + 1]))

    print(json.dumps({"mpg": [float(x) for x in mpg],
                      "scores": [float(x) for x in scores],
                      "alerts": [bool(x) for x in alerts]}))


main()
