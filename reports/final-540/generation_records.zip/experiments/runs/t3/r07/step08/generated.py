import sys, csv, json, math

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]

    def load(p):
        with open(p, newline='') as f:
            return list(csv.DictReader(f))

    T, S = load(tr), load(te)

    def num(v):
        try:
            x = float(v)
            return x if math.isfinite(x) else None
        except Exception:
            return None

    def nm(v, m, s):
        z = max(-3, min(3, (v - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def stats(vals):
        n = len(vals)
        m = sum(vals) / n
        s = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1)) if n > 1 else 0.0
        return m, s

    goals = [('Lbs-', 0), ('Acc+', 1), ('Mpg+', 1)]
    gs = {g: stats([float(r[g]) for r in T]) for g, _ in goals}
    d2h = []
    for r in T:
        t = sum((nm(float(r[g]), *gs[g]) - h) ** 2 for g, h in goals)
        d2h.append(math.sqrt(t / 3))

    feats = ['Clndrs', 'Volume', 'Model']
    fs = {f: stats([float(r[f]) for r in T]) for f in feats}

    def enc(r):
        v = []
        for f in feats:
            x = num(r.get(f))
            v.append(None if x is None else nm(x, *fs[f]))
        return v, r.get('origin')

    TE = [enc(r) for r in T]
    n = len(T)

    def dist(A, B):
        s = 0.0
        for x, y in zip(A[0], B[0]):
            s += 0.25 if x is None or y is None else (x - y) ** 2
        s += 0.0 if A[1] == B[1] else 1.0
        return math.sqrt(s / 4)

    def pred(e):
        ds = sorted(range(n), key=lambda i: (round(dist(e, TE[i]), 12), i))[:5]
        return sum(d2h[i] for i in ds) / len(ds)

    cutoff = sorted(d2h)[n // 2]
    order = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = order[:max(1, n // 4)]
    menu = []
    for i in good:
        p = (float(T[i]['Clndrs']), float(T[i]['Volume']))
        if p not in menu:
            menu.append(p)
        if len(menu) == 12:
            break

    out = []
    for k, r in enumerate(S):
        e = enc(r)
        before = pred(e)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        c0, v0 = num(r.get('Clndrs')), num(r.get('Volume'))
        best = None
        for c, v in menu:
            ch = (c != c0) + (v != v0)
            if ch == 0:
                continue
            ne = ([nm(c, *fs['Clndrs']), nm(v, *fs['Volume']), e[0][2]], e[1])
            af = pred(ne)
            if round(before - af, 10) >= 0.05:
                key = (ch, round(dist(e, ne), 10), round(af, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, af, c, v)
        if best is None:
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            _, af, c, v = best
            chg = {}
            if c != c0:
                chg['Clndrs'] = c
            if v != v0:
                chg['Volume'] = v
            out.append({"row": k, "before": before, "after": af, "changes": chg, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == '__main__':
    main()
