import sys, csv, json, math

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMF = ["Clndrs", "Volume", "Model"]
CATF = ["origin"]


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    if v is None:
        return None
    v = v.strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1))


def norm(v, ms):
    m, sd = ms
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1.0 / (1.0 + math.exp(-1.702 * z))


def gaps(row, gs):
    return {g: abs(norm(num(row[g]), gs[g]) - HEAVEN[g]) for g in GOALS}


def d2h(row, gs):
    gp = gaps(row, gs)
    return math.sqrt(sum(x * x for x in gp.values()) / 3)


def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    train = read(tr)
    test = read(te)
    gs = {g: stats([num(r[g]) for r in train if num(r[g]) is not None]) for g in GOALS}
    fs = {f: stats([num(r[f]) for r in train if num(r[f]) is not None]) for f in NUMF}
    tsc = [d2h(r, gs) for r in train]
    cutoff = sorted(tsc)[len(train) // 2]
    order = sorted(range(len(train)), key=lambda i: (round(tsc[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]
    cen = {}
    for f in NUMF:
        c = []
        for grp in (good, poor):
            v = [num(r[f]) for r in grp if num(r[f]) is not None]
            c.append(norm(sum(v) / len(v), fs[f]) if v else None)
        cen[f] = c

    def freq(grp, f, cat):
        k = [r[f].strip() for r in grp if r[f].strip() not in ("?", "")]
        return k.count(cat) / len(k) if k else 0.0

    def evidence(r):
        ev = {}
        for f in NUMF:
            x = num(r[f])
            gc, pc = cen[f]
            if x is None or gc is None or pc is None:
                ev[f] = 0.0
            else:
                nx = norm(x, fs[f])
                ev[f] = max(0.0, abs(nx - gc) - abs(nx - pc))
        for f in CATF:
            c = r[f].strip()
            if c in ("?", ""):
                ev[f] = 0.0
            else:
                ev[f] = max(0.0, freq(poor, f, c) - freq(good, f, c))
        return ev

    n = len(test)
    scores = [d2h(r, gs) for r in test]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        gp = gaps(test[j], gs)
        ev = evidence(test[j])
        gorder = sorted(GOALS, key=lambda x: (-round(gp[x], 10), x))
        forder = sorted(NUMF + CATF, key=lambda x: (-round(ev[x], 10), x))
        weakest = gorder[0]
        top = forder[0] if ev[forder[0]] > 1e-10 else None
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            gw = gaps(test[winner], gs)
            gl = gaps(test[loser], gs)
            adv = {g: gl[g] ** 2 - gw[g] ** 2 for g in GOALS}
            adv_goal = sorted(GOALS, key=lambda g: (-round(adv[g], 10), g))[0]
        text = "Car %d %s: score %.3f, other score %.3f, cutoff %.3f; weakest goal %s." % (
            j, "accepted" if accepted else "rejected", s, o, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; largest advantage in %s." % (winner, adv_goal)
        else:
            text += " Scores tie."
        if top is not None:
            text += " Top feature: %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": accepted, "winner": winner,
                    "advantage_goal": adv_goal, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


if __name__ == "__main__":
    main()
