import csv, sys, math, json, argparse

GOALS = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        head = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return head, rows


def goals(head, rows, skip_missing):
    idx = [head.index(g) for g, _ in GOALS]
    out = []
    for row in rows:
        vals = [row[i] for i in idx]
        if skip_missing and "?" in vals:
            continue
        out.append([float(v) for v in vals])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()

    th, tr = read(a.train)
    train = goals(th, tr, True)
    sh, ts = read(a.test)
    test = goals(sh, ts, False)

    n = len(train)
    stats = []
    for j in range(3):
        col = [r[j] for r in train]
        m = sum(col) / n
        sd = math.sqrt(sum((x - m) ** 2 for x in col) / (n - 1)) if n > 1 else 0.0
        stats.append((m, sd))

    def norm(v, j):
        m, sd = stats[j]
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    scores = []
    for r in test:
        s = sum((norm(r[j], j) - GOALS[j][1]) ** 2 for j in range(3))
        scores.append(math.sqrt(s / 3))

    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    print(json.dumps({
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }))


main()
