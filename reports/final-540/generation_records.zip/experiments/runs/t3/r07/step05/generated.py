import csv, sys, json, math

FEATS_NUM = ["Clndrs", "Volume", "Model"]
FEAT_CAT = "origin"
GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    if v is None:
        return None
    v = v.strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1))


def make_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))
    return f


def d2h_of(row, gn):
    s = 0.0
    for g in GOALS:
        s += (gn[g](num(row[g])) - HEAVEN[g]) ** 2
    return math.sqrt(s / 3)


def order(d):
    return [k for k, _ in sorted(d.items(), key=lambda kv: (-round(kv[1], 10), kv[0]))]


def main():
    a = sys.argv
    train = read(a[a.index("--train") + 1])
    test = read(a[a.index("--test") + 1])
    train = [r for r in train if all(num(r[g]) is not None for g in GOALS)]
    gn = {}
    for g in GOALS:
        gn[g] = make_norm(*stats([num(r[g]) for r in train]))
    fn = {}
    for c in FEATS_NUM:
        fn[c] = make_norm(*stats([x for x in (num(r[c]) for r in train) if x is not None]))
    d = [d2h_of(r, gn) for r in train]
    idx = sorted(range(len(train)), key=lambda i: (round(d[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in idx[:q]]
    poor = [train[i] for i in idx[-q:]]

    centers = {}
    for c in FEATS_NUM:
        cs = []
        for grp in (good, poor):
            vs = [x for x in (num(r[c]) for r in grp) if x is not None]
            cs.append(fn[c](sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freqs(grp):
        vs = [r[FEAT_CAT].strip() for r in grp if r[FEAT_CAT].strip() not in ("?", "")]
        n = len(vs)
        out = {}
        for v in vs:
            out[v] = out.get(v, 0) + 1
        return out, n
    gf, gnn = freqs(good)
    pf, pnn = freqs(poor)

    res = []
    for r in test:
        goals = {g: abs(gn[g](num(r[g])) - HEAVEN[g]) for g in GOALS}
        feats = {}
        for c in FEATS_NUM:
            x = num(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = fn[c](x)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        v = (r.get(FEAT_CAT) or "").strip()
        if v in ("?", ""):
            feats[FEAT_CAT] = 0.0
        else:
            p = pf.get(v, 0) / pnn if pnn else 0.0
            g = gf.get(v, 0) / gnn if gnn else 0.0
            feats[FEAT_CAT] = max(0.0, p - g)
        res.append({"goals": goals, "features": feats,
                    "goal_order": order(goals), "feature_order": order(feats)})
    print(json.dumps({"diagnoses": res}))


if __name__ == "__main__":
    main()
