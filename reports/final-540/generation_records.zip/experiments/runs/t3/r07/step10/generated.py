import sys, json, csv, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = [0, 1, 1]


def num(v):
    try:
        return float(v)
    except Exception:
        return float("nan")


def cert(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
    ks = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
             for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cl, "ks": ks,
            "same": bool(cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    if a.cmd != "race":
        sys.exit(1)
    with open(a.train, newline="") as f:
        tr = list(csv.DictReader(f))
    st = {}
    for g in GOALS:
        v = np.array([num(r[g]) for r in tr])
        st[g] = (v.mean(), v.std(ddof=1))

    def d2h(vals):
        s = 0
        for g, h, v in zip(GOALS, HEAVEN, vals):
            mu, sd = st[g]
            z = max(-3, min(3, (v - mu) / (sd + 1e-32)))
            s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
        return math.sqrt(s / 3)

    ytr = np.array([d2h([num(r[g]) for g in GOALS]) for r in tr])
    target = sorted(ytr)[len(tr) // 4]
    cats = sorted({r["origin"] for r in tr if r["origin"] != "?"})
    nc = ["Clndrs", "Volume", "Model"]
    med = [np.nanmedian([num(r[c]) for r in tr]) for c in nc]

    def feat(get):
        x = []
        for c, md in zip(nc, med):
            v = num(get(c))
            x.append(md if math.isnan(v) else v)
        o = get("origin")
        return x + [1.0 if o == c else 0.0 for c in cats]

    Xtr = np.array([feat(r.get) for r in tr])

    with open(a.test) as f:
        data = json.load(f)
    hd = data["header"]
    rows = data["rows"]
    ix = {c: hd.index(c) for c in hd}
    Xall = np.array([feat(lambda c, r=r: r[ix[c]]) for r in rows])

    def inspect(ep, strat, i):
        print(json.dumps({"episode": ep, "strategy": strat, "inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h([float(resp["goals"][g]) for g in GOALS])

    def stats(obs):
        t = next((k + 1 for k, v in enumerate(obs)
                  if round(v, 12) <= round(target, 12)), 11)
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": t}

    res = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        # adaptive
        obs, chosen = [], []
        for step in range(10):
            if step == 0:
                X, y, w = Xtr, ytr, None
            else:
                X = np.vstack([Xtr, Xall[chosen]])
                y = np.concatenate([ytr, obs])
                w = np.concatenate([np.ones(len(ytr)), np.full(len(obs), 5.0)])
            m = RandomForestRegressor(n_estimators=40, min_samples_leaf=2, random_state=0)
            m.fit(X, y, sample_weight=w)
            rem = [i for i in pool if i not in chosen]
            p = m.predict(Xall[rem])
            pick = rem[int(np.argmin(p))]
            chosen.append(pick)
            obs.append(inspect(e, "adaptive", pick))
        ad = stats(obs)
        robs = []
        for i in ep["random_order"][:10]:
            robs.append(inspect(e, "random", i))
        res.append({"episode": e, "adaptive": ad, "random": stats(robs)})
    comp = {}
    for k in ["best5", "best10", "labels_to_target"]:
        comp[k] = cert([float(r["adaptive"][k]) for r in res],
                       [float(r["random"][k]) for r in res])
    print(json.dumps({"results": res, "comparisons": comp}), flush=True)


main()
