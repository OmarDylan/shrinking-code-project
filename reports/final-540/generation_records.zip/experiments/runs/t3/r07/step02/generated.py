import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return h, rows


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def col(h, rows, name):
    if name not in h:
        return None
    i = h.index(name)
    return [row[i] if i < len(row) else "?" for row in rows]


def main():
    a = sys.argv
    trp = a[a.index("--train") + 1]
    tep = a[a.index("--test") + 1]
    th, tr = read(trp)
    eh, te = read(tep)

    def feats(h, rows):
        n = len(rows)
        X = np.full((n, 3), np.nan)
        for j, nm in enumerate(["Clndrs", "Volume", "Model"]):
            c = col(h, rows, nm)
            if c is not None:
                X[:, j] = [num(x) for x in c]
        o = col(h, rows, "origin")
        o = o if o is not None else ["?"] * n
        return X, o

    Xtr, otr = feats(th, tr)
    Xte, ote = feats(eh, te)
    cats = sorted(set(otr) - {"?"})

    def oh(o):
        return np.array([[1.0 if x == c else 0.0 for c in cats] for x in o]).reshape(len(o), len(cats))

    G = np.array([[num(x) for x in col(th, tr, g)] for g in ["Lbs-", "Acc+", "Mpg+"]]).T
    ok = np.isfinite(G).all(axis=1)
    mean = np.nanmean(G[ok], axis=0)
    sd = np.std(G[ok], axis=0, ddof=1)
    z = np.clip((G - mean) / (sd + 1e-32), -3, 3)
    nm = 1 / (1 + np.exp(-1.702 * z))
    heaven = np.array([0.0, 1.0, 1.0])
    d2h = np.sqrt(((nm - heaven) ** 2).sum(axis=1) / 3)
    mpg = G[:, 2]

    med = np.nanmedian(Xtr, axis=0)
    med = np.where(np.isfinite(med), med, 0.0)

    def build(X, o, use_vol):
        X = X.copy()
        for j in range(3):
            m = ~np.isfinite(X[:, j])
            X[m, j] = med[j]
        if not use_vol:
            X = X[:, [0, 2]]
        return np.hstack([X, oh(o)])

    n = len(te)
    pm = np.zeros(n)
    pd_ = np.zeros(n)
    vol_missing = np.array([not math.isfinite(v) for v in Xte[:, 1]])
    for use_vol in (True, False):
        idx = np.where(vol_missing == (not use_vol))[0]
        if len(idx) == 0:
            continue
        A = build(Xtr, otr, use_vol)
        B = build(Xte[idx], [ote[i] for i in idx], use_vol)
        # mpg
        m = np.isfinite(mpg)
        rf = RandomForestRegressor(300, min_samples_leaf=2, random_state=0, n_jobs=1)
        gb = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0)
        rf.fit(A[m], mpg[m]); gb.fit(A[m], mpg[m])
        pm[idx] = 0.5 * rf.predict(B) + 0.5 * gb.predict(B)
        m = ok
        rf = RandomForestRegressor(300, min_samples_leaf=2, random_state=0, n_jobs=1)
        gb = GradientBoostingRegressor(n_estimators=150, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=0)
        rf.fit(A[m], d2h[m]); gb.fit(A[m], d2h[m])
        pd_[idx] = 0.5 * rf.predict(B) + 0.5 * gb.predict(B)

    fb = float(np.nanmean(mpg))
    pm = np.where(np.isfinite(pm), pm, fb)
    pm = np.maximum(pm, 1e-3)
    pd_ = np.clip(np.where(np.isfinite(pd_), pd_, float(d2h[ok].mean())), 0.0, 1.0)
    print(json.dumps({"mpg": [float(x) for x in pm], "scores": [float(x) for x in pd_]}))


main()
