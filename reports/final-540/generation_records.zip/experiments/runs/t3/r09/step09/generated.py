import csv, json, sys
import numpy as np

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f, skipinitialspace=True))
    return [{(k or "").strip(): (v or "").strip() for k, v in r.items()} for r in rows]


def tofloat(s):
    try:
        v = float(s)
        return v if np.isfinite(v) else np.nan
    except Exception:
        return np.nan


def mat(rows):
    return np.array([[tofloat(r.get(c, "?")) for c in NUM] for r in rows], float).reshape(len(rows), 3)


def main():
    a = sys.argv[1:]
    train = load(a[a.index("--train") + 1])
    test = load(a[a.index("--test") + 1])
    Xtr, Xte = mat(train), mat(test)
    med = np.nanmedian(Xtr, axis=0)
    med = np.where(np.isfinite(med), med, 0.0)
    for X in (Xtr, Xte):
        idx = np.where(~np.isfinite(X))
        X[idx] = med[idx[1]]
    mad = 1.4826 * np.median(np.abs(Xtr - med), axis=0)
    sd = Xtr.std(axis=0)
    scale = np.where(mad > 1e-12, mad, np.where(sd > 1e-12, sd, 1.0))
    mu = Xtr.mean(axis=0)
    cov = np.cov(Xtr, rowvar=False) if len(Xtr) > 2 else np.eye(3)
    cov = np.atleast_2d(cov) + np.eye(3) * 1e-6 * (np.trace(np.atleast_2d(cov)) + 1e-12)
    inv = np.linalg.pinv(cov)
    cats = {}
    for r in train:
        c = r.get(CAT, "?")
        if c != "?" and c != "":
            cats[c] = cats.get(c, 0) + 1

    def raw(X, rows):
        z = np.abs(X - med) / scale
        d = X - mu
        maha = np.sqrt(np.maximum(np.einsum("ij,jk,ik->i", d, inv, d), 0))
        r = np.maximum(z.max(axis=1), maha)
        extra = np.array([4.0 if (x.get(CAT, "?") not in ("?", "") and x.get(CAT) not in cats) else 0.0 for x in rows])
        return r + extra

    rtr = raw(Xtr, train)
    rte = raw(Xte, test)
    t0 = float(np.quantile(rtr, 0.97)) if len(rtr) else 1.0
    t0 = max(t0, 1e-9)
    f = lambda r: r / (r + t0)
    scores = [float(min(1.0, max(0.0, v))) for v in f(rte)]
    thr = 0.5
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))


if __name__ == "__main__":
    main()
