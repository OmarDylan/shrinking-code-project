import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

GOALS = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]


def read(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        hdr = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return hdr, rows


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else float("nan")
    except Exception:
        return float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()

    th, tr = read(a.train)
    eh, te = read(a.test)
    ti = {h: i for i, h in enumerate(th)}
    ei = {h: i for i, h in enumerate(eh)}

    def get(row, idx, name):
        i = idx.get(name)
        return row[i] if i is not None and i < len(row) else "?"

    # goals in train
    G = np.array([[num(get(r, ti, g)) for g, _ in GOALS] for r in tr])
    ok = ~np.isnan(G).any(axis=1)
    tr = [r for r, k in zip(tr, ok) if k]
    G = G[ok]
    mean = G.mean(0)
    sd = G.std(0, ddof=1)
    Z = np.clip((G - mean) / (sd + 1e-32), -3, 3)
    N = 1 / (1 + np.exp(-1.702 * Z))
    H = np.array([h for _, h in GOALS])
    d2h = np.sqrt(((N - H) ** 2).sum(1) / 3)
    mpg = G[:, 2]

    cats = sorted({get(r, ti, "origin") for r in tr})

    def feats(rows, idx, vol):
        X = []
        for r in rows:
            f = [num(get(r, idx, "Clndrs")), num(get(r, idx, "Model"))]
            if vol:
                f.append(num(get(r, idx, "Volume")))
            o = get(r, idx, "origin")
            f += [1.0 if o == c else 0.0 for c in cats]
            X.append(f)
        return np.array(X, dtype=float)

    def fill(X, med):
        X = X.copy()
        m = np.isnan(X)
        X[m] = np.take(med, np.where(m)[1])
        return X

    n = len(te)
    out_m = np.zeros(n)
    out_s = np.zeros(n)
    fallback_m, fallback_s = float(mpg.mean()), float(d2h.mean())
    for vol in (True, False):
        sel = [i for i, r in enumerate(te)
               if (not math.isnan(num(get(r, ei, "Volume")))) == vol]
        if not sel:
            continue
        Xt = feats(tr, ti, vol)
        med = np.nanmedian(Xt, axis=0)
        med = np.where(np.isnan(med), 0.0, med)
        Xt = fill(Xt, med)
        Xe = fill(feats([te[i] for i in sel], ei, vol), med)
        for y, out, lo, hi in ((np.log(np.maximum(mpg, 1e-6)), out_m, None, None),
                               (d2h, out_s, 0.0, 1.0)):
            preds = []
            rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=2,
                                       random_state=0).fit(Xt, y)
            preds.append(rf.predict(Xe))
            gb = GradientBoostingRegressor(n_estimators=150, max_depth=2,
                                           learning_rate=0.05, subsample=0.8,
                                           random_state=0).fit(Xt, y)
            preds.append(gb.predict(Xe))
            p = np.mean(preds, axis=0)
            for k, i in enumerate(sel):
                out[i] = p[k]
    mp = np.exp(out_m)
    mp = np.where(np.isfinite(mp) & (mp > 0), mp, fallback_m)
    sc = np.clip(np.where(np.isfinite(out_s), out_s, fallback_s), 0.0, 1.0)
    print(json.dumps({"mpg": [float(x) for x in mp], "scores": [float(x) for x in sc]}))


main()
