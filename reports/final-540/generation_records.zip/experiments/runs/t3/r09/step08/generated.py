import csv, sys, json, math, argparse

GOALS = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def stats(vals):
    n = len(vals)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def norm(v, ms):
    m, sd = ms
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1.0 / (1.0 + math.exp(-1.702 * z))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    if a.cmd != "fix":
        sys.exit(1)
    tr = read(a.train)
    te = read(a.test)
    n = len(tr)
    gs = {g: stats([float(r[g]) for r in tr]) for g, _ in GOALS}
    d2h = []
    for r in tr:
        s = sum((norm(float(r[g]), gs[g]) - h) ** 2 for g, h in GOALS)
        d2h.append(math.sqrt(s / 3))
    cutoff = sorted(d2h)[n // 2]
    nums = ["Clndrs", "Volume", "Model"]
    fs = {c: stats([float(r[c]) for r in tr]) for c in nums}
    trn = [([norm(float(r[c]), fs[c]) for c in nums], r["origin"]) for r in tr]

    def enc(vals, org):
        return ([norm(vals[i], fs[c]) if vals[i] is not None else None
                 for i, c in enumerate(nums)], org)

    def dist(A, B):
        s = 0.0
        for x, y in zip(A[0], B[0]):
            s += 1.0 if (x is None or y is None) else (x - y) ** 2
        s += 0.0 if A[1] == B[1] else 1.0
        return math.sqrt(s / 4)

    def predict(e):
        ds = sorted(range(n), key=lambda i: (round(dist(e, trn[i]), 12), i))[:5]
        return sum(d2h[i] for i in ds) / len(ds)

    order = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = order[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (float(tr[i]["Clndrs"]), float(tr[i]["Volume"]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for idx, r in enumerate(te):
        vals = [num(r.get(c)) for c in nums]
        org = r.get("origin")
        e0 = enc(vals, org)
        before = predict(e0)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "already_good"})
            continue
        best = None
        for (c, v) in menu:
            ch = int(vals[0] != c) + int(vals[1] != v)
            if ch == 0:
                continue
            nv = [c, v, vals[2]]
            e1 = enc(nv, org)
            after = predict(e1)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(e0, e1), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, c, v)
        if best is None:
            out.append({"row": idx, "before": before, "after": before,
                        "changes": {}, "status": "no_candidate"})
        else:
            _, after, c, v = best
            changes = {}
            if vals[0] != c:
                changes["Clndrs"] = c
            if vals[1] != v:
                changes["Volume"] = v
            out.append({"row": idx, "before": before, "after": after,
                        "changes": changes, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))


main()
