import csv, sys, json, math

def read(p):
    with open(p, newline='') as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else '?') for k, v in row.items()} for row in r]

def num(v):
    if v is None or v == '?' or v == '':
        return None
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except ValueError:
        return None

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1))

def mknorm(m, s):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    train = read(tr)
    test = read(te)
    goals = [('Lbs-', 0.0), ('Acc+', 1.0), ('Mpg+', 1.0)]
    nums = ['Clndrs', 'Volume', 'Model']
    cat = 'origin'
    train = [r for r in train if all(num(r.get(g)) is not None for g, _ in goals)]
    gn = {}
    for g, _ in goals:
        gn[g] = mknorm(*stats([num(r[g]) for r in train]))
    fn = {}
    for c in nums:
        fn[c] = mknorm(*stats([x for x in (num(r.get(c)) for r in train) if x is not None]))

    def d2h(r):
        return math.sqrt(sum((gn[g](num(r[g])) - h) ** 2 for g, h in goals) / 3)

    order = sorted(range(len(train)), key=lambda i: (round(d2h(train[i]), 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for c in nums:
        cs = []
        for grp in (good, poor):
            v = [x for x in (num(r.get(c)) for r in grp) if x is not None]
            cs.append(fn[c](sum(v) / len(v)) if v else None)
        centers[c] = cs

    def freq(grp):
        vals = [r.get(cat, '?') for r in grp if r.get(cat, '?') not in ('?', '')]
        d = {}
        for v in vals:
            d[v] = d.get(v, 0) + 1
        n = len(vals)
        return d, n
    gf, gnn = freq(good)
    pf, pnn = freq(poor)

    out = []
    for r in test:
        gs = {}
        for g, h in goals:
            v = num(r.get(g))
            gs[g] = min(1.0, max(0.0, abs(gn[g](v) - h))) if v is not None else 0.0
        fs = {}
        for c in nums:
            x = num(r.get(c))
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                fs[c] = 0.0
            else:
                z = fn[c](x)
                fs[c] = max(0.0, abs(z - gc) - abs(z - pc))
        v = r.get(cat, '?')
        if v in ('?', ''):
            fs[cat] = 0.0
        else:
            pfr = pf.get(v, 0) / pnn if pnn else 0.0
            gfr = gf.get(v, 0) / gnn if gnn else 0.0
            fs[cat] = max(0.0, pfr - gfr)
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    sys.stdout.write(json.dumps({"diagnoses": out}))

main()
