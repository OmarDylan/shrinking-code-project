import sys, csv, json, math
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

def read(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    return [h.strip() for h in r[0]], [x for x in r[1:] if x]

def num(v):
    try:
        return float(v)
    except Exception:
        return float('nan')

def certify_same(xs, ys):
    xs = np.asarray(xs, float); ys = np.asarray(ys, float)
    n, m = len(xs), len(ys)
    vx, vy = xs.var(ddof=1), ys.var(ddof=1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(xs.mean() - ys.mean()) / (math.sqrt(pv) + 1e-32)
    cl = abs(np.sign(xs[:, None] - ys[None, :]).sum()) / (n * m)
    sx, sy = np.sort(xs), np.sort(ys)
    u = np.unique(np.concatenate([xs, ys]))
    d = np.abs(np.searchsorted(sx, u, 'right') / n - np.searchsorted(sy, u, 'right') / m).max()
    ks = d / math.sqrt(1 / n + 1 / m)
    return cohen <= 0.35 and cl <= 0.197 and ks <= 1.36

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    H, R = read(tr)
    Ht, Rt = read(te)
    ix = {h: i for i, h in enumerate(H)}
    it = {h: i for i, h in enumerate(Ht)}
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    G = np.array([[num(r[ix[g]]) for g in goals] for r in R])
    mean = G.mean(0); sd = G.std(0, ddof=1)
    heaven = np.array([0.0, 1.0, 1.0])

    def d2h(g):
        z = np.clip((g - mean) / (sd + 1e-32), -3, 3)
        nv = 1 / (1 + np.exp(-1.702 * z))
        return float(np.sqrt(((nv - heaven) ** 2).sum() / 3))

    hist = [d2h(g) for g in G]
    cats = sorted({r[ix['origin']] for r in R})

    def feats(rows, idx, useVol):
        out = []
        for r in rows:
            f = [num(r[idx['Clndrs']])]
            if useVol:
                f.append(num(r[idx['Volume']]))
            f.append(num(r[idx['Model']]))
            o = r[idx['origin']] if 'origin' in idx else ''
            f += [1.0 if o == c else 0.0 for c in cats]
            out.append(f)
        return np.array(out, float)

    models = {}
    for uv in (True, False):
        X = feats(R, ix, uv)
        med = np.nanmedian(X, 0)
        X = np.where(np.isnan(X), med, X)
        ms = [GradientBoostingRegressor(random_state=0, n_estimators=150, max_depth=3,
                                        learning_rate=0.05, subsample=0.8).fit(X, G[:, k])
              for k in range(3)]
        models[uv] = (ms, med)

    mpg, scores, alerts = [], [], []
    for i, r in enumerate(Rt):
        v = num(r[it['Volume']]) if 'Volume' in it else float('nan')
        uv = not math.isnan(v)
        ms, med = models[uv]
        x = feats([r], it, uv)
        x = np.where(np.isnan(x), med, x)
        g = np.array([m.predict(x)[0] for m in ms])
        g[2] = max(g[2], 1e-3)
        s = min(1.0, max(0.0, d2h(g)))
        mpg.append(float(g[2])); scores.append(s)
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify_same(hist, scores[-20:]))
    print(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))

main()
