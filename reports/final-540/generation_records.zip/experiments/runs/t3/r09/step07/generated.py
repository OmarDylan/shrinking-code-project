import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor

G = ["Lbs-", "Acc+", "Mpg+"]
H = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr = read(a.train)
    te = read(a.test)

    # goal statistics from training
    st = {}
    for g in G:
        vs = [num(r.get(g, "?")) for r in tr]
        vs = [v for v in vs if v is not None]
        m = sum(vs) / len(vs)
        sd = math.sqrt(sum((v - m) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 0.0
        st[g] = (m, sd)

    def nrm(g, v):
        m, sd = st[g]
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(goals):
        return math.sqrt(sum((nrm(g, goals[g]) - H[g]) ** 2 for g in G) / 3)

    # features
    med = {}
    for c in NUM:
        vs = sorted(v for v in (num(r.get(c, "?")) for r in tr) if v is not None)
        med[c] = vs[len(vs) // 2] if vs else 0.0
    cats = sorted({r.get("origin", "?") for r in tr} | {r.get("origin", "?") for r in te})

    def feat(r):
        f = []
        for c in NUM:
            v = num(r.get(c, "?"))
            f.append(med[c] if v is None else v)
        o = r.get("origin", "?")
        f += [1.0 if o == k else 0.0 for k in cats]
        return f

    X0, y0 = [], []
    for r in tr:
        vals = {g: num(r.get(g, "?")) for g in G}
        if any(v is None for v in vals.values()):
            continue
        X0.append(feat(r))
        y0.append(d2h(vals))
    Xte = np.array([feat(r) for r in te])
    X0 = np.array(X0)
    y0 = np.array(y0)

    seen = {}
    n = len(te)
    budget = min(10, n)
    for _ in range(budget):
        X, y = X0, y0
        if seen:
            idx = list(seen)
            X = np.vstack([X0, Xte[idx]])
            y = np.concatenate([y0, [seen[i] for i in idx]])
        rf = RandomForestRegressor(n_estimators=100, random_state=0, min_samples_leaf=2)
        rf.fit(X, y)
        pred = rf.predict(Xte)
        cand = [i for i in range(n) if i not in seen]
        i = min(cand, key=lambda k: (pred[k], k))
        print(json.dumps({"inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        seen[i] = d2h(resp["goals"])

    order = sorted(seen, key=lambda k: (round(seen[k], 12), k))
    print(json.dumps({"selected": order[:3]}), flush=True)


main()
