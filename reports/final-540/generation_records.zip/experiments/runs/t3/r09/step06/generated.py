import csv, sys, json, math, argparse

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"
FEATS = NUM + [CAT]


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    v = (v or "").strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    m = sum(vals) / n if n else 0.0
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def mk_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr, te = read(a.train), read(a.test)

    gn = {g: mk_norm(*stats([num(r[g]) for r in tr])) for g in GOALS}
    fn = {c: mk_norm(*stats([num(r[c]) for r in tr])) for c in NUM}

    def gaps(r):
        return {g: abs(gn[g](num(r[g])) - h) for g, h in GOALS.items()}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    tsc = [d2h(r) for r in tr]
    srt = sorted(tsc)
    cutoff = srt[len(tr) // 2]
    order = sorted(range(len(tr)), key=lambda i: (round(tsc[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]

    centers = {}
    for c in NUM:
        cs = []
        for grp in (good, poor):
            vs = [num(r[c]) for r in grp]
            vs = [v for v in vs if v is not None]
            cs.append(fn[c](sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freq(grp, cat):
        kn = [r[CAT] for r in grp if r[CAT].strip() not in ("?", "")]
        return kn.count(cat) / len(kn) if kn else 0.0

    def feat_ev(r):
        ev = {}
        for c in NUM:
            x = num(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                ev[c] = 0.0
            else:
                nx = fn[c](x)
                ev[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cat = r[CAT].strip()
        if cat in ("?", ""):
            ev[CAT] = 0.0
        else:
            ev[CAT] = max(0.0, freq(poor, cat) - freq(good, cat))
        return ev

    n = len(te)
    sc = [d2h(r) for r in te]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            gw, gl = gaps(te[win]), gaps(te[lose])
            ad = {g: gl[g] ** 2 - gw[g] ** 2 for g in GOALS}
            adv = sorted(ad, key=lambda g: (-round(ad[g], 10), g))[0]
        gp = gaps(te[j])
        gord = sorted(gp, key=lambda g: (-round(gp[g], 10), g))
        ev = feat_ev(te[j])
        ford = sorted(ev, key=lambda f: (-round(ev[f], 10), f))
        weakest = gord[0]
        top = ford[0] if ev[ford[0]] > 1e-10 else None
        t = (f"Car {j} {'accepted' if acc else 'rejected'}: score {s:.3f}, "
             f"other score {o:.3f}, cutoff {cutoff:.3f}. Weakest goal: {weakest}. ")
        if win is not None:
            t += f"Recommend car {win} because of advantage in {adv}. "
        else:
            t += "The comparison is a tie. "
        if top is not None:
            t += f"Top feature: {top} (retrospective association, not causal)."
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": bool(acc), "winner": win,
                    "advantage_goal": adv, "weakest_goal": weakest,
                    "top_feature": top, "text": t})
    sys.stdout.write(json.dumps({"explanations": out}))


if __name__ == "__main__":
    main()
