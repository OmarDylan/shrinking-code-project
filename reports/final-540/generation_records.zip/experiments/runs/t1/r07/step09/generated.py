import csv, sys, json, math, statistics as st

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"

def load(p):
    with open(p, newline="") as f:
        r = csv.DictReader(f)
        rows = []
        for d in r:
            d = {k.strip(): (v.strip() if v else "?") for k, v in d.items() if k}
            row = {}
            for c in NUM:
                try:
                    row[c] = float(d.get(c, "?"))
                except ValueError:
                    row[c] = None
            v = d.get(CAT, "?")
            row[CAT] = None if v == "?" else v
            rows.append(row)
    return rows

def robust(vals):
    m = st.median(vals)
    mad = st.median([abs(v - m) for v in vals]) * 1.4826
    sd = st.pstdev(vals) if len(vals) > 1 else 0.0
    s = mad if mad > 1e-12 else sd
    return m, max(s, 0.1 * sd, 1e-9)

def fit(train):
    M = {}
    for c in NUM:
        vals = [r[c] for r in train if r[c] is not None]
        M[c] = robust(vals) if vals else (0.0, 1.0)
    groups = {}
    for r in train:
        if r["Clndrs"] is not None and r["Volume"] is not None:
            groups.setdefault(r["Clndrs"], []).append(r["Volume"])
    G = {k: robust(v) for k, v in groups.items() if len(v) >= 5}
    cats = {}
    n = 0
    for r in train:
        if r[CAT] is not None:
            cats[r[CAT]] = cats.get(r[CAT], 0) + 1
            n += 1
    return M, G, cats, n

def raw(r, model):
    M, G, cats, n = model
    z = [0.0]
    for c in NUM:
        if r[c] is not None:
            m, s = M[c]
            z.append(abs(r[c] - m) / s)
    if r["Clndrs"] is not None and r["Volume"] is not None:
        g = G.get(r["Clndrs"])
        if g:
            z.append(abs(r["Volume"] - g[0]) / g[1])
        elif G:
            z.append(3.0)  # unseen cylinder count
    if r[CAT] is not None and n:
        f = cats.get(r[CAT], 0) / n
        z.append(0.0 if f >= 0.05 else (6.0 if f == 0 else 2.0 + 1.0 * (0.05 - f) / 0.05))
    return max(z)

def sc(x):
    x = x if math.isfinite(x) else 1e6
    return x / (x + 4.0)

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    train, test = load(tr), load(te)
    model = fit(train)
    ts = sorted(sc(raw(r, model)) for r in train)
    if ts:
        thr = ts[min(len(ts) - 1, int(0.97 * len(ts)))]
    else:
        thr = 0.5
    thr = min(max(thr, 0.0), 1.0)
    scores = [min(max(sc(raw(r, model)), 0.0), 1.0) for r in test]
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "spot":
        main()
