import sys, csv, json, math

def load(path):
    with open(path, newline='') as f:
        r = list(csv.reader(f))
    return [h.strip() for h in r[0]], [[c.strip() for c in row] for row in r[1:] if row]

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def main():
    a = sys.argv[1:]
    if not a or a[0] != 'fix':
        sys.exit(1)
    tr = te = None
    for i, x in enumerate(a):
        if x == '--train': tr = a[i + 1]
        if x == '--test': te = a[i + 1]
    H, T = load(tr)
    H2, S = load(te)
    ix = {h: i for i, h in enumerate(H)}
    ix2 = {h: i for i, h in enumerate(H2)}

    def stats(vals):
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return m, sd

    def mk(m, sd):
        def f(v):
            z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
            return 1 / (1 + math.exp(-1.702 * z))
        return f

    goals = [('Lbs-', 0.0), ('Acc+', 1.0), ('Mpg+', 1.0)]
    gn = {}
    for g, _ in goals:
        gn[g] = mk(*stats([float(r[ix[g]]) for r in T]))
    d2h = []
    for r in T:
        s = sum((gn[g](float(r[ix[g]])) - h) ** 2 for g, h in goals)
        d2h.append(math.sqrt(s / 3))
    nums = ['Clndrs', 'Volume', 'Model']
    nf = {c: mk(*stats([float(r[ix[c]]) for r in T])) for c in nums}

    def enc(row, idx):
        return ([nf[c](float(row[idx[c]])) for c in nums], row[idx['origin']])
    TE = [enc(r, ix) for r in T]

    def dist(A, B):
        s = sum((x - y) ** 2 for x, y in zip(A[0], B[0]))
        s += 0.0 if A[1] == B[1] else 1.0
        return math.sqrt(s / 4)

    def pred(E):
        ds = sorted(range(len(TE)), key=lambda i: (round(dist(E, TE[i]), 12), i))[:5]
        return sum(d2h[i] for i in ds) / len(ds)

    n = len(T)
    cutoff = sorted(d2h)[n // 2]
    rank = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = rank[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (float(T[i][ix['Clndrs']]), float(T[i][ix['Volume']]))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for k, r in enumerate(S):
        E = enc(r, ix2)
        c0 = float(r[ix2['Clndrs']])
        v0 = float(r[ix2['Volume']])
        before = pred(E)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for (c, v) in menu:
            ch = (c != c0) + (v != v0)
            if ch == 0:
                continue
            E2 = ([nf['Clndrs'](c), nf['Volume'](v), E[0][2]], E[1])
            after = pred(E2)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(E, E2), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, c, v, after)
        if best is None:
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            _, c, v, after = best
            changes = {}
            if c != c0: changes['Clndrs'] = c
            if v != v0: changes['Volume'] = v
            out.append({"row": k, "before": before, "after": after, "changes": changes, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

main()
