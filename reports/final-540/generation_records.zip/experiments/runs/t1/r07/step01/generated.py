import csv, sys, json, math

def read(path):
    with open(path, newline='') as f:
        return list(csv.DictReader(f))

def main():
    a = sys.argv[1:]
    if not a or a[0] != 'remember':
        sys.exit(1)
    train = test = None
    i = 1
    while i < len(a):
        if a[i] == '--train':
            train = a[i + 1]
            i += 2
        elif a[i] == '--test':
            test = a[i + 1]
            i += 2
        else:
            i += 1
    tr = read(train)
    te = read(test)
    goals = [('Lbs-', 0.0), ('Acc+', 1.0), ('Mpg+', 1.0)]
    stats = {}
    for g, _ in goals:
        v = [float(r[g]) for r in tr]
        n = len(v)
        m = sum(v) / n
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)
    scores = []
    for r in te:
        s = 0.0
        for g, h in goals:
            m, sd = stats[g]
            z = (float(r[g]) - m) / (sd + 1e-32)
            z = max(-3.0, min(3.0, z))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        scores.append(math.sqrt(s / 3))
    order = sorted(range(len(scores)), key=lambda k: (scores[k], k))
    out = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(out))

main()
