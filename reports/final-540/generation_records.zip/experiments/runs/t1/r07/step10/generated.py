import sys, json, csv, math, argparse

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMF = ["Clndrs", "Volume", "Model"]


def norm(v, m, s):
    z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def stats(vals):
    n = len(vals)
    m = sum(vals) / n
    s = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1)) if n > 1 else 0.0
    return m, s


def num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def mean(a):
    return sum(a) / len(a)


def var(a):
    m = mean(a)
    return sum((x - m) ** 2 for x in a) / (len(a) - 1)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    pv = ((n - 1) * var(xs) + (m - 1) * var(ys)) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    t = 0
    for x in xs:
        for y in ys:
            t += (x > y) - (x < y)
    cl = abs(t) / (n * m)
    ks = 0.0
    for v in set(xs) | set(ys):
        d = abs(sum(1 for x in xs if x <= v) / n - sum(1 for y in ys if y <= v) / m)
        ks = max(ks, d)
    ks /= math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cl, "ks": ks,
            "same": bool(cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)}


def race(train_path, test_path):
    with open(train_path, newline="") as f:
        rd = list(csv.reader(f))
    h = rd[0]
    ix = {c: i for i, c in enumerate(h)}
    trows = rd[1:]
    gs = {}
    for g in GOALS:
        gs[g] = stats([float(r[ix[g]]) for r in trows])
    fs = {}
    for c in NUMF:
        fs[c] = stats([v for v in (num(r[ix[c]]) for r in trows) if v is not None])

    def d2h(vals):
        return math.sqrt(sum((norm(vals[g], *gs[g]) - HEAVEN[g]) ** 2 for g in GOALS) / 3)

    def feat(get):
        out = []
        for c in NUMF:
            v = num(get(c))
            out.append(None if v is None else norm(v, *fs[c]))
        o = get("origin")
        out.append(None if o in (None, "?") else o.strip())
        return out

    def dist(a, b):
        t = 0.0
        for k in range(4):
            x, y = a[k], b[k]
            if x is None or y is None:
                g = 0.5 if k < 3 else 0.5
            elif k < 3:
                g = x - y
            else:
                g = 0.0 if x == y else 1.0
            t += g * g
        return math.sqrt(t / 4)

    tf, ts = [], []
    for r in trows:
        tf.append(feat(lambda c, r=r: r[ix[c]]))
        ts.append(d2h({g: float(r[ix[g]]) for g in GOALS}))
    sd = sorted(ts)
    target = round(sd[len(ts) // 4], 12)

    data = json.load(open(test_path))
    th = data["header"]
    hi = {c: i for i, c in enumerate(th)}
    rows = data["rows"]
    cache = {}

    def tfeat(i):
        if i not in cache:
            cache[i] = feat(lambda c: rows[i][hi[c]])
        return cache[i]

    pcache = {}

    def pred(i):
        if i not in pcache:
            f = tfeat(i)
            ds = sorted((round(dist(f, t), 12), j) for j, t in enumerate(tf))[:5]
            pcache[i] = mean([ts[j] for _, j in ds])
        return pcache[i]

    def inspect(e, strat, i):
        print(json.dumps({"episode": e, "strategy": strat, "inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h({g: float(resp["goals"][g]) for g in GOALS})

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        obs = []
        seen = set()
        for _ in range(10):
            best = None
            for i in pool:
                if i in seen:
                    continue
                sc = pred(i)
                sw = swr = 0.0
                for j, v in obs:
                    w = math.exp(-(dist(tfeat(i), tfeat(j)) / 0.25) ** 2)
                    sw += w
                    swr += w * (v - pred(j))
                sc += swr / (sw + 1.0)
                k = (sc, i)
                if best is None or k < best:
                    best = k
            i = best[1]
            seen.add(i)
            obs.append((i, inspect(e, "adaptive", i)))
        a = [v for _, v in obs]
        rv = []
        for i in ep["random_order"][:10]:
            rv.append(inspect(e, "random", i))

        def summ(v):
            lt = 11
            for k, x in enumerate(v):
                if round(x, 12) <= target:
                    lt = k + 1
                    break
            return {"best5": min(v[:5]), "best10": min(v), "labels_to_target": lt}
        results.append({"episode": e, "adaptive": summ(a), "random": summ(rv)})
    comps = {}
    for m in ["best5", "best10", "labels_to_target"]:
        comps[m] = certify([r["adaptive"][m] for r in results],
                           [r["random"][m] for r in results])
    print(json.dumps({"results": results, "comparisons": comps}), flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train")
    p.add_argument("--test")
    a = p.parse_args()
    if a.cmd == "race":
        race(a.train, a.test)


main()
