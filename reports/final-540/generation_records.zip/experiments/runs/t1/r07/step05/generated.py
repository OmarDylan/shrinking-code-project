import csv, sys, json, math

def load(p):
    with open(p, newline='') as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else '?') for k, v in row.items()} for row in r]

def mean_sd(v):
    n = len(v)
    if n == 0:
        return 0.0, 0.0
    m = sum(v) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((x - m) ** 2 for x in v) / (n - 1))

def mk(m, s):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"

def main():
    a = sys.argv
    train = load(a[a.index('--train') + 1])
    test = load(a[a.index('--test') + 1])
    gn = {g: mk(*mean_sd([float(r[g]) for r in train])) for g in GOALS}

    def d2h(r):
        return math.sqrt(sum((gn[g](float(r[g])) - h) ** 2 for g, h in GOALS.items()) / 3)

    order = sorted(range(len(train)), key=lambda i: (round(d2h(train[i]), 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    def num(r, c):
        v = r.get(c, '?')
        if v == '?' or v == '':
            return None
        return float(v)

    fn = {}
    centers = {}
    for c in NUM:
        col = [x for x in (num(r, c) for r in train) if x is not None]
        f = mk(*mean_sd(col))
        fn[c] = f
        cs = []
        for grp in (good, poor):
            vs = [x for x in (num(r, c) for r in grp) if x is not None]
            cs.append(f(sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freqs(grp):
        vs = [r.get(CAT, '?') for r in grp]
        vs = [v for v in vs if v != '?' and v != '']
        d = {}
        for v in vs:
            d[v] = d.get(v, 0) + 1
        n = len(vs)
        return {k: c / n for k, c in d.items()} if n else {}
    gf, pf = freqs(good), freqs(poor)

    out = []
    for r in test:
        feats = {}
        for c in NUM:
            x = num(r, c)
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = fn[c](x)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        v = r.get(CAT, '?')
        if v == '?' or v == '':
            feats[CAT] = 0.0
        else:
            feats[CAT] = max(0.0, pf.get(v, 0.0) - gf.get(v, 0.0))
        goals = {g: abs(gn[g](float(r[g])) - h) for g, h in GOALS.items()}
        srt = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": goals, "features": feats,
                    "goal_order": srt(goals), "feature_order": srt(feats)})
    print(json.dumps({"diagnoses": out}))

if __name__ == "__main__":
    main()
