import sys, csv, json, math

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def read(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def main():
    a = sys.argv
    tr = read(a[a.index('--train') + 1])
    te = read(a[a.index('--test') + 1])
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    heaven = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    rows = [r for r in tr if all(num(r.get(g, '?')) is not None for g in goals)]
    st = {}
    for g in goals:
        v = [num(r[g]) for r in rows]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st[g] = (m, sd)

    def norm(g, v):
        m, sd = st[g]
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(d):
        return math.sqrt(sum((norm(g, d[g]) - heaven[g]) ** 2 for g in goals) / 3)

    nf = ['Clndrs', 'Volume', 'Model']
    fs = {}
    for f in nf:
        v = [x for x in (num(r.get(f, '?')) for r in tr) if x is not None]
        if v:
            m = sum(v) / len(v)
            sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) or 1.0
        else:
            m, sd = 0.0, 1.0
        fs[f] = sd
    tscore = [d2h({g: num(r[g]) for g in goals}) for r in rows]

    def dist(r1, r2):
        t = 0.0
        c = 0
        for f in nf:
            x, y = num(r1.get(f, '?')), num(r2.get(f, '?'))
            if x is not None and y is not None:
                t += abs(x - y) / fs[f]
                c += 1
        o1, o2 = r1.get('origin', '?'), r2.get('origin', '?')
        if o1 != '?' and o2 != '?':
            t += 0.0 if o1 == o2 else 1.0
            c += 1
        return t / c if c else 1e9

    pred = []
    for i, r in enumerate(te):
        ds = sorted((dist(r, q), s) for q, s in zip(rows, tscore))[:5]
        w = [1 / (d + 0.1) for d, _ in ds]
        pred.append(sum(wi * s for wi, (_, s) in zip(w, ds)) / sum(w) if ds else 0.5)
    order = sorted(range(len(te)), key=lambda i: (pred[i], i))
    chosen, seen = [], set()
    for i in order:
        key = tuple(te[i].get(f, '?') for f in nf + ['origin'])
        if key in seen:
            continue
        seen.add(key)
        chosen.append(i)
        if len(chosen) == 10:
            break
    for i in order:
        if len(chosen) >= 10:
            break
        if i not in chosen:
            chosen.append(i)
    obs = []
    for i in chosen:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        gv = resp['goals']
        obs.append((round(d2h({g: float(gv[g]) for g in goals}), 12), i))
    obs.sort()
    print(json.dumps({"selected": [i for _, i in obs[:3]]}), flush=True)

main()
