import csv, sys, math

def read(p):
    with open(p, newline='') as f:
        r = csv.reader(f)
        h = [c.strip() for c in next(r)]
        return h, [row for row in r if row]

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(M[k][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for k in range(i + 1, n):
            f = M[k][i] / d
            for j in range(i, n + 1):
                M[k][j] -= f * M[i][j]
    w = [0.0] * n
    for i in range(n - 1, -1, -1):
        w[i] = (M[i][n] - sum(M[i][j] * w[j] for j in range(i + 1, n))) / (M[i][i] or 1e-12)
    return w

def mean(x): return sum(x) / len(x)
def sd(x):
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1))

def cert(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    co = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    ks = 0.0
    i = j = 0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v: i += 1
        while j < m and sy[j] <= v: j += 1
        ks = max(ks, abs(i / n - j / m))
    ks /= math.sqrt(1 / n + 1 / m)
    return co <= 0.35 and cl <= 0.197 and ks <= 1.36

def main():
    a = sys.argv
    tr, te = a[a.index('--train') + 1], a[a.index('--test') + 1]
    h, T = read(tr)
    h2, S = read(te)
    ix = {c: i for i, c in enumerate(h)}
    jx = {c: i for i, c in enumerate(h2)}
    def get(row, idx, c):
        if c not in idx or idx[c] >= len(row): return None
        return num(row[idx[c]])
    def org(row, idx):
        return row[idx['origin']].strip() if 'origin' in idx and idx['origin'] < len(row) else '?'
    num_c = ['Clndrs', 'Volume', 'Model']
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    G = [[get(r, ix, g) for g in goals] for r in T]
    keep = [k for k, g in enumerate(G) if None not in g]
    T = [T[k] for k in keep]; G = [G[k] for k in keep]
    gm = [mean([g[i] for g in G]) for i in range(3)]
    gs = [sd([g[i] for g in G]) for i in range(3)]
    def d2h(v):
        s = 0
        for i in range(3):
            z = max(-3, min(3, (v[i] - gm[i]) / (gs[i] + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - (0 if i == 0 else 1)) ** 2
        return math.sqrt(s / 3)
    hist = [d2h(g) for g in G]
    origins = sorted({org(r, ix) for r in T})
    cm = {}
    for c in num_c:
        vals = [get(r, ix, c) for r in T]
        vals = [v for v in vals if v is not None]
        cm[c] = mean(vals)
    def feat(row, idx, usevol):
        f = []
        for c in num_c:
            if c == 'Volume' and not usevol: continue
            v = get(row, idx, c)
            f.append(cm[c] if v is None else v)
        o = org(row, idx)
        f += [1.0 if o == k else 0.0 for k in origins]
        return f
    def fit(usevol):
        X = [feat(r, ix, usevol) for r in T]
        p = len(X[0])
        mu = [mean([x[j] for x in X]) for j in range(p)]
        sg = [(sd([x[j] for x in X]) or 1.0) for j in range(p)]
        Z = [[(x[j] - mu[j]) / sg[j] for j in range(p)] for x in X]
        A = [[sum(z[i] * z[j] for z in Z) + (1.0 if i == j else 0) for j in range(p)] for i in range(p)]
        ws = []
        ys = [[G[k][0], G[k][1], math.log(max(G[k][2], 1e-6))] for k in range(len(G))]
        ym = [mean([y[i] for y in ys]) for i in range(3)]
        for i in range(3):
            b = [sum(Z[k][j] * (ys[k][i] - ym[i]) for k in range(len(Z))) for j in range(p)]
            ws.append(solve(A, b))
        return mu, sg, ws, ym
    models = {True: fit(True), False: fit(False)}
    mpg, sc = [], []
    for r in S:
        uv = get(r, jx, 'Volume') is not None
        mu, sg, ws, ym = models[uv]
        f = feat(r, jx, uv)
        z = [(f[j] - mu[j]) / sg[j] for j in range(len(f))]
        pr = [ym[i] + sum(ws[i][j] * z[j] for j in range(len(z))) for i in range(3)]
        m = max(math.exp(pr[2]), 0.1)
        mpg.append(m)
        sc.append(min(1.0, max(0.0, d2h([pr[0], pr[1], m]))))
    al = []
    for i in range(len(sc)):
        if i < 19: al.append(False)
        else: al.append(not cert(hist, sc[i - 19:i + 1]))
    print(__import__('json').dumps({"mpg": mpg, "scores": sc, "alerts": al}))

main()
