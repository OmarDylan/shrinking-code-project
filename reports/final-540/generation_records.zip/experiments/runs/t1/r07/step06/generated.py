import csv, sys, json, math, argparse

def load(path):
    with open(path, newline='') as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows

def num(s):
    if s == '?' or s == '':
        return None
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except ValueError:
        return None

def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd

def make_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('cmd')
    ap.add_argument('--train')
    ap.add_argument('--test')
    a = ap.parse_args()
    th, tr = load(a.train)
    eh, te = load(a.test)
    goals = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    gnames = list(goals)
    nums = ['Clndrs', 'Volume', 'Model']
    cat = 'origin'
    ti = {h: i for i, h in enumerate(th)}
    ei = {h: i for i, h in enumerate(eh)}

    def col(rows, idx, name):
        return [num(r[idx[name]]) if idx[name] < len(r) else None for r in rows]

    norms = {}
    for g in gnames + nums:
        norms[g] = make_norm(*stats(col(tr, ti, g)))

    def d2h_gaps(vals):
        gaps = {g: abs(norms[g](vals[g]) - goals[g]) for g in gnames}
        return math.sqrt(sum(x * x for x in gaps.values()) / 3), gaps

    def rowgoals(rows, idx):
        out = []
        for r in rows:
            out.append({g: num(r[idx[g]]) for g in gnames})
        return out

    trg = rowgoals(tr, ti)
    trd = [d2h_gaps(v)[0] for v in trg]
    teg = rowgoals(te, ei)
    ted = [d2h_gaps(v) for v in teg]
    cutoff = sorted(trd)[len(trd) // 2]

    # blame groups
    order = sorted(range(len(tr)), key=lambda i: (round(trd[i], 12), i))
    q = max(1, len(tr) // 4)
    good = order[:q]
    poor = order[len(order) - q:]
    centers = {}
    for f in nums:
        c = col(tr, ti, f)
        cs = []
        for grp in (good, poor):
            vs = [c[i] for i in grp if c[i] is not None]
            cs.append(norms[f](sum(vs) / len(vs)) if vs else None)
        centers[f] = cs
    cidx = ti[cat]
    def freqs(grp):
        vals = [tr[i][cidx] for i in grp if tr[i][cidx] != '?' and tr[i][cidx] != '']
        d = {}
        for v in vals:
            d[v] = d.get(v, 0) + 1
        n = len(vals)
        return d, n
    gf, gn = freqs(good)
    pf, pn = freqs(poor)

    def evidence(r):
        ev = {}
        for f in nums:
            v = num(r[ei[f]]) if ei[f] < len(r) else None
            gc, pc = centers[f]
            if v is None or gc is None or pc is None:
                ev[f] = 0.0
            else:
                x = norms[f](v)
                ev[f] = max(0.0, abs(x - gc) - abs(x - pc))
        c = r[ei[cat]] if ei[cat] < len(r) else '?'
        if c in ('?', ''):
            ev[cat] = 0.0
        else:
            p = pf.get(c, 0) / pn if pn else 0.0
            g = gf.get(c, 0) / gn if gn else 0.0
            ev[cat] = max(0.0, p - g)
        return ev

    n = len(te)
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = ted[j][0], ted[k][0]
        accepted = round(s, 12) <= round(cutoff, 12)
        if round(s, 12) == round(o, 12):
            winner = None
        else:
            winner = j if s < o else k
        gaps = ted[j][1]
        gorder = sorted(gnames, key=lambda g: (-round(gaps[g], 10), g))
        weakest = gorder[0]
        adv_goal = None
        if winner is not None:
            loser = k if winner == j else j
            adv = {g: ted[loser][1][g] ** 2 - ted[winner][1][g] ** 2 for g in gnames}
            adv_goal = sorted(gnames, key=lambda g: (-round(adv[g], 10), g))[0]
        ev = evidence(te[j])
        forder = sorted(ev, key=lambda f: (-round(ev[f], 10), f))
        top = forder[0] if ev[forder[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f, cutoff %.3f; weakest goal %s." % (
            j, "accepted" if accepted else "rejected", s, o, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; largest advantage goal %s." % (winner, adv_goal)
        else:
            text += " The comparison is a tie."
        if top is not None:
            text += " Top feature %s (retrospective, not causal)." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o, "cutoff": cutoff,
                    "accepted": accepted, "winner": winner, "advantage_goal": adv_goal,
                    "weakest_goal": weakest, "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))

main()
