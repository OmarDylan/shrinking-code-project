import sys, csv, json, math

def load(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [row for row in r[1:] if row]

def num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def col(h, rows, name):
    i = next((k for k, c in enumerate(h) if c.rstrip('+-X') == name), None)
    return [(r[i].strip() if i is not None and i < len(r) else '?') for r in rows]

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(M[k][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for k in range(i + 1, n):
            f = M[k][i] / d
            for j in range(i, n + 1):
                M[k][j] -= f * M[i][j]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        x[i] = (M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n))) / (M[i][i] or 1e-12)
    return x

def ridge(X, y, lam=1.0):
    n, m = len(X), len(X[0])
    ym = sum(y) / n
    A = [[sum(X[k][i] * X[k][j] for k in range(n)) + (lam if i == j else 0) for j in range(m)] for i in range(m)]
    b = [sum(X[k][i] * (y[k] - ym) for k in range(n)) for i in range(m)]
    w = solve(A, b)
    return w, ym

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h1, R1 = load(tr)
    h2, R2 = load(te)
    def cols(h, R):
        return [col(h, R, n) for n in ('Clndrs', 'Volume', 'Model', 'origin')]
    C1, C2 = cols(h1, R1), cols(h2, R2)
    cats = sorted({v for v in C1[3] if v != '?'})
    means = []
    for j in range(3):
        vs = [num(v) for v in C1[j] if num(v) is not None]
        means.append(sum(vs) / len(vs) if vs else 0.0)
    def raw(C, i, vol):
        c = num(C[0][i]); v = num(C[1][i]); m = num(C[2][i])
        c = means[0] if c is None else c
        m = means[2] if m is None else m
        f = [c, m]
        if vol:
            v = means[1] if v is None else v
            f += [v, math.log(max(v, 1.0))]
        f += [1.0 if C[3][i] == k else 0.0 for k in cats]
        return f
    goals = [[num(v) for v in col(h1, R1, g)] for g in ('Lbs', 'Acc', 'Mpg')]
    idx = [i for i in range(len(R1)) if all(g[i] is not None for g in goals)]
    st = []
    for g in goals:
        vs = [g[i] for i in idx]
        mu = sum(vs) / len(vs)
        sd = math.sqrt(sum((x - mu) ** 2 for x in vs) / max(len(vs) - 1, 1))
        st.append((mu, sd))
    def nrm(v, s):
        z = max(-3, min(3, (v - s[0]) / (s[1] + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    d2h = []
    for i in idx:
        l, ac, mp = (nrm(goals[0][i], st[0]), nrm(goals[1][i], st[1]), nrm(goals[2][i], st[2]))
        d2h.append(math.sqrt(((l - 0) ** 2 + (ac - 1) ** 2 + (mp - 1) ** 2) / 3))
    logm = [math.log(max(goals[2][i], 1e-3)) for i in idx]
    models = {}
    for vol in (True, False):
        X = [raw(C1, i, vol) for i in idx]
        m = len(X[0])
        mu = [sum(r[j] for r in X) / len(X) for j in range(m)]
        sd = [math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / len(X)) or 1.0 for j in range(m)]
        Z = [[(r[j] - mu[j]) / sd[j] for j in range(m)] for r in X]
        models[vol] = (mu, sd, ridge(Z, logm), ridge(Z, d2h))
    mpg, sc = [], []
    for i in range(len(R2)):
        vol = num(C2[1][i]) is not None
        mu, sd, (wm, bm), (wd, bd) = models[vol]
        r = raw(C2, i, vol)
        z = [(r[j] - mu[j]) / sd[j] for j in range(len(r))]
        pm = bm + sum(p * q for p, q in zip(wm, z))
        pd = bd + sum(p * q for p, q in zip(wd, z))
        pm = min(max(pm, math.log(3)), math.log(100))
        mpg.append(math.exp(pm))
        sc.append(min(1.0, max(0.0, pd)))
    print(json.dumps({"mpg": mpg, "scores": sc}))

main()
