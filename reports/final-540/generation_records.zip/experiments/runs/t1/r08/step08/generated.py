import csv, sys, json, math

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def read(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def sig(z):
    return 1 / (1 + math.exp(-1.702 * z))

def main():
    a = sys.argv[1:]
    tr = read(a[a.index('--train') + 1])
    te = read(a[a.index('--test') + 1])
    stats = {}
    for c in ['Clndrs', 'Volume', 'Model', 'Lbs-', 'Acc+', 'Mpg+']:
        v = [num(r[c]) for r in tr]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        stats[c] = (m, sd)

    def norm(c, x):
        m, sd = stats[c]
        z = max(-3.0, min(3.0, (x - m) / (sd + 1e-32)))
        return sig(z)

    heaven = {'Lbs-': 0, 'Acc+': 1, 'Mpg+': 1}
    def d2h(r):
        return math.sqrt(sum((norm(g, float(r[g])) - h) ** 2 for g, h in heaven.items()) / 3)

    nin = ['Clndrs', 'Volume', 'Model']
    def feat(r):
        return ([None if num(r[c]) is None else norm(c, num(r[c])) for c in nin], r['origin'])
    trf = [feat(r) for r in tr]
    trd = [d2h(r) for r in tr]

    def dist(fa, fb):
        s = 0.0
        for x, y in zip(fa[0], fb[0]):
            if x is not None and y is not None:
                s += (x - y) ** 2
        s += 0.0 if fa[1] == fb[1] else 1.0
        return math.sqrt(s / 4)

    def pred(f):
        ds = sorted(range(len(tr)), key=lambda i: (round(dist(f, trf[i]), 12), i))[:5]
        return sum(trd[i] for i in ds) / len(ds)

    n = len(tr)
    cutoff = sorted(trd)[n // 2]
    rank = sorted(range(n), key=lambda i: (round(trd[i], 12), i))
    good = rank[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (float(tr[i]['Clndrs']), float(tr[i]['Volume']))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    out = []
    for idx, r in enumerate(te):
        f = feat(r)
        before = pred(f)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        oc, ov = num(r['Clndrs']), num(r['Volume'])
        best = None
        for (c, v) in menu:
            ch = (oc != c) + (ov != v)
            if ch == 0:
                continue
            nf = ([norm('Clndrs', c), norm('Volume', v), f[0][2]], f[1])
            after = pred(nf)
            if round(before - after, 10) >= 0.05:
                key = (ch, round(dist(f, nf), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, c, v)
        if best is None:
            out.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            _, after, c, v = best
            changes = {}
            if oc != c:
                changes['Clndrs'] = c
            if ov != v:
                changes['Volume'] = v
            out.append({"row": idx, "before": before, "after": after, "changes": changes, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": out}))

if __name__ == '__main__':
    main()
