import sys, json, math
from bisect import bisect_right


def stats(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)

    sx, sy = sorted(xs), sorted(ys)
    # Cliff's delta via sorted counts
    s = 0
    for x in sx:
        less = bisect_right(sy, x - 0) # placeholder replaced below
        lt = sum_lt(sy, x)
        le = bisect_right(sy, x)
        # x>y count = lt ; x<y count = m-le
        s += lt - (m - le)
    cliffs = abs(s) / (n * m)

    ks = 0.0
    for v in sorted(set(sx) | set(sy)):
        d = abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m)
        if d > ks:
            ks = d
    ks /= math.sqrt(1 / n + 1 / m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}


def sum_lt(sorted_list, x):
    from bisect import bisect_left
    return bisect_left(sorted_list, x)


def main():
    a = sys.argv[1:]
    if not a or a[0] != "certify":
        sys.exit(1)
    path = a[a.index("--test") + 1]
    with open(path) as f:
        cases = json.load(f)
    out = [stats([float(v) for v in c["xs"]], [float(v) for v in c["ys"]]) for c in cases]
    sys.stdout.write(json.dumps({"comparisons": out}))


main()
