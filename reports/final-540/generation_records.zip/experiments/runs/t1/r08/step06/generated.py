import csv, sys, json, math

G = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]
NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def load(p):
    with open(p, newline="") as f:
        r = csv.DictReader(f, skipinitialspace=True)
        return [{(k or "").strip(): (v or "").strip() for k, v in row.items()} for row in r]


def fl(v):
    try:
        if v == "?" or v == "":
            return None
        return float(v)
    except ValueError:
        return None


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def norm(v, ms):
    z = (v - ms[0]) / (ms[1] + 1e-32)
    z = max(-3.0, min(3.0, z))
    return 1 / (1 + math.exp(-1.702 * z))


def main():
    a = sys.argv
    tr = load(a[a.index("--train") + 1])
    te = load(a[a.index("--test") + 1])
    gs = {g: stats([fl(r.get(g)) for r in tr]) for g, _ in G}
    ns = {c: stats([fl(r.get(c)) for r in tr]) for c in NUM}

    def gaps(r):
        return {g: abs(norm(fl(r[g]), gs[g]) - h) for g, h in G}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    td = [d2h(r) for r in tr]
    cutoff = sorted(td)[len(tr) // 2]
    order = sorted(range(len(tr)), key=lambda i: (round(td[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    cent = {}
    for c in NUM:
        for nm, grp in (("g", good), ("p", poor)):
            vs = [fl(r.get(c)) for r in grp]
            vs = [v for v in vs if v is not None]
            cent[(c, nm)] = norm(sum(vs) / len(vs), ns[c]) if vs else None

    def freq(grp, cat):
        k = [r.get(CAT, "") for r in grp if r.get(CAT, "") not in ("?", "")]
        return sum(1 for x in k if x == cat) / len(k) if k else 0.0

    def diag(r):
        goals = gaps(r)
        feats = {}
        for c in NUM:
            x = fl(r.get(c))
            gc, pc = cent[(c, "g")], cent[(c, "p")]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = norm(x, ns[c])
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cv = r.get(CAT, "")
        if cv in ("?", ""):
            feats[CAT] = 0.0
        else:
            feats[CAT] = max(0.0, freq(poor, cv) - freq(good, cv))
        srt = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        return goals, feats, srt(goals), srt(feats)

    n = len(te)
    sc = [d2h(r) for r in te]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            lg, wg = gaps(te[lose]), gaps(te[win])
            d = {g: lg[g] ** 2 - wg[g] ** 2 for g, _ in G}
            adv = sorted(d, key=lambda g: (-round(d[g], 10), g))[0]
        goals, feats, go, fo = diag(te[j])
        weak = go[0]
        top = fo[0] if feats[fo[0]] > 1e-10 else None
        t = "Car %d %s: score %.3f, other score %.3f, cutoff %.3f; weakest goal %s." % (
            j, "accepted" if acc else "rejected", s, o, cutoff, weak)
        if win is not None:
            t += " Recommend car %d, advantage goal %s." % (win, adv)
        else:
            t += " Scores tie."
        if top is not None:
            t += " Top feature %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o, "cutoff": cutoff,
                    "accepted": acc, "winner": win, "advantage_goal": adv,
                    "weakest_goal": weak, "top_feature": top, "text": t})
    print(json.dumps({"explanations": out}))


if __name__ == "__main__":
    main()
