import sys, csv, json, math

def num(s):
    try:
        return float(s)
    except Exception:
        return None

def read(path):
    with open(path, newline='') as f:
        r = csv.DictReader(f)
        return [{(k or '').strip(): (v or '').strip() for k, v in row.items()} for row in r]

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        if abs(M[c][c]) < 1e-12:
            continue
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                if f:
                    M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]

def mean(x): return sum(x) / len(x)
def sd(x):
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1)) if len(x) > 1 else 0.0

def certify(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cl = abs(s) / (n * m)
    ks = 0.0
    for v in set(xs) | set(ys):
        d = abs(sum(a <= v for a in xs) / n - sum(b <= v for b in ys) / m)
        ks = max(ks, d)
    ks /= math.sqrt(1 / n + 1 / m)
    return cohen, cl, ks, (cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)

GOALS = ['Lbs-', 'Acc+', 'Mpg+']
HEAVEN = [0, 1, 1]

def main():
    a = sys.argv[1:]
    train = read(a[a.index('--train') + 1])
    test = read(a[a.index('--test') + 1])
    tr = []
    for r in train:
        g = [num(r.get(k, '?')) for k in GOALS]
        c, v, m = num(r.get('Clndrs')), num(r.get('Volume')), num(r.get('Model'))
        if None in g or None in (c, v, m):
            continue
        tr.append((c, v, m, r.get('origin', '?'), g))
    origins = sorted({t[3] for t in tr})
    gm = [mean([t[4][j] for t in tr]) for j in range(3)]
    gs = [sd([t[4][j] for t in tr]) for j in range(3)]

    def norm(v, j):
        z = max(-3, min(3, (v - gm[j]) / (gs[j] + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(g):
        return math.sqrt(sum((norm(g[j], j) - HEAVEN[j]) ** 2 for j in range(3)) / 3)

    hist = [d2h(t[4]) for t in tr]

    def feats(c, v, m, o, usev):
        f = [c, m] + ([v] if usev else [])
        return f + [1.0 if o == k else 0.0 for k in origins]

    models = {}
    for usev in (True, False):
        X = [feats(t[0], t[1], t[2], t[3], usev) for t in tr]
        p = len(X[0])
        mu = [mean([x[i] for x in X]) for i in range(p)]
        sg = [(sd([x[i] for x in X]) or 1.0) for i in range(p)]
        Z = [[1.0] + [(x[i] - mu[i]) / sg[i] for i in range(p)] for x in X]
        q = p + 1
        A = [[sum(z[i] * z[j] for z in Z) for j in range(q)] for i in range(q)]
        for i in range(1, q):
            A[i][i] += 1.0
        ws = []
        for j in range(3):
            b = [sum(z[i] * t[4][j] for z, t in zip(Z, tr)) for i in range(q)]
            ws.append(solve(A, b))
        models[usev] = (mu, sg, ws)

    mpg, scores = [], []
    for r in test:
        c, v, m = num(r.get('Clndrs')), num(r.get('Volume')), num(r.get('Model'))
        c = mean([t[0] for t in tr]) if c is None else c
        m = mean([t[2] for t in tr]) if m is None else m
        usev = v is not None
        mu, sg, ws = models[usev]
        f = feats(c, v, m, r.get('origin', '?'), usev)
        z = [1.0] + [(f[i] - mu[i]) / sg[i] for i in range(len(f))]
        g = [sum(w * x for w, x in zip(ws[j], z)) for j in range(3)]
        g[2] = max(g[2], 1.0)
        mpg.append(g[2])
        scores.append(min(1.0, max(0.0, d2h(g))))

    alerts = []
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, scores[i - 19:i + 1])[3])
    print(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))

main()
