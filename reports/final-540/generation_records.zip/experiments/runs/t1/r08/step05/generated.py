import sys, csv, json, math

def read(p):
    with open(p, newline='') as f:
        r = [[c.strip() for c in row] for row in csv.reader(f) if row]
    return r[0], r[1:]

def num(s):
    if s == '?' or s == '':
        return None
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except ValueError:
        return None

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, trr = read(tr)
    h2, ter = read(te)
    ix = {n: i for i, n in enumerate(h)}
    ix2 = {n: i for i, n in enumerate(h2)}
    goals = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    nums = ['Clndrs', 'Volume', 'Model']
    cat = 'origin'
    feats = nums + [cat]

    def getg(row, ixm):
        return {g: num(row[ixm[g]]) for g in goals}
    trr = [r for r in trr if all(v is not None for v in getg(r, ix).values())]

    def stats(vals):
        n = len(vals)
        if n == 0:
            return 0.0, 0.0
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return m, sd
    def mk(m, sd):
        def f(v):
            z = max(-3, min(3, (v - m) / (sd + 1e-32)))
            return 1 / (1 + math.exp(-1.702 * z))
        return f
    gn = {g: mk(*stats([num(r[ix[g]]) for r in trr])) for g in goals}
    fn = {c: mk(*stats([v for v in (num(r[ix[c]]) for r in trr) if v is not None])) for c in nums}

    def d2h(r, ixm):
        gv = getg(r, ixm)
        return math.sqrt(sum((gn[g](gv[g]) - goals[g]) ** 2 for g in goals) / 3)
    order = sorted(range(len(trr)), key=lambda i: (round(d2h(trr[i], ix), 12), i))
    q = max(1, len(trr) // 4)
    good = [trr[i] for i in order[:q]]
    poor = [trr[i] for i in order[-q:]]

    centers = {}
    for c in nums:
        cs = []
        for grp in (good, poor):
            v = [x for x in (num(r[ix[c]]) for r in grp) if x is not None]
            cs.append(fn[c](sum(v) / len(v)) if v else None)
        centers[c] = cs
    def freq(grp):
        v = [r[ix[cat]] for r in grp if r[ix[cat]] not in ('?', '')]
        d = {}
        for x in v:
            d[x] = d.get(x, 0) + 1
        return d, len(v)
    gf, gc = freq(good)
    pf, pc = freq(poor)

    out = []
    for r in ter:
        gv = getg(r, ix2)
        gs = {g: (abs(gn[g](gv[g]) - goals[g]) if gv[g] is not None else 0.0) for g in goals}
        fs = {}
        for c in nums:
            x = num(r[ix2[c]])
            gcn, pcn = centers[c]
            if x is None or gcn is None or pcn is None:
                fs[c] = 0.0
            else:
                z = fn[c](x)
                fs[c] = max(0.0, abs(z - gcn) - abs(z - pcn))
        x = r[ix2[cat]]
        if x in ('?', ''):
            fs[cat] = 0.0
        else:
            pfr = pf.get(x, 0) / pc if pc else 0.0
            gfr = gf.get(x, 0) / gc if gc else 0.0
            fs[cat] = max(0.0, pfr - gfr)
        key = lambda d: sorted(d, key=lambda n: (-round(d[n], 10), n))
        out.append({"goals": gs, "features": fs,
                    "goal_order": key(gs), "feature_order": key(fs)})
    print(json.dumps({"diagnoses": out}))

main()
