import sys, csv, json, math

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def read(path):
    with open(path, newline='') as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return {n: i for i, n in enumerate(h)}, [[c.strip() for c in row] for row in r[1:] if row]

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda i: abs(M[i][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for i in range(c + 1, n):
            f = M[i][c] / d
            if f:
                for j in range(c, n + 1):
                    M[i][j] -= f * M[c][j]
    x = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = M[i][n] - sum(M[i][j] * x[j] for j in range(i + 1, n))
        x[i] = s / (M[i][i] or 1e-12)
    return x

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    hi, R = read(tr)
    hj, T = read(te)

    def get(row, h, n):
        i = h.get(n)
        return num(row[i]) if i is not None and i < len(row) else None

    def org(row, h):
        i = h.get('origin')
        return row[i] if i is not None and i < len(row) else '?'

    origins = sorted({org(r, hi) for r in R if org(r, hi) != '?'})
    cm = {}
    for n in ('Clndrs', 'Volume', 'Model'):
        v = [get(r, hi, n) for r in R]
        v = [x for x in v if x is not None]
        cm[n] = sum(v) / len(v) if v else 0.0

    def feats(row, h, vol):
        c = get(row, h, 'Clndrs'); m = get(row, h, 'Model'); v = get(row, h, 'Volume')
        c = cm['Clndrs'] if c is None else c
        m = cm['Model'] if m is None else m
        v = cm['Volume'] if v is None else v
        f = [c, m]
        if vol:
            f += [v, math.log(max(v, 1.0))]
        o = org(row, h)
        f += [1.0 if o == k else 0.0 for k in origins]
        return f

    goals = ['Lbs', 'Acc', 'Mpg']
    gn = {'Lbs': 'Lbs-', 'Acc': 'Acc+', 'Mpg': 'Mpg+'}
    rows = []
    for r in R:
        g = [get(r, hi, gn[k]) for k in goals]
        if all(x is not None for x in g):
            rows.append((r, g))
    stats = []
    for k in range(3):
        v = [g[k] for _, g in rows]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        stats.append((m, sd))

    def d2h(g):
        s = 0
        for k in range(3):
            z = max(-3, min(3, (g[k] - stats[k][0]) / (stats[k][1] + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - (0 if k == 0 else 1)) ** 2
        return math.sqrt(s / 3)

    ymp = [math.log(max(g[2], 1e-3)) for _, g in rows]
    yd = [d2h(g) for _, g in rows]

    def fit(vol, ys, lam=1.0):
        X = [feats(r, hi, vol) for r, _ in rows]
        p = len(X[0])
        mu = [sum(x[j] for x in X) / len(X) for j in range(p)]
        sd = [math.sqrt(sum((x[j] - mu[j]) ** 2 for x in X) / len(X)) or 1.0 for j in range(p)]
        Z = [[(x[j] - mu[j]) / sd[j] for j in range(p)] for x in X]
        ym = sum(ys) / len(ys)
        A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0) for j in range(p)] for i in range(p)]
        b = [sum(z[i] * (y - ym) for z, y in zip(Z, ys)) for i in range(p)]
        w = solve(A, b)
        def pred(f):
            return ym + sum(w[j] * (f[j] - mu[j]) / sd[j] for j in range(p))
        return pred

    models = {}
    for vol in (True, False):
        models[vol] = (fit(vol, ymp), fit(vol, yd))

    mpg, sc = [], []
    for r in T:
        vol = get(r, hj, 'Volume') is not None
        f = feats(r, hj, vol)
        pm, pd = models[vol]
        mpg.append(max(math.exp(max(-2.0, min(5.0, pm(f)))), 1.0))
        sc.append(max(0.0, min(1.0, pd(f))))
    print(json.dumps({"mpg": mpg, "scores": sc}))

main()
