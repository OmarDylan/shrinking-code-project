import csv, sys, json, math, argparse
from statistics import median

def load(p):
    with open(p, newline='') as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v or '').strip() for k, v in row.items() if k} for row in r]

def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

def rscale(xs):
    m = median(xs)
    s = 1.4826 * median([abs(x - m) for x in xs])
    if s < 1e-9:
        mu = sum(xs) / len(xs)
        s = math.sqrt(sum((x - mu) ** 2 for x in xs) / max(1, len(xs) - 1))
    return m, (s if s > 1e-9 else 1.0)

NUM = ["Clndrs", "Volume", "Model"]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    tr, te = load(a.train), load(a.test)

    glob = {}
    for c in NUM:
        xs = [x for x in (num(r.get(c)) for r in tr) if x is not None]
        glob[c] = rscale(xs) if xs else (0.0, 1.0)
    # Volume conditional on Clndrs
    groups = {}
    for r in tr:
        c, v = num(r.get("Clndrs")), num(r.get("Volume"))
        if c is not None and v is not None:
            groups.setdefault(c, []).append(v)
    gstat = {}
    for c, vs in groups.items():
        if len(vs) >= 8:
            m, s = rscale(vs)
            gstat[c] = (m, max(s, 0.25 * glob["Volume"][1]))
    cats = {}
    n_o = 0
    for r in tr:
        o = r.get("origin", "?")
        if o and o != "?":
            cats[o] = cats.get(o, 0) + 1
            n_o += 1

    def raw(r):
        best = 0.0
        for c in NUM:
            x = num(r.get(c))
            if x is None:
                continue
            m, s = glob[c]
            best = max(best, abs(x - m) / s)
        cl, v = num(r.get("Clndrs")), num(r.get("Volume"))
        if v is not None and cl is not None and cl in gstat:
            m, s = gstat[cl]
            best = max(best, abs(v - m) / s)
        elif v is not None and cl is not None and gstat:
            # unseen cylinder count: compare to nearest group
            k = min(gstat, key=lambda g: abs(g - cl))
            m, s = gstat[k]
            best = max(best, abs(v - m) / s * 0.5)
        o = r.get("origin", "?")
        if o and o != "?" and n_o:
            f = cats.get(o, 0) / n_o
            if f == 0:
                best = max(best, 6.0)
            elif f < 0.02:
                best = max(best, 3.0)
        return best

    sc = lambda r: (lambda x: x / (x + 3.0))(raw(r))
    ts = sorted(sc(r) for r in tr)
    if ts:
        thr = ts[min(len(ts) - 1, int(0.97 * len(ts)))]
    else:
        thr = 0.5
    thr = min(1.0, max(0.0, thr))
    scores = [sc(r) for r in te]
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

main()
