import sys, json, csv, math

def mean(a): return sum(a) / len(a)
def sd(a):
    m = mean(a)
    return math.sqrt(sum((x - m) ** 2 for x in a) / (len(a) - 1))
def norm_fn(vals):
    m, s = mean(vals), sd(vals)
    return lambda v: 1 / (1 + math.exp(-1.702 * max(-3, min(3, (v - m) / (s + 1e-32)))))

def certify(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
    ks = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
             for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cl, "ks": ks,
            "same": cohen <= 0.35 and cl <= 0.197 and ks <= 1.36}

def main():
    a = sys.argv
    train_p = a[a.index("--train") + 1]
    test_p = a[a.index("--test") + 1]
    with open(train_p, newline="") as f:
        r = list(csv.reader(f))
    h, rows = r[0], r[1:]
    ix = {c: i for i, c in enumerate(h)}
    goals = ["Lbs-", "Acc+", "Mpg+"]
    heaven = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    gn = {g: norm_fn([float(x[ix[g]]) for x in rows]) for g in goals}

    def d2h(gv):
        return math.sqrt(sum((gn[g](gv[g]) - heaven[g]) ** 2 for g in goals) / 3)

    td = [d2h({g: float(x[ix[g]]) for g in goals}) for x in rows]
    target = sorted(td)[len(rows) // 4]
    nums = ["Clndrs", "Volume", "Model"]
    fn = {c: norm_fn([float(x[ix[c]]) for x in rows]) for c in nums}

    def feat(get):
        out = []
        for c in nums:
            v = get(c)
            out.append(None if v == "?" else fn[c](float(v)))
        o = get("origin")
        out.append(None if o == "?" else o)
        return out
    tf = [feat(lambda c, x=x: x[ix[c]]) for x in rows]

    def dist(p, q):
        s = 0
        for u, v in zip(p, q):
            if u is None or v is None: continue
            s += ((u - v) ** 2) if not isinstance(u, str) else (u != v)
        return math.sqrt(s / 4)

    def predict(p):
        ds = sorted((round(dist(p, q), 12), i) for i, q in enumerate(tf))[:5]
        return mean([td[i] for _, i in ds])

    data = json.load(open(test_p))
    H, R = data["header"], data["rows"]
    hx = {c: i for i, c in enumerate(H)}
    cache = {}
    def tfeat(i):
        if i not in cache:
            cache[i] = feat(lambda c: R[i][hx[c]])
        return cache[i]
    pred = {}
    def tpred(i):
        if i not in pred: pred[i] = predict(tfeat(i))
        return pred[i]

    def inspect(e, strat, i):
        print(json.dumps({"episode": e, "strategy": strat, "inspect": i}), flush=True)
        resp = json.loads(sys.stdin.readline())
        return d2h(resp["goals"])

    def summarize(obs):
        lt = 11
        for k, v in enumerate(obs):
            if round(v, 12) <= round(target, 12):
                lt = k + 1
                break
        return {"best5": min(obs[:5]), "best10": min(obs), "labels_to_target": lt}

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = list(ep["pool"])
        seen, obs = [], []
        for _ in range(10):
            best = None
            for i in pool:
                if i in seen: continue
                corr = 0; ws = 1.0
                for j, o in zip(seen, obs):
                    w = math.exp(-dist(tfeat(i), tfeat(j)) ** 2 / 0.05)
                    corr += w * (o - tpred(j)); ws += w
                sc = tpred(i) + corr / ws
                if best is None or (sc, i) < best: best = (sc, i)
            seen.append(best[1])
            obs.append(inspect(e, "adaptive", best[1]))
        ad = summarize(obs)
        ro = [inspect(e, "random", i) for i in ep["random_order"][:10]]
        results.append({"episode": e, "adaptive": ad, "random": summarize(ro)})
    comp = {}
    for m in ["best5", "best10", "labels_to_target"]:
        comp[m] = certify([x["adaptive"][m] for x in results], [x["random"][m] for x in results])
    print(json.dumps({"results": results, "comparisons": comp}), flush=True)

if __name__ == "__main__":
    main()
