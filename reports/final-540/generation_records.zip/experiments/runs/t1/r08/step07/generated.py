import csv, sys, math, json, argparse

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]


def fnum(s):
    s = (s or "").strip()
    if s == "?" or s == "":
        return None
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except ValueError:
        return None


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def stats(vals):
    n = len(vals)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def norm(v, m, sd):
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    tr = read(a.train)
    te = read(a.test)

    gs = {}
    for g in GOALS:
        vals = [fnum(r.get(g)) for r in tr]
        gs[g] = stats([v for v in vals if v is not None])

    def d2h(goals):
        s = 0.0
        for g in GOALS:
            s += (norm(goals[g], *gs[g]) - HEAVEN[g]) ** 2
        return math.sqrt(s / 3)

    ys = []
    for r in tr:
        try:
            ys.append(d2h({g: fnum(r.get(g)) for g in GOALS}))
        except TypeError:
            ys.append(None)

    fs = {}
    for c in NUM:
        vals = [fnum(r.get(c)) for r in tr]
        fs[c] = stats([v for v in vals if v is not None])

    def vec(r):
        v = []
        for c in NUM:
            x = fnum(r.get(c))
            m, sd = fs[c]
            v.append(None if x is None else (x - m) / (sd + 1e-32))
        o = (r.get("origin") or "").strip()
        v.append(None if o in ("", "?") else o)
        return v

    trv = [(vec(r), y) for r, y in zip(tr, ys) if y is not None]
    gm = sum(y for _, y in trv) / len(trv) if trv else 0.5

    def dist(p, q):
        s = 0.0
        n = 0
        for i in range(3):
            if p[i] is not None and q[i] is not None:
                s += (p[i] - q[i]) ** 2
                n += 1
        if p[3] is not None and q[3] is not None:
            s += 0.0 if p[3] == q[3] else 1.0
            n += 1
        return s / n if n else 1e9

    def predict(r):
        v = vec(r)
        ds = sorted((dist(v, t), y) for t, y in trv)[:5]
        if not ds:
            return gm
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w)

    n = len(te)
    pred = [predict(r) for r in te]
    order = sorted(range(n), key=lambda i: (pred[i], i))
    picks = order[:min(10, n)]

    obs = {}
    for i in picks:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        if not line:
            break
        resp = json.loads(line)
        obs[i] = d2h(resp["goals"])
    ranked = sorted(obs, key=lambda i: (round(obs[i], 12), i))[:3]
    print(json.dumps({"selected": ranked}), flush=True)


main()
