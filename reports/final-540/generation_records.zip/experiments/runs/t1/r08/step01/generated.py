import sys, csv, json, math

def load(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows

def goals(header, rows):
    idx = [header.index(n) for n in ("Lbs-", "Acc+", "Mpg+")]
    out = []
    for row in rows:
        try:
            out.append([float(row[i]) for i in idx])
        except (ValueError, IndexError):
            out.append(None)
    return out

def remember(train, test):
    h1, r1 = load(train)
    h2, r2 = load(test)
    tr = [g for g in goals(h1, r1) if g is not None]
    te = goals(h2, r2)
    n = len(tr)
    stats = []
    for j in range(3):
        col = [g[j] for g in tr]
        m = sum(col) / n if n else 0.0
        sd = math.sqrt(sum((v - m) ** 2 for v in col) / (n - 1)) if n > 1 else 0.0
        stats.append((m, sd))
    heaven = (0.0, 1.0, 1.0)
    scores = []
    for g in te:
        s = 0.0
        for j in range(3):
            m, sd = stats[j]
            z = max(-3.0, min(3.0, (g[j] - m) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - heaven[j]) ** 2
        scores.append(math.sqrt(s / 3))
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(scores) // 2],
        "worst": order[-1],
    }

def main():
    a = sys.argv[1:]
    if not a or a[0] != "remember":
        sys.exit(1)
    train = test = None
    for i, x in enumerate(a):
        if x == "--train":
            train = a[i + 1]
        elif x == "--test":
            test = a[i + 1]
    print(json.dumps(remember(train, test)))

if __name__ == "__main__":
    main()
