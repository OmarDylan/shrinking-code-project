import csv, sys, json, math

def rd(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [[c.strip() for c in row] for row in r[1:] if row]

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for j in range(i, n + 1):
            M[i][j] /= d
        for r in range(n):
            if r != i and M[r][i]:
                f = M[r][i]
                for j in range(i, n + 1):
                    M[r][j] -= f * M[i][j]
    return [M[i][n] for i in range(n)]

def ridge(X, y, lam=1.0):
    n, k = len(X), len(X[0])
    mu = [sum(r[j] for r in X) / n for j in range(k)]
    sd = [math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / n) or 1.0 for j in range(k)]
    Z = [[1.0] + [(r[j] - mu[j]) / sd[j] for j in range(k)] for r in X]
    m = k + 1
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j and i > 0 else 0) for j in range(m)] for i in range(m)]
    b = [sum(z[i] * t for z, t in zip(Z, y)) for i in range(m)]
    w = solve(A, b)
    def pred(x):
        return w[0] + sum(w[j + 1] * (x[j] - mu[j]) / sd[j] for j in range(k))
    return pred

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, R = rd(tr)
    th, T = rd(te)
    ix = {n: i for i, n in enumerate(h)}
    tx = {n: i for i, n in enumerate(th)}
    def get(row, idx, name):
        i = idx.get(name)
        if i is None or i >= len(row):
            return None
        return row[i]
    origins = sorted({get(r, ix, 'origin') for r in R} - {None, '?'})
    cm = {}
    for nm in ('Clndrs', 'Model', 'Volume'):
        v = [num(get(r, ix, nm)) for r in R]
        v = [x for x in v if x is not None]
        cm[nm] = sum(v) / len(v) if v else 0.0
    def feat(row, idx, usevol):
        c = num(get(row, idx, 'Clndrs'))
        c = cm['Clndrs'] if c is None else c
        m = num(get(row, idx, 'Model'))
        m = cm['Model'] if m is None else m
        o = get(row, idx, 'origin')
        f = [c, m] + [1.0 if o == g else 0.0 for g in origins]
        if usevol:
            v = num(get(row, idx, 'Volume'))
            v = cm['Volume'] if v is None else v
            f += [v, math.log(max(v, 1.0))]
        return f
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    G = [[num(get(r, ix, g)) for g in goals] for r in R]
    ok = [i for i, g in enumerate(G) if None not in g]
    st = []
    for j in range(3):
        v = [G[i][j] for i in ok]
        mean = sum(v) / len(v)
        sd = math.sqrt(sum((x - mean) ** 2 for x in v) / max(len(v) - 1, 1))
        st.append((mean, sd))
    def d2h(g):
        s = 0.0
        for j in range(3):
            z = max(-3, min(3, (g[j] - st[j][0]) / (st[j][1] + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - (0 if j == 0 else 1)) ** 2
        return math.sqrt(s / 3)
    D = {i: d2h(G[i]) for i in ok}
    mi = [i for i in ok]
    models = {}
    for uv in (True, False):
        X = [feat(R[i], ix, uv) for i in mi]
        ym = [math.log(max(G[i][2], 1e-6)) for i in mi]
        yd = [D[i] for i in mi]
        models[uv] = (ridge(X, ym), ridge(X, yd))
    mpg, sc = [], []
    dm = sum(D.values()) / len(D)
    mm = sum(G[i][2] for i in ok) / len(ok)
    for row in T:
        uv = num(get(row, tx, 'Volume')) is not None
        f = feat(row, tx, uv)
        p, q = models[uv]
        try:
            mv = math.exp(p(f))
            if not math.isfinite(mv) or mv <= 0:
                mv = mm
        except Exception:
            mv = mm
        dv = q(f)
        if not math.isfinite(dv):
            dv = dm
        mpg.append(mv)
        sc.append(min(1.0, max(0.0, dv)))
    print(json.dumps({"mpg": mpg, "scores": sc}))

main()
