import sys, json, csv, math

def main():
    a = sys.argv
    train = a[a.index('--train') + 1]
    test = a[a.index('--test') + 1]
    with open(train, newline='') as f:
        r = list(csv.reader(f))
    H = [h.strip() for h in r[0]]
    T = r[1:]
    G = ['Lbs-', 'Acc+', 'Mpg+']
    HV = {'Lbs-': 0, 'Acc+': 1, 'Mpg+': 1}
    N = ['Clndrs', 'Volume', 'Model']
    ix = {h: i for i, h in enumerate(H)}

    def fl(v):
        try:
            return float(v)
        except Exception:
            return None

    st = {}
    for c in G + N:
        vs = [fl(t[ix[c]]) for t in T]
        vs = [v for v in vs if v is not None]
        m = sum(vs) / len(vs)
        sd = math.sqrt(sum((v - m) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 0
        st[c] = (m, sd)

    def nm(c, v):
        m, sd = st[c]
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    def d2h(g):
        return math.sqrt(sum((nm(c, g[c]) - HV[c]) ** 2 for c in G) / 3)

    def feat(get):
        out = []
        for c in N:
            v = fl(get(c))
            out.append(None if v is None else nm(c, v))
        o = get('origin')
        out.append(None if o is None or str(o).strip() == '?' else str(o).strip())
        return out

    tr = []
    for t in T:
        g = {c: float(t[ix[c]]) for c in G}
        tr.append((feat(lambda c: t[ix[c]]), d2h(g)))
    sc = sorted(s for _, s in tr)
    target = round(sc[len(tr) // 4], 12)

    def dist(x, y):
        s = 0.0
        n = 0
        for i in range(4):
            p, q = x[i], y[i]
            if p is None or q is None:
                continue
            n += 1
            s += (p - q) ** 2 if i < 3 else (0 if p == q else 1)
        return math.sqrt(s / n) if n else 1.0

    D = json.load(open(test))
    th = [h.strip() for h in D['header']]
    tix = {h: i for i, h in enumerate(th)}
    rows = D['rows']
    TF = [feat(lambda c, r=r: r[tix[c]]) for r in rows]

    def rd(line):
        return json.loads(line)

    def inspect(e, name, i):
        print(json.dumps({"episode": e, "strategy": name, "inspect": i}), flush=True)
        resp = rd(sys.stdin.readline())
        g = resp['goals']
        return d2h({c: float(g[c]) for c in G})

    def adaptive(e, pool):
        ref = list(tr)
        done = set()
        obs = []
        for _ in range(10):
            best = None
            for i in pool:
                if i in done:
                    continue
                ds = sorted((round(dist(TF[i], x), 12), k) for k, (x, _) in enumerate(ref))[:5]
                p = sum(ref[k][1] for _, k in ds) / len(ds)
                if best is None or (p, i) < best:
                    best = (p, i)
            i = best[1]
            done.add(i)
            s = inspect(e, 'adaptive', i)
            obs.append(s)
            ref.append((TF[i], s))
        return obs

    def random_(e, order):
        obs = []
        seen = []
        for i in order:
            if i not in seen:
                seen.append(i)
            if len(seen) == 10:
                break
        for i in seen:
            obs.append(inspect(e, 'random', i))
        return obs

    def metrics(o):
        lt = 11
        for k, v in enumerate(o):
            if round(v, 12) <= target:
                lt = k + 1
                break
        return {"best5": min(o[:5]), "best10": min(o), "labels_to_target": lt}

    res = []
    for e, ep in enumerate(D['episodes']):
        ao = adaptive(e, ep['pool'])
        ro = random_(e, ep['random_order'])
        res.append({"episode": e, "adaptive": metrics(ao), "random": metrics(ro)})

    def cert(xs, ys):
        n, m = len(xs), len(ys)
        mx, my = sum(xs) / n, sum(ys) / m
        vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
        vy = sum((y - my) ** 2 for y in ys) / (m - 1)
        pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
        co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
        cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
        ks = max(abs(sum(x <= v for x in xs) / n - sum(y <= v for y in ys) / m)
                 for v in set(xs) | set(ys)) / math.sqrt(1 / n + 1 / m)
        return {"cohen": co, "cliffs": cl, "ks": ks,
                "same": bool(co <= 0.35 and cl <= 0.197 and ks <= 1.36)}

    comp = {}
    for k in ("best5", "best10", "labels_to_target"):
        comp[k] = cert([float(r["adaptive"][k]) for r in res], [float(r["random"][k]) for r in res])
    print(json.dumps({"results": res, "comparisons": comp}), flush=True)

main()
