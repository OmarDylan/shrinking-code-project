import csv, sys, json, math, argparse

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMS = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    v = (v or "").strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def norm(v, st):
    m, sd = st
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1.0 / (1.0 + math.exp(-1.702 * z))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()
    train, test = read(a.train), read(a.test)

    gst = {g: stats([num(r[g]) for r in train]) for g in GOALS}
    nst = {c: stats([num(r[c]) for r in train]) for c in NUMS}

    def gaps(r):
        return {g: abs(norm(num(r[g]), gst[g]) - h) for g, h in GOALS.items()}

    def d2h(r):
        return math.sqrt(sum(x * x for x in gaps(r).values()) / 3)

    tr_d = [d2h(r) for r in train]
    order = sorted(range(len(train)), key=lambda i: (round(tr_d[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            vs = [num(r[c]) for r in grp]
            vs = [v for v in vs if v is not None]
            cs.append(norm(sum(vs) / len(vs), nst[c]) if vs else None)
        centers[c] = cs

    def freq(grp, cat):
        known = [r[CAT].strip() for r in grp if r[CAT].strip() not in ("?", "")]
        return known.count(cat) / len(known) if known else 0.0

    def diagnose(r):
        goals = gaps(r)
        feats = {}
        for c in NUMS:
            x = num(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = norm(x, nst[c])
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cat = r[CAT].strip()
        if cat in ("?", ""):
            feats[CAT] = 0.0
        else:
            feats[CAT] = max(0.0, freq(poor, cat) - freq(good, cat))
        go = sorted(goals, key=lambda n: (-round(goals[n], 10), n))
        fo = sorted(feats, key=lambda n: (-round(feats[n], 10), n))
        return goals, feats, go, fo

    cutoff = sorted(tr_d)[len(train) // 2]
    n = len(test)
    scores = [d2h(r) for r in test]
    gp = [gaps(r) for r in test]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: gp[loser][g] ** 2 - gp[winner][g] ** 2 for g in GOALS}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        _, feats, go, fo = diagnose(test[j])
        weakest = go[0]
        top = fo[0] if feats[fo[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f (car %d), cutoff %.3f; weakest goal %s." % (
            j, "accepted" if accepted else "rejected", s, o, k, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; largest advantage in %s." % (winner, adv_goal)
        else:
            text += " Scores tie."
        if top is not None:
            text += " Top feature: %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": accepted, "winner": winner,
                    "advantage_goal": adv_goal, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


main()
