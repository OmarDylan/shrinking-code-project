import sys, csv, json, math

def load(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [x for x in r if x]
    ix = {n: h.index(n) for n in ("Clndrs", "Volume", "Model", "origin")}
    out = []
    for row in rows:
        v = []
        for n in ("Clndrs", "Volume", "Model", "origin"):
            s = row[ix[n]].strip() if ix[n] < len(row) else "?"
            if s == "?" or s == "":
                v.append(None)
            elif n == "origin":
                v.append(s)
            else:
                try:
                    x = float(s)
                    v.append(x if math.isfinite(x) else None)
                except ValueError:
                    v.append(None)
        out.append(v)
    return out

def median(a):
    a = sorted(a)
    n = len(a)
    return 0.0 if n == 0 else (a[n // 2] if n % 2 else (a[n // 2 - 1] + a[n // 2]) / 2)

def quant(a, q):
    a = sorted(a)
    return a[min(len(a) - 1, int(q * len(a)))]

def main():
    args = sys.argv[1:]
    train = load(args[args.index("--train") + 1])
    test = load(args[args.index("--test") + 1])
    stats = []
    for j in range(3):
        col = [r[j] for r in train if r[j] is not None]
        m = median(col)
        s = 1.4826 * median([abs(x - m) for x in col]) if col else 0
        if s < 1e-9 and col:
            mu = sum(col) / len(col)
            s = math.sqrt(sum((x - mu) ** 2 for x in col) / max(1, len(col) - 1))
        if s < 1e-9:
            s = 1.0
        stats.append((m, s))

    def marg(r):
        z = [abs(r[j] - stats[j][0]) / stats[j][1] for j in range(3) if r[j] is not None]
        return max(z) if z else 0.0

    def dist(a, b):
        t = 0.0
        c = 0
        for j in range(3):
            if a[j] is not None and b[j] is not None:
                t += ((a[j] - b[j]) / stats[j][1]) ** 2
                c += 1
        if a[3] is not None and b[3] is not None:
            t += 0.0 if a[3] == b[3] else 1.0
            c += 1
        return math.sqrt(t / c) if c else 0.0

    K = 5

    def knn(r, skip=None):
        d = sorted(dist(r, t) for i, t in enumerate(train) if i != skip)
        d = d[:K]
        return sum(d) / len(d) if d else 0.0

    tk = [knn(r, i) for i, r in enumerate(train)]
    kref = max(quant(tk, 0.95), 1e-6)
    tm = [marg(r) for r in train]
    freq = {}
    for r in train:
        if r[3] is not None:
            freq[r[3]] = freq.get(r[3], 0) + 1

    def raw(r, k):
        s = max(marg(r) / 4.0, k / kref)
        if r[3] is not None and freq and r[3] not in freq:
            s = max(s, 1.5)
        return s

    def sc(s):
        return s / (s + 1.0)

    ts = [sc(raw(r, tk[i])) for i, r in enumerate(train)]
    thr = quant(ts, 0.97) if ts else 0.5
    thr = min(max(thr, 0.0), 1.0)
    scores = [min(1.0, max(0.0, sc(raw(r, knn(r))))) for r in test]
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

if __name__ == "__main__":
    main()
