import sys, csv, json, math, argparse

NUM = ["Clndrs", "Volume", "Model"]
GOALS = ["Lbs-", "Acc+", "Mpg+"]


def fnum(s):
    try:
        return float(s)
    except Exception:
        return None


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        d = M[c][c] or 1e-12
        for r in range(n):
            if r != c:
                f = M[r][c] / d
                if f:
                    for k in range(c, n + 1):
                        M[r][k] -= f * M[c][k]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]


def mean(x):
    return sum(x) / len(x)


def sd(x):
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1)) if len(x) > 1 else 0.0


def sign(x):
    return (x > 0) - (x < 0)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum(sign(x - y) for x in xs for y in ys)) / (n * m)
    ks = 0.0
    for v in set(xs) | set(ys):
        d = abs(sum(a <= v for a in xs) / n - sum(b <= v for b in ys) / m)
        ks = max(ks, d)
    ks /= math.sqrt(1 / n + 1 / m)
    return cohen, cl, ks, (cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    train = read(a.train)
    test = read(a.test)

    tg = [[fnum(r[g]) for r in train] for g in GOALS]
    stats = []
    for col in tg:
        c = [v for v in col if v is not None]
        stats.append((mean(c), sd(c)))

    def d2h(vals):
        s = 0.0
        for v, (m, sdv), h in zip(vals, stats, (0, 1, 1)):
            z = max(-3.0, min(3.0, (v - m) / (sdv + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        return math.sqrt(s / 3)

    hist = []
    for i in range(len(train)):
        if all(tg[k][i] is not None for k in range(3)):
            hist.append(d2h([tg[k][i] for k in range(3)]))

    origins = sorted({r["origin"] for r in train if r["origin"] != "?"})

    def feats(r, use):
        # use: tuple of numeric names, plus 'origin' flag
        v = []
        for nme in use:
            if nme == "origin":
                v.extend(1.0 if r["origin"] == o else 0.0 for o in origins)
            else:
                v.append(fnum(r[nme]))
        return v

    cache = {}

    def model(use):
        if use in cache:
            return cache[use]
        X, Y = [], [[], [], []]
        for i, r in enumerate(train):
            f = feats(r, use)
            if any(x is None for x in f) or any(tg[k][i] is None for k in range(3)):
                continue
            X.append(f)
            for k in range(3):
                Y[k].append(tg[k][i])
        p = len(use and X[0]) if X else 0
        mu = [mean([x[j] for x in X]) for j in range(p)] if X else []
        sg = [(sd([x[j] for x in X]) or 1.0) for j in range(p)] if X else []
        Z = [[1.0] + [(x[j] - mu[j]) / sg[j] for j in range(p)] for x in X]
        W = []
        for k in range(3):
            q = p + 1
            A = [[sum(z[i] * z[j] for z in Z) for j in range(q)] for i in range(q)]
            for i in range(1, q):
                A[i][i] += 1.0
            b = [sum(z[i] * y for z, y in zip(Z, Y[k])) for i in range(q)]
            W.append(solve(A, b))
        cache[use] = (mu, sg, W)
        return cache[use]

    mpgs, scores = [], []
    for r in test:
        use = tuple(n for n in NUM if fnum(r[n]) is not None)
        if r["origin"] != "?" and r["origin"] in origins:
            use += ("origin",)
        mu, sg, W = model(use)
        f = feats(r, use)
        z = [1.0] + [(f[j] - mu[j]) / sg[j] for j in range(len(f))]
        pr = [sum(w * x for w, x in zip(W[k], z)) for k in range(3)]
        pr[2] = max(pr[2], 1.0)
        mpgs.append(pr[2])
        scores.append(min(1.0, max(0.0, d2h(pr))))

    alerts = []
    for i in range(len(scores)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, scores[i - 19:i + 1])[3])
    print(json.dumps({"mpg": mpgs, "scores": scores, "alerts": alerts}))


main()
