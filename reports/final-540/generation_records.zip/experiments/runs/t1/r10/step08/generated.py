import sys, csv, json, math

def load(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [[c.strip() for c in row] for row in r[1:] if row]

def nrm(v, m, sd):
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))

def stats(vals):
    m = sum(vals) / len(vals)
    sd = math.sqrt(sum((x - m) ** 2 for x in vals) / (len(vals) - 1)) if len(vals) > 1 else 0.0
    return m, sd

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, T = load(tr)
    h2, S = load(te)
    ix = {n: i for i, n in enumerate(h)}
    ix2 = {n: i for i, n in enumerate(h2)}
    goals = [('Lbs-', 0), ('Acc+', 1), ('Mpg+', 1)]
    gs = {g: stats([float(r[ix[g]]) for r in T]) for g, _ in goals}
    d2h = []
    for r in T:
        s = 0
        for g, hv in goals:
            s += (nrm(float(r[ix[g]]), *gs[g]) - hv) ** 2
        d2h.append(math.sqrt(s / 3))
    nums = ['Clndrs', 'Volume', 'Model']
    ns = {c: stats([float(r[ix[c]]) for r in T]) for c in nums}

    def feat(vals):
        # vals: dict name -> raw value (float or None), origin string
        f = []
        for c in nums:
            v = vals[c]
            f.append(None if v is None else nrm(v, *ns[c]))
        f.append(vals['origin'])
        return f

    def parse(r, idx):
        d = {}
        for c in nums:
            s = r[idx[c]]
            d[c] = None if s == '?' else float(s)
        d['origin'] = r[idx['origin']]
        return d

    TF = [feat(parse(r, ix)) for r in T]

    def dist(x, y):
        s = 0
        for i in range(3):
            if x[i] is None or y[i] is None:
                s += 1 if x[i] is not y[i] else 0
            else:
                s += (x[i] - y[i]) ** 2
        s += 0 if x[3] == y[3] else 1
        return math.sqrt(s / 4)

    def pred(x):
        o = sorted(range(len(TF)), key=lambda i: (round(dist(x, TF[i]), 12), i))[:5]
        return sum(d2h[i] for i in o) / len(o)

    n = len(T)
    cutoff = sorted(d2h)[n // 2]
    rank = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = rank[:max(1, n // 4)]
    menu = []
    for i in good:
        p = (float(T[i][ix['Clndrs']]), float(T[i][ix['Volume']]))
        if p not in menu:
            menu.append(p)
        if len(menu) == 12:
            break

    out = []
    for k, r in enumerate(S):
        d = parse(r, ix2)
        x = feat(d)
        before = pred(x)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for c, v in menu:
            ch = {}
            if d['Clndrs'] != c:
                ch['Clndrs'] = c
            if d['Volume'] != v:
                ch['Volume'] = v
            if not ch:
                continue
            e = dict(d)
            e['Clndrs'] = c
            e['Volume'] = v
            y = feat(e)
            after = pred(y)
            if round(before - after, 10) >= 0.05:
                key = (len(ch), round(dist(x, y), 10), round(after, 10), (c, v))
                if best is None or key < best[0]:
                    best = (key, after, ch)
        if best is None:
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            out.append({"row": k, "before": before, "after": best[1], "changes": best[2], "status": "improved"})
    print(json.dumps({"repairs": out}))

if __name__ == '__main__':
    main()
