import sys, csv, json, math

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]

    def load(p):
        with open(p, newline='') as f:
            r = list(csv.reader(f))
        h = [x.strip() for x in r[0]]
        rows = [[c.strip() for c in x] for x in r[1:] if x]
        return h, rows

    h, R = load(tr)
    _, T = load(te)
    ix = {n: i for i, n in enumerate(h)}
    goals = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    nums = ['Clndrs', 'Volume', 'Model']
    cat = 'origin'

    def fl(v):
        if v == '?' or v == '':
            return None
        try:
            return float(v)
        except ValueError:
            return None

    def stats(vals):
        n = len(vals)
        if n == 0:
            return 0.0, 0.0
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return m, sd

    def mk(vals):
        m, sd = stats(vals)
        def f(v):
            z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
            return 1 / (1 + math.exp(-1.702 * z))
        return f

    gn = {}
    for g in goals:
        gn[g] = mk([fl(r[ix[g]]) for r in R if fl(r[ix[g]]) is not None])
    fn = {}
    for c in nums:
        fn[c] = mk([fl(r[ix[c]]) for r in R if fl(r[ix[c]]) is not None])

    def d2h(r):
        s = 0.0
        for g, hv in goals.items():
            s += (gn[g](fl(r[ix[g]])) - hv) ** 2
        return math.sqrt(s / 3)

    order = sorted(range(len(R)), key=lambda i: (round(d2h(R[i]), 12), i))
    q = max(1, len(R) // 4)
    good = [R[i] for i in order[:q]]
    poor = [R[i] for i in order[-q:]]

    centers = {}
    for c in nums:
        cc = []
        for grp in (good, poor):
            v = [fl(r[ix[c]]) for r in grp if fl(r[ix[c]]) is not None]
            cc.append(fn[c](sum(v) / len(v)) if v else None)
        centers[c] = cc

    def freqs(grp):
        v = [r[ix[cat]] for r in grp if r[ix[cat]] not in ('?', '')]
        d = {}
        for x in v:
            d[x] = d.get(x, 0) + 1
        return d, len(v)
    gf, gnn = freqs(good)
    pf, pnn = freqs(poor)

    out = []
    for r in T:
        goalsc = {}
        for g, hv in goals.items():
            goalsc[g] = abs(gn[g](fl(r[ix[g]])) - hv)
        fs = {}
        for c in nums:
            x = fl(r[ix[c]])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                fs[c] = 0.0
            else:
                nx = fn[c](x)
                fs[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        v = r[ix[cat]]
        if v in ('?', ''):
            fs[cat] = 0.0
        else:
            p = pf.get(v, 0) / pnn if pnn else 0.0
            g = gf.get(v, 0) / gnn if gnn else 0.0
            fs[cat] = max(0.0, p - g)
        key = lambda d: sorted(d, key=lambda n: (-round(d[n], 10), n))
        out.append({"goals": goalsc, "features": fs,
                    "goal_order": key(goalsc), "feature_order": key(fs)})
    print(json.dumps({"diagnoses": out}))

main()
