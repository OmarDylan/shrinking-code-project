import sys, json, math, argparse


def cohen(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    p = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    return abs(mx - my) / (math.sqrt(p) + 1e-32)


def cliffs(xs, ys):
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    return abs(s) / (len(xs) * len(ys))


def ks(xs, ys):
    n, m = len(xs), len(ys)
    sx, sy = sorted(xs), sorted(ys)
    i = j = 0
    d = 0.0
    for v in sorted(set(sx) | set(sy)):
        while i < n and sx[i] <= v:
            i += 1
        while j < m and sy[j] <= v:
            j += 1
        d = max(d, abs(i / n - j / m))
    return d / math.sqrt(1 / n + 1 / m)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    with open(a.test) as f:
        cases = json.load(f)
    out = []
    for c in cases:
        xs = [float(v) for v in c["xs"]]
        ys = [float(v) for v in c["ys"]]
        co, cl, k = cohen(xs, ys), cliffs(xs, ys), ks(xs, ys)
        out.append({"cohen": co, "cliffs": cl, "ks": k,
                    "same": bool(co <= 0.35 and cl <= 0.197 and k <= 1.36)})
    json.dump({"comparisons": out}, sys.stdout)


main()
