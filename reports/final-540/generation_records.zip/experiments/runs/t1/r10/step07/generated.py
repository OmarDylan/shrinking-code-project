import csv, sys, math, json

def load(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

G = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    train, test = load(tr), load(te)

    stats = {}
    for g in G:
        vs = [num(r.get(g)) for r in train]
        vs = [v for v in vs if v is not None]
        m = sum(vs) / len(vs)
        sd = math.sqrt(sum((v - m) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 0.0
        stats[g] = (m, sd)

    def d2h(goals):
        s = 0.0
        for g, h in G.items():
            m, sd = stats[g]
            z = max(-3, min(3, (goals[g] - m) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - h) ** 2
        return math.sqrt(s / 3)

    feats = ["Clndrs", "Volume", "Model"]
    fs = {}
    for c in feats:
        vs = [num(r.get(c)) for r in train]
        vs = [v for v in vs if v is not None]
        m = sum(vs) / len(vs) if vs else 0.0
        sd = math.sqrt(sum((v - m) ** 2 for v in vs) / (len(vs) - 1)) if len(vs) > 1 else 1.0
        fs[c] = (m, sd or 1.0)

    def vec(r):
        v = []
        for c in feats:
            x = num(r.get(c))
            v.append(None if x is None else (x - fs[c][0]) / fs[c][1])
        return v, r.get("origin", "?")

    def dist(p, q):
        d = 0.0
        for x, y in zip(p[0], q[0]):
            if x is not None and y is not None:
                d += (x - y) ** 2
        if p[1] != q[1] and p[1] != "?" and q[1] != "?":
            d += 1.0
        return d

    tv, ty = [], []
    for r in train:
        gs = {g: num(r.get(g)) for g in G}
        if any(v is None for v in gs.values()):
            continue
        tv.append(vec(r))
        ty.append(d2h(gs))

    def pred(p):
        ds = sorted((dist(p, q), y) for q, y in zip(tv, ty))[:5]
        w = [1 / (d + 0.05) for d, _ in ds]
        return sum(wi * y for wi, (_, y) in zip(w, ds)) / sum(w)

    n = len(test)
    tvec = [vec(r) for r in test]
    pr = [pred(p) for p in tvec] if tv else [0.0] * n
    order = sorted(range(n), key=lambda i: (pr[i], i))
    budget = min(10, n)
    chosen = order[:min(6, budget)]
    pool = order[:max(budget, n // 4)]
    while len(chosen) < budget:
        best, bd = None, -1
        for i in pool:
            if i in chosen:
                continue
            d = min(dist(tvec[i], tvec[j]) for j in chosen)
            if d > bd:
                best, bd = i, d
        if best is None:
            best = next(i for i in order if i not in chosen)
        chosen.append(best)

    obs = []
    for i in chosen:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        resp = json.loads(line)
        obs.append((round(d2h(resp["goals"]), 12), i))
    obs.sort()
    print(json.dumps({"selected": [i for _, i in obs[:3]]}), flush=True)

main()
