import csv, sys, json, math

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUMS = ["Clndrs", "Volume", "Model"]
CAT = "origin"


def read(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    try:
        v = (v or "").strip()
        if v == "?" or v == "":
            return None
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1))


def mk_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))
    return f


def main():
    a = sys.argv
    tr = read(a[a.index("--train") + 1])
    te = read(a[a.index("--test") + 1])
    cols = GOALS + NUMS
    nf = {}
    for c in cols:
        vs = [x for x in (num(r.get(c)) for r in tr) if x is not None]
        nf[c] = mk_norm(*stats(vs))

    def gaps(r):
        return {g: abs(nf[g](num(r[g])) - HEAVEN[g]) for g in GOALS}

    def d2h(r):
        return math.sqrt(sum(v * v for v in gaps(r).values()) / 3)

    tsc = [d2h(r) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(tsc[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]
    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            vs = [x for x in (num(r.get(c)) for r in grp) if x is not None]
            cs.append(nf[c](sum(vs) / len(vs)) if vs else None)
        centers[c] = cs

    def freq(grp):
        vals = [(r.get(CAT) or "").strip() for r in grp]
        vals = [v for v in vals if v != "?" and v != ""]
        d = {}
        for v in vals:
            d[v] = d.get(v, 0) + 1
        n = len(vals)
        return {k: c / n for k, c in d.items()} if n else {}

    gf, pf = freq(good), freq(poor)

    def blame(r):
        gp = gaps(r)
        feats = {}
        for c in NUMS:
            x = num(r.get(c))
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = nf[c](x)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        v = (r.get(CAT) or "").strip()
        if v == "?" or v == "":
            feats[CAT] = 0.0
        else:
            feats[CAT] = max(0.0, pf.get(v, 0.0) - gf.get(v, 0.0))
        go = sorted(gp, key=lambda k: (-round(gp[k], 10), k))
        fo = sorted(feats, key=lambda k: (-round(feats[k], 10), k))
        return gp, feats, go, fo

    cutoff = sorted(tsc)[len(tsc) // 2]
    n = len(te)
    sc = [d2h(r) for r in te]
    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = sc[j], sc[k]
        acc = round(s, 12) <= round(cutoff, 12)
        win = None
        if round(s, 12) != round(o, 12):
            win = j if s < o else k
        adv = None
        if win is not None:
            lose = k if win == j else j
            gw, gl = gaps(te[win]), gaps(te[lose])
            d = {g: gl[g] ** 2 - gw[g] ** 2 for g in GOALS}
            adv = sorted(GOALS, key=lambda g: (-round(d[g], 10), g))[0]
        _, feats, go, fo = blame(te[j])
        weak = go[0]
        top = fo[0] if feats[fo[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f, cutoff %.3f; weakest goal %s." % (
            j, "accepted" if acc else "rejected", s, o, cutoff, weak)
        if win is not None:
            text += " Recommend car %d, largest advantage in %s." % (win, adv)
        else:
            text += " The comparison is a tie."
        if top is not None:
            text += " Top feature: %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": acc, "winner": win,
                    "advantage_goal": adv, "weakest_goal": weak,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


if __name__ == "__main__":
    main()
