import csv, sys, json, math

def load(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    return r[0], r[1:]

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, T = load(tr)
    _, S = load(te)
    ix = {n: i for i, n in enumerate(h)}

    def stats(vals):
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return m, sd

    def nm(v, ms):
        m, sd = ms
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))

    goals = [('Lbs-', 0), ('Acc+', 1), ('Mpg+', 1)]
    gs = {g: stats([float(r[ix[g]]) for r in T]) for g in [g for g, _ in goals]}
    d2h = []
    for r in T:
        s = sum((nm(float(r[ix[g]]), gs[g]) - hv) ** 2 for g, hv in goals)
        d2h.append(math.sqrt(s / 3))
    nums = ['Clndrs', 'Volume', 'Model']
    ns = {c: stats([float(r[ix[c]]) for r in T]) for c in nums}

    def feat(c, v, o):
        return [nm(c, ns['Clndrs']), nm(v, ns['Volume']), nm(o, ns['Model'])]

    def mk(r):
        return (feat(float(r[ix['Clndrs']]), float(r[ix['Volume']]), float(r[ix['Model']])), r[ix['origin']])

    TF = [mk(r) for r in T]

    def dist(a, b):
        s = sum((x - y) ** 2 for x, y in zip(a[0], b[0]))
        s += 0 if a[1] == b[1] else 1
        return math.sqrt(s / 4)

    def pred(f):
        ds = sorted(range(len(TF)), key=lambda i: (round(dist(f, TF[i]), 12), i))[:5]
        return sum(d2h[i] for i in ds) / len(ds)

    n = len(T)
    cutoff = sorted(d2h)[n // 2]
    rank = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = rank[:max(1, n // 4)]
    menu = []
    for i in good:
        p = (float(T[i][ix['Clndrs']]), float(T[i][ix['Volume']]))
        if p not in menu:
            menu.append(p)
        if len(menu) == 12:
            break

    out = []
    for k, r in enumerate(S):
        c0 = float(r[ix['Clndrs']])
        v0 = float(r[ix['Volume']])
        mo = float(r[ix['Model']])
        o = r[ix['origin']]
        f0 = (feat(c0, v0, mo), o)
        before = pred(f0)
        if round(before, 10) <= round(cutoff, 10):
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for c, v in menu:
            if c == c0 and v == v0:
                continue
            f = (feat(c, v, mo), o)
            after = pred(f)
            if round(before - after, 10) < 0.05:
                continue
            ch = {}
            if c != c0:
                ch['Clndrs'] = c
            if v != v0:
                ch['Volume'] = v
            key = (len(ch), round(dist(f0, f), 10), round(after, 10), (c, v))
            if best is None or key < best[0]:
                best = (key, after, ch)
        if best is None:
            out.append({"row": k, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            out.append({"row": k, "before": before, "after": best[1], "changes": best[2], "status": "improved"})
    print(json.dumps({"repairs": out}))

main()
