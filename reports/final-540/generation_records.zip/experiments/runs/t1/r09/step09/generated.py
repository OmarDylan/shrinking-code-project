import csv, sys, json, math, bisect
from collections import Counter

NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"

def load(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))

def num(v):
    try:
        x = float((v or "").strip())
        return x if math.isfinite(x) else None
    except Exception:
        return None

def med(a):
    a = sorted(a); n = len(a)
    return a[n // 2] if n % 2 else (a[n // 2 - 1] + a[n // 2]) / 2

def inv(M):
    n = len(M)
    A = [r[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(A[r][c]))
        A[c], A[p] = A[p], A[c]
        d = A[c][c]
        if abs(d) < 1e-15:
            return None
        A[c] = [x / d for x in A[c]]
        for r in range(n):
            if r != c:
                f = A[r][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [r[n:] for r in A]

def main():
    a = sys.argv
    tr = load(a[a.index("--train") + 1])
    te = load(a[a.index("--test") + 1])
    X = [[num(r.get(k)) for k in NUM] for r in tr]
    med_, sc, mu = [], [], []
    for j in range(3):
        col = [x[j] for x in X if x[j] is not None] or [0.0]
        m = med(col)
        s = 1.4826 * med([abs(v - m) for v in col])
        mean = sum(col) / len(col)
        sd = math.sqrt(sum((v - mean) ** 2 for v in col) / max(1, len(col) - 1))
        if s < 1e-9:
            s = sd
        if s < 1e-9:
            s = 1.0
        med_.append(m); sc.append(s); mu.append(mean)
    full = [x for x in X if None not in x]
    if len(full) < 5:
        full = [[mu[j] + (i % 2) * sc[j] for j in range(3)] for i in range(5)]
    fm = [sum(x[j] for x in full) / len(full) for j in range(3)]
    cov = [[sum((x[i] - fm[i]) * (x[j] - fm[j]) for x in full) / max(1, len(full) - 1)
            for j in range(3)] for i in range(3)]
    for i in range(3):
        cov[i][i] = cov[i][i] * (1 + 1e-6) + 1e-9
    invs = {}
    def getinv(idx):
        if idx not in invs:
            invs[idx] = inv([[cov[i][j] for j in idx] for i in idx])
        return invs[idx]
    cnt = Counter((r.get(CAT) or "").strip() for r in tr
                  if (r.get(CAT) or "").strip() not in ("", "?"))
    n = len(tr)

    def raw(r):
        x = [num(r.get(k)) for k in NUM]
        idx = tuple(j for j in range(3) if x[j] is not None)
        best = 0.0
        for j in idx:
            best = max(best, abs(x[j] - med_[j]) / sc[j])
        if idx:
            P = getinv(idx)
            if P:
                d = [x[j] - fm[j] for j in idx]
                q = sum(d[i] * P[i][k] * d[k] for i in range(len(idx)) for k in range(len(idx)))
                best = max(best, math.sqrt(max(q, 0.0)))
        o = (r.get(CAT) or "").strip()
        if o not in ("", "?"):
            best = max(best, -math.log((cnt.get(o, 0) + 0.5) / (n + 1)))
        return best if math.isfinite(best) else 0.0

    ts = sorted(raw(r) for r in tr)
    def sc_(r):
        v = raw(r)
        return bisect.bisect_right(ts, v) / (len(ts) + 1) if ts else 0.0
    # test ECDF: values beyond all train get len/(len+1)
    thr = 0.98
    scores = [min(1.0, max(0.0, sc_(r))) for r in te]
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

main()
