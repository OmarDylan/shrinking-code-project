import sys, csv, json, math

def main():
    args = sys.argv[1:]
    train_p = args[args.index("--train") + 1]
    test_p = args[args.index("--test") + 1]

    def read(p):
        with open(p, newline="") as f:
            r = csv.reader(f)
            h = next(r)
            return h, [row for row in r if row]

    h, tr = read(train_p)
    _, te = read(test_p)
    ix = {n: i for i, n in enumerate(h)}
    goals = ["Lbs-", "Acc+", "Mpg+"]
    heaven = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
    feats_num = ["Clndrs", "Volume", "Model"]
    feat_cat = "origin"

    def num(s):
        s = s.strip()
        if s == "?" or s == "":
            return None
        try:
            return float(s)
        except ValueError:
            return None

    # goal stats
    stats = {}
    for g in goals:
        vals = [num(r[ix[g]]) for r in tr]
        vals = [v for v in vals if v is not None]
        m = sum(vals) / len(vals)
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (len(vals) - 1)) if len(vals) > 1 else 0.0
        stats[g] = (m, sd)

    def norm(g, v):
        m, sd = stats[g]
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))

    def d2h_of(vals):
        return math.sqrt(sum((norm(g, vals[g]) - heaven[g]) ** 2 for g in goals) / 3)

    # feature stats
    fstat = {}
    for c in feats_num:
        vals = [num(r[ix[c]]) for r in tr]
        vals = [v for v in vals if v is not None]
        m = sum(vals) / len(vals)
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / max(1, len(vals) - 1)) or 1.0
        fstat[c] = (m, sd)

    def vec(r):
        v = []
        for c in feats_num:
            x = num(r[ix[c]])
            v.append(None if x is None else (x - fstat[c][0]) / fstat[c][1])
        o = r[ix[feat_cat]].strip()
        v.append(None if o in ("?", "") else o)
        return v

    def dist(a, b):
        s = 0.0
        n = 0
        for i in range(3):
            if a[i] is not None and b[i] is not None:
                s += (a[i] - b[i]) ** 2
                n += 1
        if a[3] is not None and b[3] is not None:
            s += 0.0 if a[3] == b[3] else 1.0
            n += 1
        return math.sqrt(s / n) if n else 1.0

    pts = []
    for r in tr:
        vals = {g: num(r[ix[g]]) for g in goals}
        if any(v is None for v in vals.values()):
            continue
        pts.append((vec(r), d2h_of(vals)))
    tv = [vec(r) for r in te]
    n = len(te)
    obs = {}
    K = 5

    def predict(i):
        ds = [(dist(tv[i], p), y) for p, y in pts]
        ds += [(dist(tv[i], tv[j]), y) for j, y in obs.items()]
        ds.sort(key=lambda t: t[0])
        nb = ds[:K]
        w = [1.0 / (d + 0.05) for d, _ in nb]
        pred = sum(wi * y for wi, (_, y) in zip(w, nb)) / sum(w)
        md = sum(d for d, _ in nb) / len(nb)
        return pred - 0.1 * md

    budget = min(10, n)
    for _ in range(budget):
        best = min((i for i in range(n) if i not in obs), key=lambda i: (predict(i), i))
        print(json.dumps({"inspect": best}), flush=True)
        line = sys.stdin.readline()
        resp = json.loads(line)
        g = resp["goals"]
        obs[best] = d2h_of({k: float(g[k]) for k in goals})

    ranked = sorted(obs, key=lambda i: (round(obs[i], 12), i))[:3]
    print(json.dumps({"selected": ranked}), flush=True)

main()
