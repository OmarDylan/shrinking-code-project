import sys, csv, math, argparse, json

def solve(A, b):
    n = len(b)
    M = [r[:] + [b[i]] for i, r in enumerate(A)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for r in range(n):
            if r != i:
                f = M[r][i] / d
                if f:
                    for c in range(i, n + 1):
                        M[r][c] -= f * M[i][c]
    return [M[i][n] / (M[i][i] or 1e-12) for i in range(n)]

def fit(X, y, lam=1.0):
    n, k = len(X), len(X[0])
    mu = [sum(r[j] for r in X) / n for j in range(k)]
    sd = [math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / n) or 1.0 for j in range(k)]
    Z = [[(r[j] - mu[j]) / sd[j] for j in range(k)] for r in X]
    ym = sum(y) / n
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j else 0) for j in range(k)] for i in range(k)]
    b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(k)]
    w = solve(A, b)
    return lambda r: ym + sum(w[j] * (r[j] - mu[j]) / sd[j] for j in range(k))

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def read(path):
    with open(path, newline="") as f:
        rd = csv.reader(f)
        h = [c.strip() for c in next(rd)]
        rows = [[c.strip() for c in r] for r in rd if r]
    return h, rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train")
    ap.add_argument("--test")
    a = ap.parse_args()
    h, tr = read(a.train)
    h2, te = read(a.test)
    ix = {n: i for i, n in enumerate(h)}
    ix2 = {n: i for i, n in enumerate(h2)}
    def g(r, m, n):
        return num(r[m[n]]) if n in m and m[n] < len(r) else None
    origins = sorted({r[ix["origin"]] for r in tr})
    def oh(r, m):
        o = r[m["origin"]] if "origin" in m and m["origin"] < len(r) else ""
        return [1.0 if o == x else 0.0 for x in origins]
    tr = [r for r in tr if all(g(r, ix, n) is not None for n in ("Lbs-", "Acc+", "Mpg+"))]
    # base features (no volume)
    def base(r, m, mm):
        c = g(r, m, "Clndrs"); mo = g(r, m, "Model")
        c = mm["c"] if c is None else c
        mo = mm["m"] if mo is None else mo
        return [c, c * c, mo] + oh(r, m)
    def avg(n):
        v = [g(r, ix, n) for r in tr]; v = [x for x in v if x is not None]
        return sum(v) / len(v) if v else 0.0
    mm = {"c": avg("Clndrs"), "m": avg("Model"), "v": avg("Volume")}
    vr = [r for r in tr if g(r, ix, "Volume") is not None]
    volf = fit([base(r, ix, mm) for r in vr], [g(r, ix, "Volume") for r in vr], 1.0)
    def full(r, m):
        b = base(r, m, mm)
        v = g(r, m, "Volume")
        if v is None:
            v = max(volf(b), 30.0)
        v = max(v, 1.0)
        return b + [v, math.log(v), b[0] * math.log(v)]
    Xtr = [full(r, ix) for r in tr]
    Xte = [full(r, ix2) for r in te]
    G = {n: [g(r, ix, n) for r in tr] for n in ("Lbs-", "Acc+", "Mpg+")}
    st = {}
    for n, v in G.items():
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / max(len(v) - 1, 1))
        st[n] = (m, sd)
    def norm(n, v):
        m, sd = st[n]
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    hv = {"Lbs-": 0, "Acc+": 1, "Mpg+": 1}
    def d2h(d):
        return math.sqrt(sum((norm(n, d[n]) - hv[n]) ** 2 for n in hv) / 3)
    ytr = [d2h({n: G[n][i] for n in G}) for i in range(len(tr))]
    mpgf = fit(Xtr, [math.log(max(v, 1e-3)) for v in G["Mpg+"]], 2.0)
    gf = {n: fit(Xtr, G[n], 2.0) for n in ("Lbs-", "Acc+")}
    df = fit(Xtr, ytr, 2.0)
    minmpg = min(G["Mpg+"]); maxmpg = max(G["Mpg+"])
    mpg, sc = [], []
    for x in Xte:
        lm = mpgf(x)
        m = math.exp(lm)
        m = min(max(m, minmpg * 0.7), maxmpg * 1.3)
        mpg.append(m)
        d = {"Lbs-": gf["Lbs-"](x), "Acc+": gf["Acc+"](x), "Mpg+": m}
        s = 0.5 * d2h(d) + 0.5 * df(x)
        sc.append(min(1.0, max(0.0, s)))
    print(json.dumps({"mpg": mpg, "scores": sc}))

main()
