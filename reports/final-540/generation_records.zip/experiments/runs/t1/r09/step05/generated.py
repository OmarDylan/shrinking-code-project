import csv, sys, math, json

FEATS = ["Clndrs", "Volume", "Model", "origin"]
NUMF = ["Clndrs", "Volume", "Model"]
GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(p):
    with open(p, newline="") as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = []
        for row in r:
            if not row:
                continue
            rows.append({h[i]: row[i].strip() for i in range(min(len(h), len(row)))})
    return rows


def num(v):
    if v is None or v == "?" or v == "":
        return None
    try:
        x = float(v)
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    if n < 2:
        return m, 0.0
    return m, math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1))


def mknorm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f


def main():
    a = sys.argv
    tr = read(a[a.index("--train") + 1])
    te = read(a[a.index("--test") + 1])
    cols = list(GOALS) + NUMF
    norms = {}
    for c in cols:
        vals = [x for x in (num(r.get(c)) for r in tr) if x is not None]
        norms[c] = mknorm(*stats(vals))

    def d2h(r):
        s = 0.0
        for g, h in GOALS.items():
            s += (norms[g](num(r[g])) - h) ** 2
        return math.sqrt(s / 3)

    order = sorted(range(len(tr)), key=lambda i: (round(d2h(tr[i]), 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]

    centers = {}
    for c in NUMF:
        gv = [x for x in (num(r.get(c)) for r in good) if x is not None]
        pv = [x for x in (num(r.get(c)) for r in poor) if x is not None]
        gc = norms[c](sum(gv) / len(gv)) if gv else None
        pc = norms[c](sum(pv) / len(pv)) if pv else None
        centers[c] = (gc, pc)

    def freq(group):
        known = [r.get("origin") for r in group if r.get("origin") not in (None, "", "?")]
        d = {}
        for k in known:
            d[k] = d.get(k, 0) + 1
        n = len(known)
        return d, n

    gf, gn = freq(good)
    pf, pn = freq(poor)

    out = []
    for r in te:
        goals = {g: abs(norms[g](num(r[g])) - h) for g, h in GOALS.items()}
        feats = {}
        for c in NUMF:
            x = num(r.get(c))
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = norms[c](x)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        k = r.get("origin")
        if k in (None, "", "?"):
            feats["origin"] = 0.0
        else:
            pfr = pf.get(k, 0) / pn if pn else 0.0
            gfr = gf.get(k, 0) / gn if gn else 0.0
            feats["origin"] = max(0.0, pfr - gfr)
        go = sorted(goals, key=lambda n: (-round(goals[n], 10), n))
        fo = sorted(feats, key=lambda n: (-round(feats[n], 10), n))
        out.append({"goals": goals, "features": feats, "goal_order": go, "feature_order": fo})
    sys.stdout.write(json.dumps({"diagnoses": out}))


if __name__ == "__main__":
    main()
