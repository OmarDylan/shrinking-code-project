import sys, csv, json, math

def rd(p):
    with open(p, newline='') as f:
        return [{k.strip(): (v or '').strip() for k, v in r.items()} for r in csv.DictReader(f)]

def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except Exception:
        return None

def mean(a): return sum(a) / len(a)
def sd(a):
    m = mean(a)
    return math.sqrt(sum((x - m) ** 2 for x in a) / (len(a) - 1)) if len(a) > 1 else 0.0

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for j in range(i, n + 1):
            M[i][j] /= d
        for r in range(n):
            if r != i:
                f = M[r][i]
                if f:
                    for j in range(i, n + 1):
                        M[r][j] -= f * M[i][j]
    return [M[i][n] for i in range(n)]

NUM = ['Clndrs', 'Volume', 'Model']
GOALS = ['Lbs-', 'Acc+', 'Mpg+']

def certify(xs, ys):
    n, m = len(xs), len(ys)
    vx, vy = sd(xs) ** 2, sd(ys) ** 2
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cl = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    i = j = 0
    ks = 0.0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v: i += 1
        while j < m and sy[j] <= v: j += 1
        ks = max(ks, abs(i / n - j / m))
    ks /= math.sqrt(1 / n + 1 / m)
    return cohen, cl, ks, (cohen <= 0.35 and cl <= 0.197 and ks <= 1.36)

def main():
    a = sys.argv
    train = rd(a[a.index('--train') + 1])
    test = rd(a[a.index('--test') + 1])
    orgs = sorted({r['origin'] for r in train})
    nm = {c: mean([num(r[c]) for r in train if num(r[c]) is not None]) for c in NUM}

    def feats(r, usevol):
        cols = [c for c in NUM if usevol or c != 'Volume']
        f = []
        for c in cols:
            v = num(r.get(c, '?'))
            f.append(nm[c] if v is None else v)
        f += [1.0 if r.get('origin') == o else 0.0 for o in orgs]
        return f

    models = {}
    def fit(usevol):
        X = [feats(r, usevol) for r in train]
        k = len(X[0])
        mu = [mean([x[j] for x in X]) for j in range(k)]
        s = [sd([x[j] for x in X]) or 1.0 for j in range(k)]
        Z = [[(x[j] - mu[j]) / s[j] for j in range(k)] for x in X]
        ws = {}
        for g in GOALS:
            y = [float(r[g]) for r in train]
            ym = mean(y)
            A = [[sum(z[i] * z[j] for z in Z) + (1.0 if i == j else 0.0) for j in range(k)] for i in range(k)]
            b = [sum(z[i] * (yy - ym) for z, yy in zip(Z, y)) for i in range(k)]
            ws[g] = (solve(A, b), ym)
        return mu, s, ws
    models[True] = fit(True)
    models[False] = fit(False)

    stats = {g: (mean([float(r[g]) for r in train]), sd([float(r[g]) for r in train])) for g in GOALS}
    def d2h(vals):
        t = 0.0
        for g, v in zip(GOALS, vals):
            m, s = stats[g]
            z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            h = 0.0 if g == 'Lbs-' else 1.0
            t += (nv - h) ** 2
        return math.sqrt(t / 3)

    hist = [d2h([float(r[g]) for g in GOALS]) for r in train]

    mpg, scores, alerts = [], [], []
    for i, r in enumerate(test):
        uv = num(r.get('Volume', '?')) is not None
        mu, s, ws = models[uv]
        x = feats(r, uv)
        z = [(x[j] - mu[j]) / s[j] for j in range(len(x))]
        pr = {}
        for g in GOALS:
            w, ym = ws[g]
            pr[g] = ym + sum(wi * zi for wi, zi in zip(w, z))
        pr['Mpg+'] = max(pr['Mpg+'], 1.0)
        pr['Lbs-'] = max(pr['Lbs-'], 1.0)
        pr['Acc+'] = max(pr['Acc+'], 0.1)
        sc = min(1.0, max(0.0, d2h([pr[g] for g in GOALS])))
        mpg.append(pr['Mpg+'])
        scores.append(sc)
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not certify(hist, scores[i - 19:i + 1])[3])
    print(json.dumps({"mpg": mpg, "scores": scores, "alerts": alerts}))

main()
