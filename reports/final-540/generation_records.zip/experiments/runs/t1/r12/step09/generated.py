import csv, sys, json, math, statistics as st

def load(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

def rob(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return 0.0, 1.0
    m = st.median(vals)
    s = 1.4826 * st.median([abs(v - m) for v in vals])
    if s < 1e-9:
        s = st.pstdev(vals) if len(vals) > 1 else 0.0
    if s < 1e-9:
        s = max(abs(m) * 0.05, 1.0)
    return m, s

def main():
    a = sys.argv
    tr = load(a[a.index('--train') + 1])
    te = load(a[a.index('--test') + 1])
    cols = ['Clndrs', 'Volume', 'Model']

    def get(r):
        return [num(r.get(c)) for c in cols], (r.get('origin') or '?').strip()

    T = [get(r) for r in tr]
    stats = [rob([t[0][i] for t in T]) for i in range(3)]
    groups = {}
    for x, o in T:
        if x[0] is not None and x[1] is not None:
            groups.setdefault(x[0], []).append(x[1])
    gst = {k: rob(v) for k, v in groups.items() if len(v) >= 8}
    freq = {}
    for _, o in T:
        if o != '?':
            freq[o] = freq.get(o, 0) + 1
    n = max(1, sum(freq.values()))

    def raw(x, o):
        z = [0.0]
        for i in range(3):
            if x[i] is not None:
                m, s = stats[i]
                z.append(abs(x[i] - m) / s)
        if x[0] is not None and x[1] is not None and x[0] in gst:
            m, s = gst[x[0]]
            z.append(abs(x[1] - m) / s)
        if o != '?':
            f = freq.get(o, 0) / n
            if f == 0:
                z.append(5.0)
            elif f < 0.01:
                z.append(3.5)
        return max(z)

    sq = lambda r: 1 - math.exp(-r * r / 40.0)
    ts = sorted(sq(raw(x, o)) for x, o in T)
    if ts:
        q = ts[min(len(ts) - 1, int(0.975 * len(ts)))]
    else:
        q = 0.5
    thr = min(1.0, max(0.0, max(q, sq(3.5))))
    scores = []
    for r in te:
        x, o = get(r)
        s = sq(raw(x, o))
        scores.append(min(1.0, max(0.0, s)))
    print(json.dumps({"scores": scores, "alerts": [s > thr for s in scores], "threshold": thr}))

if __name__ == '__main__':
    main()
