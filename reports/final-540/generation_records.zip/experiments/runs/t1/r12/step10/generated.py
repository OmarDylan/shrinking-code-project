import sys, csv, json, math

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]


def norm(v, m, s):
    z = max(-3.0, min(3.0, (v - m) / (s + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def stats(vals):
    n = len(vals)
    m = sum(vals) / n
    s = math.sqrt(sum((x - m) ** 2 for x in vals) / (n - 1)) if n > 1 else 0.0
    return m, s


def isnum(x):
    try:
        float(x)
        return True
    except Exception:
        return False


def mean(a):
    return sum(a) / len(a)


def svar(a):
    m = mean(a)
    return sum((x - m) ** 2 for x in a) / (len(a) - 1)


def certify(xs, ys):
    n, m = len(xs), len(ys)
    pv = ((n - 1) * svar(xs) + (m - 1) * svar(ys)) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pv) + 1e-32)
    t = 0
    for x in xs:
        for y in ys:
            t += (x > y) - (x < y)
    cliffs = abs(t) / (n * m)
    ks = 0.0
    for v in set(xs) | set(ys):
        d = abs(sum(1 for x in xs if x <= v) / n - sum(1 for y in ys if y <= v) / m)
        ks = max(ks, d)
    ks /= math.sqrt(1 / n + 1 / m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}


def main():
    a = sys.argv
    train_path = a[a.index("--train") + 1]
    test_path = a[a.index("--test") + 1]
    with open(train_path, newline="") as f:
        rd = list(csv.reader(f))
    th = [h.strip() for h in rd[0]]
    trows = [r for r in rd[1:] if r]
    ti = {h: i for i, h in enumerate(th)}
    gst = {}
    for g in GOALS:
        gst[g] = stats([float(r[ti[g]]) for r in trows])

    def d2h(vals):
        s = 0.0
        for g in GOALS:
            s += (norm(vals[g], *gst[g]) - HEAVEN[g]) ** 2
        return math.sqrt(s / 3)

    tscore = [d2h({g: float(r[ti[g]]) for g in GOALS}) for r in trows]
    target = sorted(tscore)[len(trows) // 4]
    nst = {c: stats([float(r[ti[c]]) for r in trows if isnum(r[ti[c]])]) for c in NUM}

    def feat(get):
        out = []
        for c in NUM:
            v = get(c)
            out.append(norm(float(v), *nst[c]) if v is not None and isnum(v) else None)
        o = get("origin")
        out.append(None if o is None or str(o).strip() == "?" else str(o).strip())
        return out

    tf = [feat(lambda c, r=r: r[ti[c]]) for r in trows]

    def dist(p, q):
        s = 0.0
        k = 0
        for i in range(4):
            if p[i] is None or q[i] is None:
                continue
            g = (p[i] - q[i]) if i < 3 else (0.0 if p[i] == q[i] else 1.0)
            s += g * g
            k += 1
        return math.sqrt(s / k) if k else 1.0

    def predict(f):
        ds = sorted((round(dist(f, t), 12), i) for i, t in enumerate(tf))[:5]
        return mean([tscore[i] for _, i in ds])

    with open(test_path) as fh:
        data = json.load(fh)
    header = data["header"]
    hi = {h: i for i, h in enumerate(header)}
    rows = data["rows"]

    def read():
        line = sys.stdin.readline()
        return json.loads(line)

    def inspect(ep, strat, idx):
        sys.stdout.write(json.dumps({"episode": ep, "strategy": strat, "inspect": idx}) + "\n")
        sys.stdout.flush()
        resp = read()
        return d2h({g: float(resp["goals"][g]) for g in GOALS})

    results = []
    for e, ep in enumerate(data["episodes"]):
        pool = ep["pool"]
        pred = {i: predict(feat(lambda c, i=i: rows[i][hi[c]] if c in hi else None)) for i in pool}
        order = sorted(pool, key=lambda i: (pred[i], i))[:10]
        obs_a = [inspect(e, "adaptive", i) for i in order]
        obs_r = [inspect(e, "random", i) for i in ep["random_order"][:10]]

        def summ(o):
            lt = 11
            for k, v in enumerate(o):
                if round(v, 12) <= round(target, 12):
                    lt = k + 1
                    break
            return {"best5": min(o[:5]), "best10": min(o), "labels_to_target": lt}

        results.append({"episode": e, "adaptive": summ(obs_a), "random": summ(obs_r)})

    comps = {}
    for k in ["best5", "best10", "labels_to_target"]:
        comps[k] = certify([float(r["adaptive"][k]) for r in results],
                           [float(r["random"][k]) for r in results])
    sys.stdout.write(json.dumps({"results": results, "comparisons": comps}) + "\n")
    sys.stdout.flush()


main()
