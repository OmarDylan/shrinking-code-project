import csv, sys, json, math

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def read(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def main():
    a = sys.argv[1:]
    if not a or a[0] != 'fix':
        return
    tr = read(a[a.index('--train') + 1])
    te = read(a[a.index('--test') + 1])
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    heaven = {'Lbs-': 0.0, 'Acc+': 1.0, 'Mpg+': 1.0}
    sig = lambda z: 1 / (1 + math.exp(-1.702 * z))

    def stats(vals):
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        return m, sd

    def norm(v, st):
        z = (v - st[0]) / (st[1] + 1e-32)
        return sig(max(-3.0, min(3.0, z)))

    gst = {g: stats([float(r[g]) for r in tr]) for g in goals}
    d2h = []
    for r in tr:
        s = sum((norm(float(r[g]), gst[g]) - heaven[g]) ** 2 for g in goals)
        d2h.append(math.sqrt(s / 3))
    feats = ['Clndrs', 'Volume', 'Model']
    fst = {f: stats([float(r[f]) for r in tr]) for f in feats}

    def enc(c, v, m, o):
        out = []
        for x, f in ((c, 'Clndrs'), (v, 'Volume'), (m, 'Model')):
            out.append(None if x is None else norm(x, fst[f]))
        return out, o

    T = [enc(float(r['Clndrs']), float(r['Volume']), float(r['Model']), r['origin']) for r in tr]

    def dist(A, B):
        s = 0.0
        for x, y in zip(A[0], B[0]):
            s += 1.0 if (x is None or y is None) else (x - y) ** 2
        s += 0.0 if A[1] == B[1] else 1.0
        return math.sqrt(s / 4)

    def predict(E):
        ds = sorted((round(dist(E, t), 12), i) for i, t in enumerate(T))
        k = ds[:5]
        return sum(d2h[i] for _, i in k) / len(k)

    n = len(tr)
    cutoff = sorted(d2h)[n // 2]
    order = sorted(range(n), key=lambda i: (round(d2h[i], 12), i))
    good = order[:max(1, n // 4)]
    menu = []
    seen = set()
    for i in good:
        p = (float(tr[i]['Clndrs']), float(tr[i]['Volume']))
        if p not in seen:
            seen.add(p)
            menu.append(p)
            if len(menu) == 12:
                break

    res = []
    for idx, r in enumerate(te):
        c = num(r['Clndrs'])
        v = num(r['Volume'])
        m = num(r['Model'])
        o = r['origin']
        E0 = enc(c, v, m, o)
        before = predict(E0)
        if round(before, 10) <= round(cutoff, 10):
            res.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"})
            continue
        best = None
        for nc, nv in menu:
            cc = c is None or nc != c
            vc = v is None or nv != v
            if not (cc or vc):
                continue
            E = enc(nc, nv, m, o)
            after = predict(E)
            if round(before - after, 10) >= 0.05:
                key = (int(cc) + int(vc), round(dist(E0, E), 10), round(after, 10), (nc, nv))
                if best is None or key < best[0]:
                    best = (key, after, cc, vc, nc, nv)
        if best is None:
            res.append({"row": idx, "before": before, "after": before, "changes": {}, "status": "no_candidate"})
        else:
            _, after, cc, vc, nc, nv = best
            ch = {}
            if cc:
                ch['Clndrs'] = nc
            if vc:
                ch['Volume'] = nv
            res.append({"row": idx, "before": before, "after": after, "changes": ch, "status": "improved"})
    sys.stdout.write(json.dumps({"repairs": res}))

main()
