import sys, csv, json, math

def load(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    h = [x.strip() for x in r[0]]
    return h, [[c.strip() for c in row] for row in r[1:] if row]

def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except Exception:
        return None

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(M[r][i]))
        M[i], M[p] = M[p], M[i]
        d = M[i][i] or 1e-12
        for j in range(i, n + 1):
            M[i][j] /= d
        for r in range(n):
            if r != i and M[r][i]:
                f = M[r][i]
                for j in range(i, n + 1):
                    M[r][j] -= f * M[i][j]
    return [M[i][n] for i in range(n)]

def ridge(X, y, lam=0.5):
    m = len(X[0])
    mu = [sum(r[j] for r in X) / len(X) for j in range(m)]
    sd = [math.sqrt(sum((r[j] - mu[j]) ** 2 for r in X) / len(X)) or 1.0 for j in range(m)]
    Z = [[1.0] + [(r[j] - mu[j]) / sd[j] for j in range(m)] for r in X]
    k = m + 1
    A = [[sum(z[i] * z[j] for z in Z) + (lam if i == j and i > 0 else 0) for j in range(k)] for i in range(k)]
    b = [sum(z[i] * t for z, t in zip(Z, y)) for i in range(k)]
    w = solve(A, b)
    def pred(x):
        return w[0] + sum(w[j + 1] * (x[j] - mu[j]) / sd[j] for j in range(m))
    return pred

def main():
    a = sys.argv
    tr = a[a.index('--train') + 1]
    te = a[a.index('--test') + 1]
    h, R = load(tr)
    th, T = load(te)
    ix = {n: i for i, n in enumerate(h)}
    tx = {n: i for i, n in enumerate(th)}
    def col(row, ixm, n):
        i = ixm.get(n)
        if i is None or i >= len(row):
            return None
        return num(row[i])
    def orig(row, ixm):
        i = ixm.get('origin')
        return row[i] if i is not None and i < len(row) else '?'
    goals = ['Lbs-', 'Acc+', 'Mpg+']
    # keep rows with complete goals
    R = [r for r in R if all(col(r, ix, g) is not None and col(r, ix, g) > -1e18 for g in goals)]
    G = [[col(r, ix, g) for g in goals] for r in R]
    n = len(G)
    means = [sum(g[k] for g in G) / n for k in range(3)]
    sds = [math.sqrt(sum((g[k] - means[k]) ** 2 for g in G) / max(n - 1, 1)) for k in range(3)]
    def d2h(v):
        s = 0
        for k in range(3):
            z = max(-3, min(3, (v[k] - means[k]) / (sds[k] + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - (0 if k == 0 else 1)) ** 2
        return math.sqrt(s / 3)
    y_d = [d2h(g) for g in G]
    y_m = [math.log(max(g[2], 1e-6)) for g in G]
    cats = sorted({orig(r, ix) for r in R if orig(r, ix) != '?'})
    def mean_of(n_):
        v = [col(r, ix, n_) for r in R]
        v = [x for x in v if x is not None]
        return sum(v) / len(v) if v else 0.0
    dflt = {k: mean_of(k) for k in ['Clndrs', 'Volume', 'Model']}
    def feats(row, ixm, use_vol):
        c = col(row, ixm, 'Clndrs'); c = dflt['Clndrs'] if c is None else c
        m = col(row, ixm, 'Model'); m = dflt['Model'] if m is None else m
        o = orig(row, ixm)
        f = [c, c * c, m] + [1.0 if o == k else 0.0 for k in cats]
        if use_vol:
            v = col(row, ixm, 'Volume'); v = dflt['Volume'] if v is None else v
            f += [v, math.log(max(v, 1.0)), v * v / 1000.0]
        return f
    models = {}
    for uv in (True, False):
        X = [feats(r, ix, uv) for r in R]
        models[uv] = (ridge(X, y_m), ridge(X, y_d))
    mpg, sc = [], []
    mean_mpg = means[2]
    for r in T:
        uv = col(r, tx, 'Volume') is not None
        pm, pd = models[uv]
        f = feats(r, tx, uv)
        mv = math.exp(pm(f))
        if not math.isfinite(mv) or mv <= 0:
            mv = mean_mpg
        d = pd(f)
        if not math.isfinite(d):
            d = sum(y_d) / n
        mpg.append(mv)
        sc.append(max(0.0, min(1.0, d)))
    print(json.dumps({"mpg": mpg, "scores": sc}))

main()
