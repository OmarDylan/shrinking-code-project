import sys, json, math
from bisect import bisect_right


def stats(xs, ys):
    n, m = len(xs), len(ys)
    mx = math.fsum(xs) / n
    my = math.fsum(ys) / m
    vx = math.fsum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = math.fsum((y - my) ** 2 for y in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)

    sx, sy = sorted(xs), sorted(ys)
    # Cliff's delta via sorted counts
    total = 0
    for x in sx:
        less = bisect_right(sy, x - 0) # placeholder, fixed below
    total = 0
    from bisect import bisect_left
    for x in sx:
        gt = bisect_left(sy, x)        # count of y < x
        le = bisect_right(sy, x)       # count of y <= x
        lt = m - le                    # count of y > x
        total += gt - lt
    cliffs = abs(total) / (n * m)

    ks = 0.0
    for v in sorted(set(sx) | set(sy)):
        d = abs(bisect_right(sx, v) / n - bisect_right(sy, v) / m)
        if d > ks:
            ks = d
    ks /= math.sqrt(1 / n + 1 / m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}


def main():
    a = sys.argv[1:]
    if not a or a[0] != "certify":
        sys.exit(1)
    test = None
    for i, t in enumerate(a):
        if t == "--test" and i + 1 < len(a):
            test = a[i + 1]
    with open(test) as f:
        cases = json.load(f)
    out = {"comparisons": [stats([float(x) for x in c["xs"]], [float(y) for y in c["ys"]]) for c in cases]}
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
