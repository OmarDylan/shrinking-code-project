import csv, sys, json, math

def load(p):
    with open(p, newline='') as f:
        return list(csv.DictReader(f))

def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None

G = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]
NUM = ["Clndrs", "Volume", "Model"]

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    train, test = load(tr), load(te)

    st = {}
    for g, _ in G:
        v = [num(r.get(g)) for r in train]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st[g] = (m, sd)

    def d2h(gs):
        s = 0.0
        for g, h in G:
            m, sd = st[g]
            z = max(-3.0, min(3.0, (gs[g] - m) / (sd + 1e-32)))
            n = 1 / (1 + math.exp(-1.702 * z))
            s += (n - h) ** 2
        return math.sqrt(s / 3)

    # train features
    ns = {}
    for c in NUM:
        v = [num(r.get(c)) for r in train]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v) if v else 0.0
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 1.0
        ns[c] = (m, sd or 1.0)

    def feat(r):
        f = [None if num(r.get(c)) is None else (num(r[c]) - ns[c][0]) / ns[c][1] for c in NUM]
        o = r.get("origin")
        f.append(None if o in (None, "", "?") else o)
        return f

    tf, ty = [], []
    for r in train:
        gs = {g: num(r.get(g)) for g, _ in G}
        if any(v is None for v in gs.values()):
            continue
        tf.append(feat(r))
        ty.append(d2h(gs))

    def predict(f):
        ds = []
        for x, y in zip(tf, ty):
            s = 0.0
            c = 0
            for i in range(3):
                if f[i] is not None and x[i] is not None:
                    s += (f[i] - x[i]) ** 2
                    c += 1
            if f[3] is not None and x[3] is not None:
                s += 0.0 if f[3] == x[3] else 1.0
                c += 1
            d = math.sqrt(s / c) if c else 10.0
            ds.append((d, y))
        ds.sort(key=lambda t: t[0])
        k = ds[:7]
        w = [1 / (d + 0.1) for d, _ in k]
        return sum(wi * y for wi, (_, y) in zip(w, k)) / sum(w) if k else 0.5

    preds = [(predict(feat(r)), i) for i, r in enumerate(test)]
    preds.sort()
    picks = [i for _, i in preds[:10]]

    obs = []
    for i in picks:
        print(json.dumps({"inspect": i}), flush=True)
        line = sys.stdin.readline()
        resp = json.loads(line)
        obs.append((round(d2h(resp["goals"]), 12), i))
    obs.sort()
    print(json.dumps({"selected": [i for _, i in obs[:3]]}), flush=True)

main()
