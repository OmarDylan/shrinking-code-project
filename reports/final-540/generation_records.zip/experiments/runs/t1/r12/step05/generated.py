import csv, sys, json, math

def load(p):
    with open(p, newline="") as f:
        r = csv.reader(f)
        h = [x.strip() for x in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return h, rows

def num(s):
    if s == "?" or s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None

def stats(vals):
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd

def mk(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1 / (1 + math.exp(-1.702 * z))
    return f

def main():
    a = sys.argv
    tr = a[a.index("--train") + 1]
    te = a[a.index("--test") + 1]
    h, T = load(tr)
    _, S = load(te)
    ix = {n: i for i, n in enumerate(h)}
    nums = ["Clndrs", "Volume", "Model"]
    cat = "origin"
    goals = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}

    def col(rows, n):
        i = ix[n]
        return [num(r[i]) if i < len(r) else None for r in rows]

    norm = {}
    for n in list(nums) + list(goals):
        norm[n] = mk(*stats([v for v in col(T, n) if v is not None]))

    def d2h(r):
        s = 0.0
        for g, hv in goals.items():
            v = num(r[ix[g]])
            if v is None:
                continue
            s += (norm[g](v) - hv) ** 2
        return math.sqrt(s / 3)

    order = sorted(range(len(T)), key=lambda i: (round(d2h(T[i]), 12), i))
    q = max(1, len(T) // 4)
    good = [T[i] for i in order[:q]]
    poor = [T[i] for i in order[-q:]]

    centers = {}
    for n in nums:
        c = []
        for grp in (good, poor):
            vs = [v for v in col(grp, n) if v is not None]
            c.append(norm[n](sum(vs) / len(vs)) if vs else None)
        centers[n] = c

    def freq(grp):
        k = [r[ix[cat]] for r in grp if r[ix[cat]] != "?" and r[ix[cat]] != ""]
        d = {}
        for x in k:
            d[x] = d.get(x, 0) + 1
        return d, len(k)
    gf, gn = freq(good)
    pf, pn = freq(poor)

    out = []
    for r in S:
        feats = {}
        for n in nums:
            v = num(r[ix[n]]) if ix[n] < len(r) else None
            gc, pc = centers[n]
            if v is None or gc is None or pc is None:
                feats[n] = 0.0
            else:
                x = norm[n](v)
                feats[n] = max(0.0, abs(x - gc) - abs(x - pc))
        c = r[ix[cat]] if ix[cat] < len(r) else "?"
        if c in ("?", ""):
            feats[cat] = 0.0
        else:
            g = gf.get(c, 0) / gn if gn else 0.0
            p = pf.get(c, 0) / pn if pn else 0.0
            feats[cat] = max(0.0, p - g)
        gl = {}
        for g, hv in goals.items():
            v = num(r[ix[g]]) if ix[g] < len(r) else None
            gl[g] = 0.0 if v is None else abs(norm[g](v) - hv)
        key = lambda d: sorted(d, key=lambda k: (-round(d[k], 10), k))
        out.append({"goals": gl, "features": feats,
                    "goal_order": key(gl), "feature_order": key(feats)})
    sys.stdout.write(json.dumps({"diagnoses": out}))

main()
