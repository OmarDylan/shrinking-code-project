import sys, csv, json, math

GOALS = ["Lbs-", "Acc+", "Mpg+"]
HEAVEN = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM = ["Clndrs", "Volume", "Model"]
CAT = "origin"
FEATS = NUM + [CAT]


def read(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def num(v):
    if v is None:
        return None
    v = v.strip()
    if v == "?" or v == "":
        return None
    try:
        return float(v)
    except ValueError:
        return None


def stats(vals):
    vals = [v for v in vals if v is not None]
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return m, sd


def make_norm(m, sd):
    def f(v):
        z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
        return 1.0 / (1.0 + math.exp(-1.702 * z))
    return f


def main():
    args = sys.argv[1:]
    if not args or args[0] != "justify":
        sys.stderr.write("unsupported command\n")
        sys.exit(1)
    tr = te = None
    i = 1
    while i < len(args):
        if args[i] == "--train":
            tr = args[i + 1]
            i += 2
        elif args[i] == "--test":
            te = args[i + 1]
            i += 2
        else:
            i += 1
    train, test = read(tr), read(te)

    cols = NUM + GOALS
    norms = {}
    for c in cols:
        m, sd = stats([num(r.get(c)) for r in train])
        norms[c] = make_norm(m, sd)

    def d2h(r):
        s = 0.0
        for g in GOALS:
            s += (norms[g](num(r[g])) - HEAVEN[g]) ** 2
        return math.sqrt(s / 3)

    tr_d = [d2h(r) for r in train]
    order = sorted(range(len(train)), key=lambda i: (round(tr_d[i], 12), i))
    q = max(1, len(train) // 4)
    good = [train[i] for i in order[:q]]
    poor = [train[i] for i in order[-q:]]

    centers = {}
    for c in NUM:
        cs = []
        for grp in (good, poor):
            vals = [num(r[c]) for r in grp]
            vals = [v for v in vals if v is not None]
            cs.append(norms[c](sum(vals) / len(vals)) if vals else None)
        centers[c] = cs

    def freq(grp, cat):
        known = [r[CAT].strip() for r in grp if r[CAT].strip() not in ("?", "")]
        if not known:
            return 0.0
        return known.count(cat) / len(known)

    def diagnose(r):
        goals = {g: abs(norms[g](num(r[g])) - HEAVEN[g]) for g in GOALS}
        feats = {}
        for c in NUM:
            x = num(r[c])
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = norms[c](x)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        cat = r[CAT].strip()
        if cat in ("?", ""):
            feats[CAT] = 0.0
        else:
            feats[CAT] = max(0.0, freq(poor, cat) - freq(good, cat))
        go = sorted(goals, key=lambda n: (-round(goals[n], 10), n))
        fo = sorted(feats, key=lambda n: (-round(feats[n], 10), n))
        return goals, feats, go, fo

    n = len(test)
    scores = [d2h(r) for r in test]
    diags = [diagnose(r) for r in test]
    cutoff = sorted(tr_d)[len(tr_d) // 2]

    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: diags[loser][0][g] ** 2 - diags[winner][0][g] ** 2 for g in GOALS}
            adv_goal = sorted(GOALS, key=lambda g: (-round(adv[g], 10), g))[0]
        goals, feats, go, fo = diags[j]
        weakest = go[0]
        top = fo[0] if feats[fo[0]] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f (car %d), cutoff %.3f; weakest goal %s." % (
            j, "accepted" if accepted else "rejected", s, o, k, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; largest advantage in %s." % (winner, adv_goal)
        else:
            text += " Scores tie."
        if top is not None:
            text += " Top feature: %s." % top
        out.append({"row": j, "other": k, "score": s, "other_score": o,
                    "cutoff": cutoff, "accepted": accepted, "winner": winner,
                    "advantage_goal": adv_goal, "weakest_goal": weakest,
                    "top_feature": top, "text": text})
    sys.stdout.write(json.dumps({"explanations": out}))


main()
