import sys, csv, json, math

def rd(p):
    with open(p, newline='') as f:
        r = list(csv.reader(f))
    h = [c.strip() for c in r[0]]
    return h, [dict(zip(h, [c.strip() for c in row])) for row in r[1:] if row]

def fl(v):
    try:
        return float(v)
    except Exception:
        return None

G = ['Lbs-', 'Acc+', 'Mpg+']

def stats(tr):
    st = []
    for g in G:
        v = [fl(r.get(g)) for r in tr]
        v = [x for x in v if x is not None]
        m = sum(v) / len(v)
        sd = math.sqrt(sum((x - m) ** 2 for x in v) / (len(v) - 1)) if len(v) > 1 else 0.0
        st.append((m, sd))
    return st

def d2h(vals, st):
    s = 0
    for v, (m, sd), h in zip(vals, st, (0, 1, 1)):
        z = max(-3, min(3, (v - m) / (sd + 1e-32)))
        s += (1 / (1 + math.exp(-1.702 * z)) - h) ** 2
    return math.sqrt(s / 3)

def solve(A, b):
    n = len(b)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for i in range(n):
        p = max(range(i, n), key=lambda k: abs(M[k][i]))
        M[i], M[p] = M[p], M[i]
        if abs(M[i][i]) < 1e-12:
            M[i][i] = 1e-12
        for k in range(n):
            if k != i:
                f = M[k][i] / M[i][i]
                for j in range(i, n + 1):
                    M[k][j] -= f * M[i][j]
    return [M[i][n] / M[i][i] for i in range(n)]

class Ridge:
    def __init__(self, tr, ys, use_vol, lam=1.0):
        self.nums = ['Clndrs', 'Model'] + (['Volume'] if use_vol else [])
        self.orig = sorted({r.get('origin', '') for r in tr})
        self.mu = {}
        self.sd = {}
        for c in self.nums:
            v = [fl(r.get(c)) for r in tr]
            v = [x for x in v if x is not None]
            m = sum(v) / len(v) if v else 0.0
            s = math.sqrt(sum((x - m) ** 2 for x in v) / max(1, len(v) - 1)) if v else 1.0
            self.mu[c] = m
            self.sd[c] = s or 1.0
        X = [self.f(r) for r in tr]
        k = len(X[0])
        A = [[sum(x[i] * x[j] for x in X) + (lam if i == j and i > 0 else 0) for j in range(k)] for i in range(k)]
        b = [sum(x[i] * y for x, y in zip(X, ys)) for i in range(k)]
        self.w = solve(A, b)

    def f(self, r):
        x = [1.0]
        for c in self.nums:
            v = fl(r.get(c))
            x.append(0.0 if v is None else (v - self.mu[c]) / self.sd[c])
        x += [1.0 if r.get('origin', '') == o else 0.0 for o in self.orig]
        return x

    def p(self, r):
        return sum(a * b for a, b in zip(self.w, self.f(r)))

def guess(tr, te):
    st = stats(tr)
    rows = [r for r in tr if all(fl(r.get(g)) is not None for g in G)]
    mp = [fl(r['Mpg+']) for r in rows]
    ds = [d2h([fl(r[g]) for g in G], st) for r in rows]
    mods = {}
    for uv in (True, False):
        mods[uv] = (Ridge(rows, mp, uv), Ridge(rows, ds, uv))
    lo = min(mp)
    mpg, sc = [], []
    for r in te:
        uv = fl(r.get('Volume')) is not None
        a, b = mods[uv]
        mpg.append(max(a.p(r), max(lo * 0.5, 1.0)))
        sc.append(min(1.0, max(0.0, b.p(r))))
    return mpg, sc, rows, st

def mean(x):
    return sum(x) / len(x)

def cert(xs, ys):
    n, m = len(xs), len(ys)
    mx, my = mean(xs), mean(ys)
    vx = sum((x - mx) ** 2 for x in xs) / (n - 1)
    vy = sum((y - my) ** 2 for y in ys) / (m - 1)
    pv = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    co = abs(mx - my) / (math.sqrt(pv) + 1e-32)
    cl = abs(sum((x > y) - (x < y) for x in xs for y in ys)) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    import bisect
    ks = max(abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m) for v in set(xs) | set(ys))
    ks /= math.sqrt(1 / n + 1 / m)
    return co, cl, ks, (co <= 0.35 and cl <= 0.197 and ks <= 1.36)

def main():
    cmd = sys.argv[1]
    a = sys.argv[2:]
    arg = {a[i]: a[i + 1] for i in range(0, len(a) - 1, 2)}
    if cmd == 'certify':
        cases = json.load(open(arg['--test'])) if '--test' in arg else json.load(open(arg['--cases']))
        out = []
        for c in cases:
            co, cl, ks, s = cert(c['xs'], c['ys'])
            out.append({"cohen": co, "cliffs": cl, "ks": ks, "same": s})
        print(json.dumps({"comparisons": out}))
        return
    _, tr = rd(arg['--train'])
    _, te = rd(arg['--test'])
    if cmd == 'remember':
        st = stats(tr)
        sc = [d2h([fl(r[g]) for g in G], st) for r in te]
        idx = sorted(range(len(sc)), key=lambda i: (sc[i], i))
        print(json.dumps({"scores": sc, "top": idx[:10], "best": idx[0], "median": idx[len(sc) // 2], "worst": idx[-1]}))
        return
    mpg, sc, rows, st = guess(tr, te)
    if cmd == 'guess':
        print(json.dumps({"mpg": mpg, "scores": sc}))
        return
    hist = [d2h([fl(r[g]) for g in G], st) for r in rows]
    al = []
    for i in range(len(sc)):
        if i < 19:
            al.append(False)
        else:
            al.append(not cert(hist, sc[i - 19:i + 1])[3])
    print(json.dumps({"mpg": mpg, "scores": sc, "alerts": al}))

main()
