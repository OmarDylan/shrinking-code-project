import sys, csv, json, math
import numpy as np
from sklearn.ensemble import RandomForestRegressor

GOALS = [("Lbs-", 0), ("Acc+", 1), ("Mpg+", 1)]
NUM = ["Clndrs", "Volume", "Model"]


def load(path):
    with open(path, newline="") as f:
        r = csv.reader(f)
        header = [h.strip() for h in next(r)]
        rows = [[c.strip() for c in row] for row in r if row]
    return header, rows


def num(s):
    try:
        v = float(s)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError):
        return None


def goal_values(path):
    header, rows = load(path)
    idx = [header.index(g) for g, _ in GOALS]
    return [[num(row[i]) for i in idx] for row in rows]


def get_stats(tr):
    n = len(tr)
    stats = []
    for j in range(3):
        col = [r[j] for r in tr]
        m = sum(col) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in col) / (n - 1)) if n > 1 else 0.0
        stats.append((m, sd))
    return stats


def d2h(r, stats):
    s = 0.0
    for j, (_, h) in enumerate(GOALS):
        m, sd = stats[j]
        z = max(-3.0, min(3.0, (r[j] - m) / (sd + 1e-32)))
        nv = 1 / (1 + math.exp(-1.702 * z))
        s += (nv - h) ** 2
    return math.sqrt(s / 3)


def arg(a, name):
    return a[a.index(name) + 1]


def remember(a):
    tr = [r for r in goal_values(arg(a, "--train")) if None not in r]
    te = goal_values(arg(a, "--test"))
    stats = get_stats(tr)
    scores = [d2h(r, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    print(json.dumps({
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }))


def guess(a):
    th, trows = load(arg(a, "--train"))
    eh, erows = load(arg(a, "--test"))
    gi = [th.index(g) for g, _ in GOALS]
    trows = [r for r in trows if all(num(r[i]) is not None for i in gi)]
    stats = get_stats([[float(r[i]) for i in gi] for r in trows])
    y_d = np.array([d2h([float(r[i]) for i in gi], stats) for r in trows])
    y_m = np.array([float(r[gi[2]]) for r in trows])

    cats = sorted({r[th.index("origin")] for r in trows if r[th.index("origin")] != "?"})

    def raw(header, rows):
        ci = [header.index(c) for c in NUM]
        oi = header.index("origin")
        X = [[num(r[i]) for i in ci] for r in rows]
        O = [[1.0 if r[oi] == c else 0.0 for c in cats] for r in rows]
        return X, O

    Xt, Ot = raw(th, trows)
    Xe, Oe = raw(eh, erows)
    med = []
    for j in range(3):
        v = [x[j] for x in Xt if x[j] is not None]
        med.append(float(np.median(v)) if v else 0.0)

    def build(X, O, cols, mask=None):
        out = []
        for k, x in enumerate(X):
            out.append([(x[j] if x[j] is not None else med[j]) for j in cols] + O[k])
        return np.array(out, dtype=float)

    full, red = [0, 1, 2], [0, 2]
    models = {}
    for key, cols in (("full", full), ("red", red)):
        A = build(Xt, Ot, cols)
        md = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0, n_jobs=1).fit(A, y_d)
        mm = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0, n_jobs=1).fit(A, y_m)
        models[key] = (cols, md, mm)

    mpg, scores = [0.0] * len(erows), [0.0] * len(erows)
    fallback_m = float(y_m.mean())
    fallback_d = float(y_d.mean())
    for i, x in enumerate(Xe):
        key = "red" if (i % 2 == 0 or x[1] is None) else "full"
        cols, md, mm = models[key]
        A = build([x], [Oe[i]], cols)
        m = float(mm.predict(A)[0])
        d = float(md.predict(A)[0])
        if not math.isfinite(m) or m <= 0:
            m = fallback_m
        if not math.isfinite(d):
            d = fallback_d
        mpg[i] = m
        scores[i] = min(1.0, max(0.0, d))
    print(json.dumps({"mpg": mpg, "scores": scores}))


def mean(v):
    return sum(v) / len(v)


def svar(v):
    m = mean(v)
    return sum((x - m) ** 2 for x in v) / (len(v) - 1)


def compare(xs, ys):
    xs = [float(x) for x in xs]
    ys = [float(y) for y in ys]
    n, m = len(xs), len(ys)
    pooled = ((n - 1) * svar(xs) + (m - 1) * svar(ys)) / (n + m - 2)
    cohen = abs(mean(xs) - mean(ys)) / (math.sqrt(pooled) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    i = j = 0
    d = 0.0
    for v in sorted(set(xs) | set(ys)):
        while i < n and sx[i] <= v:
            i += 1
        while j < m and sy[j] <= v:
            j += 1
        d = max(d, abs(i / n - j / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks,
            "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36)}


def certify(a):
    with open(arg(a, "--test")) as f:
        cases = json.load(f)
    print(json.dumps({"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}))


def main():
    a = sys.argv[1:]
    if not a or a[0] not in ("remember", "guess", "certify"):
        sys.exit("usage: main.py remember|guess|certify --train TRAIN --test TEST")
    {"remember": remember, "guess": guess, "certify": certify}[a[0]](a)


main()
