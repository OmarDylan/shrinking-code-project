import sys, csv, json, math, argparse

GOALS = [("Lbs-", 0.0), ("Acc+", 1.0), ("Mpg+", 1.0)]
NUMS = ["Clndrs", "Volume", "Model"]
CATS = ["origin"]


def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        r.fieldnames = [h.strip() for h in r.fieldnames]
        return [{k: (v or "").strip() for k, v in row.items()} for row in r]


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def get_stats(train, names=None):
    stats = {}
    for g in names or [g for g, _ in GOALS]:
        vals = [x for x in (num(r.get(g, "?")) for r in train) if x is not None]
        n = len(vals)
        m = sum(vals) / n if n else 0.0
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)
    return stats


def norm(v, g, stats):
    m, sd = stats[g]
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1.0 / (1.0 + math.exp(-1.702 * z))


def d2h(vals, stats):
    s = sum((norm(vals[g], g, stats) - h) ** 2 for g, h in GOALS)
    return math.sqrt(s / 3)


def remember(train, test):
    stats = get_stats(train)
    scores = [d2h({g: float(r[g]) for g, _ in GOALS}, stats) for r in test]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(order) // 2],
        "worst": order[-1],
    }


def guess(train, test):
    import numpy as np
    from sklearn.ensemble import RandomForestRegressor

    stats = get_stats(train)
    origins = sorted({r.get("origin", "") for r in train})

    def feats(r, use_vol):
        f = [num(r.get("Clndrs")), num(r.get("Model"))]
        if use_vol:
            f.append(num(r.get("Volume")))
        f += [1.0 if r.get("origin", "") == o else 0.0 for o in origins]
        return f

    def build(rows, use_vol, med=None):
        X = np.array([[np.nan if v is None else v for v in feats(r, use_vol)] for r in rows], float)
        if med is None:
            med = np.nanmedian(X, axis=0)
            med = np.where(np.isnan(med), 0.0, med)
        idx = np.where(np.isnan(X))
        X[idx] = med[idx[1]]
        return X, med

    mpg_rows, mpg_y, d_rows, d_y = [], [], [], []
    for r in train:
        vals = {g: num(r.get(g, "?")) for g, _ in GOALS}
        if vals["Mpg+"] is not None:
            mpg_rows.append(r)
            mpg_y.append(vals["Mpg+"])
        if all(v is not None for v in vals.values()):
            d_rows.append(r)
            d_y.append(d2h(vals, stats))

    def fit_pred(rows, y, use_vol, targets):
        X, med = build(rows, use_vol)
        m = RandomForestRegressor(n_estimators=300, min_samples_leaf=2, random_state=0, n_jobs=1)
        m.fit(X, y)
        Xt, _ = build(targets, use_vol, med)
        return m.predict(Xt)

    n = len(test)
    mpg = [0.0] * n
    sc = [0.0] * n
    for use_vol in (True, False):
        ids = [i for i, r in enumerate(test) if (num(r.get("Volume")) is not None) == use_vol]
        if not ids:
            continue
        tr = [test[i] for i in ids]
        pm = fit_pred(mpg_rows, mpg_y, use_vol, tr)
        pd_ = fit_pred(d_rows, d_y, use_vol, tr)
        for k, i in enumerate(ids):
            mpg[i] = float(pm[k])
            sc[i] = float(pd_[k])
    mpg = [max(v, 0.1) if math.isfinite(v) else 0.1 for v in mpg]
    sc = [min(1.0, max(0.0, v)) if math.isfinite(v) else 0.5 for v in sc]
    return {"mpg": mpg, "scores": sc}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)
    s = 0
    for x in xs:
        for y in ys:
            s += (x > y) - (x < y)
    cliffs = abs(s) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    import bisect
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m))
    ks = d / math.sqrt(1.0 / n + 1.0 / m)
    return {
        "cohen": cohen,
        "cliffs": cliffs,
        "ks": ks,
        "same": bool(cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36),
    }


def certify(cases):
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def flow(train, test, window=20):
    g = guess(train, test)
    stats = get_stats(train)
    hist = []
    for r in train:
        vals = {k: num(r.get(k, "?")) for k, _ in GOALS}
        if all(v is not None for v in vals.values()):
            hist.append(d2h(vals, stats))
    sc = g["scores"]
    alerts = []
    for i in range(len(sc)):
        if i < window - 1 or len(hist) < 2:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - window + 1:i + 1])["same"])
    return {"mpg": g["mpg"], "scores": sc, "alerts": alerts}


def blame(train, test):
    gstats = get_stats(train)
    istats = get_stats(train, NUMS)
    ranked = []
    for i, r in enumerate(train):
        vals = {g: num(r.get(g, "?")) for g, _ in GOALS}
        if all(v is not None for v in vals.values()):
            ranked.append((round(d2h(vals, gstats), 12), i))
    ranked.sort()
    q = max(1, len(ranked) // 4)
    good = [train[i] for _, i in ranked[:q]]
    poor = [train[i] for _, i in ranked[-q:]]

    centers = {}
    for c in NUMS:
        cs = []
        for grp in (good, poor):
            v = [x for x in (num(r.get(c, "?")) for r in grp) if x is not None]
            cs.append(norm(sum(v) / len(v), c, istats) if v else None)
        centers[c] = cs

    freqs = {}
    for c in CATS:
        fr = []
        for grp in (good, poor):
            known = [r.get(c, "") for r in grp if r.get(c, "") not in ("", "?")]
            d = {}
            for k in known:
                d[k] = d.get(k, 0) + 1
            fr.append({k: v / len(known) for k, v in d.items()})
        freqs[c] = fr

    def order(sc):
        return [k for k in sorted(sc, key=lambda k: (-round(sc[k], 10), k))]

    out = []
    for r in test:
        goals = {}
        for g, h in GOALS:
            v = num(r.get(g, "?"))
            goals[g] = abs(norm(v, g, gstats) - h) if v is not None else 0.0
        feats = {}
        for c in NUMS:
            x = num(r.get(c, "?"))
            gc, pc = centers[c]
            if x is None or gc is None or pc is None:
                feats[c] = 0.0
            else:
                nx = norm(x, c, istats)
                feats[c] = max(0.0, abs(nx - gc) - abs(nx - pc))
        for c in CATS:
            k = r.get(c, "")
            if k in ("", "?"):
                feats[c] = 0.0
            else:
                feats[c] = max(0.0, freqs[c][1].get(k, 0.0) - freqs[c][0].get(k, 0.0))
        out.append({"goals": goals, "features": feats,
                    "goal_order": order(goals), "feature_order": order(feats)})
    return {"diagnoses": out}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd")
    ap.add_argument("--train", required=True)
    ap.add_argument("--test", required=True)
    a = ap.parse_args()

    if a.cmd == "certify":
        with open(a.test) as f:
            out = certify(json.load(f))
        sys.stdout.write(json.dumps(out))
        return

    train, test = read(a.train), read(a.test)
    if a.cmd == "remember":
        out = remember(train, test)
    elif a.cmd == "guess":
        out = guess(train, test)
    elif a.cmd == "flow":
        out = flow(train, test)
    elif a.cmd == "blame":
        out = blame(train, test)
    else:
        sys.stderr.write("unknown command\n")
        sys.exit(2)
    sys.stdout.write(json.dumps(out))


main()
