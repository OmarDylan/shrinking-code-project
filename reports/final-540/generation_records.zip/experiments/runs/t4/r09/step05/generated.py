import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM_FEATS = ["Clndrs", "Volume", "Model"]


def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else v) for k, v in row.items()} for row in r]


def goal_stats(tr):
    stats = {}
    for g in GOALS:
        vals = [float(r[g]) for r in tr]
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)
    return stats


def normv(v, st):
    m, sd = st
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def d2h(vals, stats):
    s = 0.0
    for g, h in GOALS.items():
        s += (normv(vals[g], stats[g]) - h) ** 2
    return math.sqrt(s / 3)


def remember(tr, te):
    stats = goal_stats(tr)
    scores = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def clean(tr):
    good = []
    for r in tr:
        try:
            if all(math.isfinite(float(r[g])) for g in GOALS):
                good.append(r)
        except (TypeError, ValueError, KeyError):
            pass
    return good


def guess(tr, te):
    tr = clean(tr)
    stats = goal_stats(tr)
    cats = sorted({r.get("origin", "") for r in tr})

    def feats(r):
        return [num(r.get("Clndrs")), num(r.get("Volume")), num(r.get("Model"))] + [
            1.0 if r.get("origin", "") == c else 0.0 for c in cats
        ]

    Xtr = np.array([feats(r) for r in tr])
    Xte = np.array([feats(r) for r in te])
    targets = {
        "mpg": np.array([float(r["Mpg+"]) for r in tr]),
        "d2h": np.array([d2h({g: float(r[g]) for g in GOALS}, stats) for r in tr]),
    }
    nov = [0] + list(range(2, Xtr.shape[1]))
    miss = np.isnan(Xte[:, 1])
    preds = {}
    for name, y in targets.items():
        out = np.zeros(len(te))
        for use_vol, cols in ((True, list(range(Xtr.shape[1]))), (False, nov)):
            idx = np.where(~miss if use_vol else miss)[0]
            if len(idx) == 0:
                continue
            model = make_pipeline(
                SimpleImputer(strategy="median"),
                RandomForestRegressor(n_estimators=300, min_samples_leaf=3, random_state=0, n_jobs=1),
            )
            model.fit(Xtr[:, cols], y)
            out[idx] = model.predict(Xte[idx][:, cols])
        preds[name] = out
    mpg = [max(float(v), 1e-3) for v in preds["mpg"]]
    scores = [min(1.0, max(0.0, float(v))) for v in preds["d2h"]]
    return {"mpg": mpg, "scores": scores}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)
    tot = 0
    for x in xs:
        for y in ys:
            tot += (x > y) - (x < y)
    cliffs = abs(tot) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    import bisect
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}


def certify(cases):
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def flow(tr, te):
    out = guess(tr, te)
    good = clean(tr)
    stats = goal_stats(good)
    hist = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in good]
    sc = out["scores"]
    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    out["alerts"] = alerts
    return out


def known(r, k):
    v = r.get(k)
    if v is None or v.strip() in ("", "?"):
        return None
    return v


def numstat(vals):
    n = len(vals)
    if n == 0:
        return (0.0, 0.0)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return (m, sd)


def blame(tr, te):
    tr = clean(tr)
    gst = goal_stats(tr)
    sc = [d2h({g: float(r[g]) for g in GOALS}, gst) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(sc[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]

    def col(rows, k):
        out = []
        for r in rows:
            v = known(r, k)
            if v is not None:
                x = num(v)
                if math.isfinite(x):
                    out.append(x)
        return out

    nst, cen = {}, {}
    for k in NUM_FEATS:
        st = numstat(col(tr, k))
        nst[k] = st
        gv, pv = col(good, k), col(poor, k)
        cen[k] = (
            normv(sum(gv) / len(gv), st) if gv else None,
            normv(sum(pv) / len(pv), st) if pv else None,
        )

    def freqs(rows):
        vals = [known(r, "origin") for r in rows]
        vals = [v for v in vals if v is not None]
        n = len(vals)
        return {c: vals.count(c) / n for c in set(vals)} if n else {}

    gf, pf = freqs(good), freqs(poor)

    res = []
    for r in te:
        goals = {}
        for g, h in GOALS.items():
            goals[g] = abs(normv(float(r[g]), gst[g]) - h)
        feats = {}
        for k in NUM_FEATS:
            v = known(r, k)
            x = num(v) if v is not None else float("nan")
            gc, pc = cen[k]
            if not math.isfinite(x) or gc is None or pc is None:
                feats[k] = 0.0
            else:
                nx = normv(x, nst[k])
                feats[k] = min(1.0, max(0.0, abs(nx - gc) - abs(nx - pc)))
        v = known(r, "origin")
        feats["origin"] = 0.0 if v is None else max(0.0, pf.get(v, 0.0) - gf.get(v, 0.0))
        res.append({
            "goals": goals,
            "features": feats,
            "goal_order": sorted(goals, key=lambda n: (-round(goals[n], 10), n)),
            "feature_order": sorted(feats, key=lambda n: (-round(feats[n], 10), n)),
        })
    return {"diagnoses": res}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train", required=True)
    p.add_argument("--test", required=True)
    a = p.parse_args()
    if a.cmd not in ("remember", "guess", "certify", "flow", "blame"):
        sys.exit(1)
    if a.cmd == "certify":
        with open(a.test) as f:
            out = certify(json.load(f))
    else:
        tr = read(a.train)
        te = read(a.test)
        if a.cmd == "remember":
            out = remember(tr, te)
        elif a.cmd == "guess":
            out = guess(tr, te)
        elif a.cmd == "blame":
            out = blame(tr, te)
        else:
            out = flow(tr, te)
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
