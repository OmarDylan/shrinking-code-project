import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor, IsolationForest
from sklearn.impute import SimpleImputer

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}
NUM_FEATS = ["Clndrs", "Volume", "Model"]


def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else v) for k, v in row.items()} for row in r]


def goal_stats(tr):
    stats = {}
    for g in GOALS:
        vals = [float(r[g]) for r in tr]
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)
    return stats


def normv(v, st):
    m, sd = st
    z = max(-3.0, min(3.0, (v - m) / (sd + 1e-32)))
    return 1 / (1 + math.exp(-1.702 * z))


def d2h(vals, stats):
    s = 0.0
    for g, h in GOALS.items():
        s += (normv(vals[g], stats[g]) - h) ** 2
    return math.sqrt(s / 3)


def remember(tr, te):
    stats = goal_stats(tr)
    scores = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def clean(tr):
    good = []
    for r in tr:
        try:
            if all(math.isfinite(float(r[g])) for g in GOALS):
                good.append(r)
        except (TypeError, ValueError, KeyError):
            pass
    return good


def guess(tr, te):
    tr = clean(tr)
    stats = goal_stats(tr)
    cats = sorted({r.get("origin", "") for r in tr})

    def feats(r):
        return [num(r.get("Clndrs")), num(r.get("Volume")), num(r.get("Model"))] + [
            1.0 if r.get("origin", "") == c else 0.0 for c in cats
        ]

    Xtr = np.array([feats(r) for r in tr])
    Xte = np.array([feats(r) for r in te])
    targets = {
        "mpg": np.array([float(r["Mpg+"]) for r in tr]),
        "d2h": np.array([d2h({g: float(r[g]) for g in GOALS}, stats) for r in tr]),
    }
    nov = [0] + list(range(2, Xtr.shape[1]))
    miss = np.isnan(Xte[:, 1])
    preds = {}
    for name, y in targets.items():
        out = np.zeros(len(te))
        for use_vol, cols in ((True, list(range(Xtr.shape[1]))), (False, nov)):
            idx = np.where(~miss if use_vol else miss)[0]
            if len(idx) == 0:
                continue
            imp = SimpleImputer(strategy="median")
            A = imp.fit_transform(Xtr[:, cols])
            model = RandomForestRegressor(n_estimators=300, min_samples_leaf=3, random_state=0, n_jobs=1)
            model.fit(A, y)
            out[idx] = model.predict(imp.transform(Xte[idx][:, cols]))
        preds[name] = out
    mpg = [max(float(v), 1e-3) for v in preds["mpg"]]
    scores = [min(1.0, max(0.0, float(v))) for v in preds["d2h"]]
    return {"mpg": mpg, "scores": scores}


def compare(xs, ys):
    xs = [float(v) for v in xs]
    ys = [float(v) for v in ys]
    n, m = len(xs), len(ys)
    mx, my = sum(xs) / n, sum(ys) / m
    vx = sum((v - mx) ** 2 for v in xs) / (n - 1)
    vy = sum((v - my) ** 2 for v in ys) / (m - 1)
    pooled = ((n - 1) * vx + (m - 1) * vy) / (n + m - 2)
    cohen = abs(mx - my) / (math.sqrt(pooled) + 1e-32)
    tot = 0
    for x in xs:
        for y in ys:
            tot += (x > y) - (x < y)
    cliffs = abs(tot) / (n * m)
    sx, sy = sorted(xs), sorted(ys)
    import bisect
    d = 0.0
    for v in set(xs) | set(ys):
        d = max(d, abs(bisect.bisect_right(sx, v) / n - bisect.bisect_right(sy, v) / m))
    ks = d / math.sqrt(1 / n + 1 / m)
    same = cohen <= 0.35 and cliffs <= 0.197 and ks <= 1.36
    return {"cohen": cohen, "cliffs": cliffs, "ks": ks, "same": bool(same)}


def certify(cases):
    return {"comparisons": [compare(c["xs"], c["ys"]) for c in cases]}


def flow(tr, te):
    out = guess(tr, te)
    good = clean(tr)
    stats = goal_stats(good)
    hist = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in good]
    sc = out["scores"]
    alerts = []
    for i in range(len(sc)):
        if i < 19:
            alerts.append(False)
        else:
            alerts.append(not compare(hist, sc[i - 19:i + 1])["same"])
    out["alerts"] = alerts
    return out


def known(r, k):
    v = r.get(k)
    if v is None or v.strip() in ("", "?"):
        return None
    return v


def numstat(vals):
    n = len(vals)
    if n == 0:
        return (0.0, 0.0)
    m = sum(vals) / n
    sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
    return (m, sd)


def blame(tr, te):
    tr = clean(tr)
    gst = goal_stats(tr)
    sc = [d2h({g: float(r[g]) for g in GOALS}, gst) for r in tr]
    order = sorted(range(len(tr)), key=lambda i: (round(sc[i], 12), i))
    q = max(1, len(tr) // 4)
    good = [tr[i] for i in order[:q]]
    poor = [tr[i] for i in order[-q:]]

    def col(rows, k):
        out = []
        for r in rows:
            v = known(r, k)
            if v is not None:
                x = num(v)
                if math.isfinite(x):
                    out.append(x)
        return out

    nst, cen = {}, {}
    for k in NUM_FEATS:
        st = numstat(col(tr, k))
        nst[k] = st
        gv, pv = col(good, k), col(poor, k)
        cen[k] = (
            normv(sum(gv) / len(gv), st) if gv else None,
            normv(sum(pv) / len(pv), st) if pv else None,
        )

    def freqs(rows):
        vals = [known(r, "origin") for r in rows]
        vals = [v for v in vals if v is not None]
        n = len(vals)
        return {c: vals.count(c) / n for c in set(vals)} if n else {}

    gf, pf = freqs(good), freqs(poor)

    res = []
    for r in te:
        goals = {}
        for g, h in GOALS.items():
            goals[g] = abs(normv(float(r[g]), gst[g]) - h)
        feats = {}
        for k in NUM_FEATS:
            v = known(r, k)
            x = num(v) if v is not None else float("nan")
            gc, pc = cen[k]
            if not math.isfinite(x) or gc is None or pc is None:
                feats[k] = 0.0
            else:
                nx = normv(x, nst[k])
                feats[k] = min(1.0, max(0.0, abs(nx - gc) - abs(nx - pc)))
        v = known(r, "origin")
        feats["origin"] = 0.0 if v is None else max(0.0, pf.get(v, 0.0) - gf.get(v, 0.0))
        res.append({
            "goals": goals,
            "features": feats,
            "goal_order": sorted(goals, key=lambda n: (-round(goals[n], 10), n)),
            "feature_order": sorted(feats, key=lambda n: (-round(feats[n], 10), n)),
        })
    return {"diagnoses": res}


def justify(tr, te):
    good = clean(tr)
    stats = goal_stats(good)
    hs = sorted(d2h({g: float(r[g]) for g in GOALS}, stats) for r in good)
    cutoff = hs[len(good) // 2]
    scores = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in te]
    diags = blame(tr, te)["diagnoses"]
    n = len(te)

    def gap2(r, g):
        return (normv(float(r[g]), stats[g]) - GOALS[g]) ** 2

    out = []
    for j in range(n):
        k = (j + 1) % n
        s, o = scores[j], scores[k]
        accepted = round(s, 12) <= round(cutoff, 12)
        winner = None
        adv_goal = None
        if round(s, 12) != round(o, 12):
            winner = j if s < o else k
            loser = k if winner == j else j
            adv = {g: gap2(te[loser], g) - gap2(te[winner], g) for g in GOALS}
            adv_goal = sorted(adv, key=lambda g: (-round(adv[g], 10), g))[0]
        d = diags[j]
        weakest = d["goal_order"][0]
        tf = d["feature_order"][0]
        top = tf if d["features"][tf] > 1e-10 else None
        text = "Car %d %s: score %.3f, other score %.3f, cutoff %.3f; weakest_goal %s." % (
            j, "accepted" if accepted else "rejected", s, o, cutoff, weakest)
        if winner is not None:
            text += " Recommend car %d; advantage_goal %s." % (winner, adv_goal)
        else:
            text += " Scores tie."
        if top is not None:
            text += " Top feature %s (retrospective association, not causal)." % top
        out.append({
            "row": j, "other": k, "score": s, "other_score": o, "cutoff": cutoff,
            "accepted": bool(accepted), "winner": winner, "advantage_goal": adv_goal,
            "weakest_goal": weakest, "top_feature": top, "text": text,
        })
    return {"explanations": out}


def choose(tr, te, budget=10):
    tr = clean(tr)
    stats = goal_stats(tr)
    cats = sorted({r.get("origin", "") for r in tr})

    def feats(r):
        return [num(r.get("Clndrs")), num(r.get("Volume")), num(r.get("Model"))] + [
            1.0 if r.get("origin", "") == c else 0.0 for c in cats
        ]

    imp = SimpleImputer(strategy="median")
    Xtr = imp.fit_transform(np.array([feats(r) for r in tr]))
    Xte = imp.transform(np.array([feats(r) for r in te]))
    y = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in tr]
    n = len(te)
    seen = {}
    X = Xtr
    for step in range(min(budget, n)):
        rf = RandomForestRegressor(n_estimators=100, min_samples_leaf=2, random_state=step, n_jobs=1)
        rf.fit(X, y)
        P = np.array([t.predict(Xte) for t in rf.estimators_])
        kappa = 1.0 if step < 4 else 0.3
        acq = P.mean(0) - kappa * P.std(0)
        cand = [i for i in range(n) if i not in seen]
        i = min(cand, key=lambda i: (acq[i], i))
        sys.stdout.write(json.dumps({"inspect": i}) + "\n")
        sys.stdout.flush()
        resp = json.loads(sys.stdin.readline())
        gl = {g: float(resp["goals"][g]) for g in GOALS}
        s = d2h(gl, stats)
        seen[i] = s
        X = np.vstack([X, Xte[i:i + 1]])
        y = y + [s]
    order = sorted(seen, key=lambda i: (round(seen[i], 12), i))
    sys.stdout.write(json.dumps({"selected": order[:3]}) + "\n")
    sys.stdout.flush()


def fix(tr, te):
    tr = clean(tr)
    sts = {}
    for k in NUM_FEATS:
        vals = [num(known(r, k)) if known(r, k) is not None else float("nan") for r in tr]
        vals = [v for v in vals if math.isfinite(v)]
        sts[k] = numstat(vals)

    def vec(r, over=None):
        v = []
        for k in NUM_FEATS:
            x = None
            if over and k in over:
                x = over[k]
            else:
                s = known(r, k)
                x = num(s) if s is not None else float("nan")
            if not math.isfinite(x):
                x = sts[k][0]
            v.append(normv(x, sts[k]))
        s = known(r, "origin")
        return v, (s if s is not None else "")

    def dist(a, b):
        t = sum((x - y) ** 2 for x, y in zip(a[0], b[0]))
        t += 0.0 if a[1] == b[1] else 1.0
        return math.sqrt(t / 4)

    tv = [vec(r) for r in tr]
    stats = goal_stats(tr)
    sc = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in tr]
    cutoff = sorted(sc)[len(tr) // 2]
    rank = sorted(range(len(tr)), key=lambda i: (round(sc[i], 12), i))
    q = max(1, len(tr) // 4)
    menu = []
    for i in rank[:q]:
        p = (num(tr[i].get("Clndrs")), num(tr[i].get("Volume")))
        if not all(math.isfinite(x) for x in p):
            continue
        if p not in menu:
            menu.append(p)
        if len(menu) == 12:
            break

    def predict(v):
        ds = sorted(range(len(tr)), key=lambda i: (round(dist(v, tv[i]), 12), i))[:5]
        return sum(sc[i] for i in ds) / len(ds)

    reps = []
    for idx, r in enumerate(te):
        v0 = vec(r)
        before = predict(v0)
        rep = {"row": idx, "before": before, "after": before, "changes": {}, "status": "already_good"}
        if round(before, 10) > round(cutoff, 10):
            c0, w0 = num(r.get("Clndrs")), num(r.get("Volume"))
            best = None
            for c, w in menu:
                ch = {}
                if c != c0:
                    ch["Clndrs"] = c
                if w != w0:
                    ch["Volume"] = w
                if not ch:
                    continue
                v1 = vec(r, {"Clndrs": c, "Volume": w})
                after = predict(v1)
                if round(before - after, 10) >= 0.05:
                    key = (len(ch), round(dist(v0, v1), 10), round(after, 10), (c, w))
                    if best is None or key < best[0]:
                        best = (key, ch, after)
            if best is None:
                rep["status"] = "no_candidate"
            else:
                rep["status"] = "improved"
                rep["changes"] = {k: float(x) for k, x in best[1].items()}
                rep["after"] = best[2]
        reps.append(rep)
    return {"repairs": reps}


def spot(tr, te, quantile=0.97):
    cats = sorted({r.get("origin", "") for r in tr if known(r, "origin") is not None})

    def raw(rows):
        return np.array([[num(known(r, k)) if known(r, k) is not None else float("nan")
                          for k in NUM_FEATS] for r in rows], dtype=float).reshape(len(rows), len(NUM_FEATS))

    def onehot(rows):
        return np.array([[1.0 if r.get("origin") == c else 0.0 for c in cats] for r in rows],
                        dtype=float).reshape(len(rows), len(cats))

    Rtr, Rte = raw(tr), raw(te)
    med = np.array([np.nanmedian(Rtr[:, j]) if np.isfinite(Rtr[:, j]).any() else 0.0
                    for j in range(Rtr.shape[1])])
    scale = np.ones(Rtr.shape[1])
    for j in range(Rtr.shape[1]):
        c = Rtr[:, j][np.isfinite(Rtr[:, j])]
        if len(c) == 0:
            continue
        s = 1.4826 * np.median(np.abs(c - med[j]))
        if s <= 1e-12:
            s = c.std()
        scale[j] = s if s > 1e-12 else 1.0

    def maxz(R):
        Z = np.abs((R - med) / scale)
        Z = np.where(np.isfinite(Z), Z, 0.0)
        return Z.max(axis=1)

    def fill(R):
        return np.where(np.isfinite(R), R, med)

    def design(R, rows):
        return np.hstack([(fill(R) - med) / scale, onehot(rows)])

    Xtr, Xte = design(Rtr, tr), design(Rte, te)
    iso = IsolationForest(n_estimators=300, random_state=0, n_jobs=1).fit(Xtr)
    a_tr, a_te = -iso.score_samples(Xtr), -iso.score_samples(Xte)
    z_tr, z_te = maxz(Rtr), maxz(Rte)
    sa, sz = np.sort(a_tr), np.sort(z_tr)
    n = len(tr)

    def ecdf(s, v):
        return np.searchsorted(s, v, side="right") / n

    c_tr = (ecdf(sa, a_tr) + ecdf(sz, z_tr)) / 2
    c_te = (ecdf(sa, a_te) + ecdf(sz, z_te)) / 2
    sc_ = np.sort(c_tr)
    s_tr = ecdf(sc_, c_tr)
    s_te = ecdf(sc_, c_te)
    # test rows more extreme than any training row on a component get a boost
    ext = (z_te > z_tr.max()) | (a_te > a_tr.max())
    s_te = np.where(ext, np.maximum(s_te, 0.99), s_te)
    thr = float(np.quantile(s_tr, quantile))
    scores = [float(min(1.0, max(0.0, v))) for v in s_te]
    return {"scores": scores, "alerts": [bool(v > thr) for v in scores],
            "threshold": min(1.0, max(0.0, thr))}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train", required=True)
    p.add_argument("--test", required=True)
    a = p.parse_args()
    if a.cmd not in ("remember", "guess", "certify", "flow", "blame", "justify", "choose", "fix", "spot"):
        sys.exit(1)
    if a.cmd == "certify":
        with open(a.test) as f:
            out = certify(json.load(f))
    else:
        tr = read(a.train)
        te = read(a.test)
        if a.cmd == "choose":
            choose(tr, te)
            return
        if a.cmd == "remember":
            out = remember(tr, te)
        elif a.cmd == "guess":
            out = guess(tr, te)
        elif a.cmd == "blame":
            out = blame(tr, te)
        elif a.cmd == "justify":
            out = justify(tr, te)
        elif a.cmd == "fix":
            out = fix(tr, te)
        elif a.cmd == "spot":
            out = spot(tr, te)
        else:
            out = flow(tr, te)
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
