import sys, csv, json, math, argparse
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else v) for k, v in row.items()} for row in r]


def goal_stats(tr):
    stats = {}
    for g in GOALS:
        vals = [float(r[g]) for r in tr]
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)
    return stats


def d2h(vals, stats):
    s = 0.0
    for g, h in GOALS.items():
        m, sd = stats[g]
        z = max(-3.0, min(3.0, (vals[g] - m) / (sd + 1e-32)))
        nv = 1 / (1 + math.exp(-1.702 * z))
        s += (nv - h) ** 2
    return math.sqrt(s / 3)


def remember(tr, te):
    stats = goal_stats(tr)
    scores = [d2h({g: float(r[g]) for g in GOALS}, stats) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    return {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }


def num(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def guess(tr, te):
    good = []
    for r in tr:
        try:
            if all(math.isfinite(float(r[g])) for g in GOALS):
                good.append(r)
        except (TypeError, ValueError, KeyError):
            pass
    tr = good
    stats = goal_stats(tr)
    cats = sorted({r.get("origin", "") for r in tr})

    def feats(r):
        return [num(r.get("Clndrs")), num(r.get("Volume")), num(r.get("Model"))] + [
            1.0 if r.get("origin", "") == c else 0.0 for c in cats
        ]

    Xtr = np.array([feats(r) for r in tr])
    Xte = np.array([feats(r) for r in te])
    targets = {
        "mpg": np.array([float(r["Mpg+"]) for r in tr]),
        "d2h": np.array([d2h({g: float(r[g]) for g in GOALS}, stats) for r in tr]),
    }
    nov = [0] + list(range(2, Xtr.shape[1]))
    miss = np.isnan(Xte[:, 1])
    preds = {}
    for name, y in targets.items():
        out = np.zeros(len(te))
        for use_vol, cols in ((True, list(range(Xtr.shape[1]))), (False, nov)):
            idx = np.where(~miss if use_vol else miss)[0]
            if len(idx) == 0:
                continue
            model = make_pipeline(
                SimpleImputer(strategy="median"),
                RandomForestRegressor(n_estimators=300, min_samples_leaf=3, random_state=0, n_jobs=1),
            )
            model.fit(Xtr[:, cols], y)
            out[idx] = model.predict(Xte[idx][:, cols])
        preds[name] = out
    mpg = [max(float(v), 1e-3) for v in preds["mpg"]]
    scores = [min(1.0, max(0.0, float(v))) for v in preds["d2h"]]
    return {"mpg": mpg, "scores": scores}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train", required=True)
    p.add_argument("--test", required=True)
    a = p.parse_args()
    if a.cmd not in ("remember", "guess"):
        sys.exit(1)
    tr = read(a.train)
    te = read(a.test)
    out = remember(tr, te) if a.cmd == "remember" else guess(tr, te)
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
