import sys, csv, json, math, argparse

GOALS = {"Lbs-": 0.0, "Acc+": 1.0, "Mpg+": 1.0}


def read(path):
    with open(path, newline="") as f:
        r = csv.DictReader(f)
        return [{k.strip(): (v.strip() if v is not None else v) for k, v in row.items()} for row in r]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd")
    p.add_argument("--train", required=True)
    p.add_argument("--test", required=True)
    a = p.parse_args()
    if a.cmd != "remember":
        sys.exit(1)
    tr = read(a.train)
    te = read(a.test)
    stats = {}
    for g in GOALS:
        vals = [float(r[g]) for r in tr]
        n = len(vals)
        m = sum(vals) / n
        sd = math.sqrt(sum((v - m) ** 2 for v in vals) / (n - 1)) if n > 1 else 0.0
        stats[g] = (m, sd)

    def score(r):
        s = 0.0
        for g, h in GOALS.items():
            m, sd = stats[g]
            z = max(-3.0, min(3.0, (float(r[g]) - m) / (sd + 1e-32)))
            nv = 1 / (1 + math.exp(-1.702 * z))
            s += (nv - h) ** 2
        return math.sqrt(s / 3)

    scores = [score(r) for r in te]
    order = sorted(range(len(scores)), key=lambda i: (scores[i], i))
    out = {
        "scores": scores,
        "top": order[:10],
        "best": order[0],
        "median": order[len(te) // 2],
        "worst": order[-1],
    }
    sys.stdout.write(json.dumps(out))


if __name__ == "__main__":
    main()
